package com.aliyun.iot.industry.data.network;

import java.io.Serializable;

public class SendShortMessageRequest implements Serializable{
    private String phoneNumber;

    public SendShortMessageRequest(){}

    public SendShortMessageRequest(String phoneNumber) {
        this.phoneNumber = phoneNumber;
    }

    public void setPhoneNumber(String phoneNumber) {
        this.phoneNumber = phoneNumber;
    }
}
