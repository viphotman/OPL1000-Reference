package com.aliyun.iot.industry.page.view;

import android.app.Activity;
import android.content.Context;
import android.util.AttributeSet;

import com.alibaba.sdk.android.openaccount.ui.widget.MobileInputBoxWithClear;

/**
 * 隐藏注册账号左边的内容
 */
public class RegisterInputView extends MobileInputBoxWithClear {
    public RegisterInputView(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);

    }

    @Override
    public void setSupportForeignMobile(Activity activity, Class<? extends Activity> aClass, boolean b) {
        super.setSupportForeignMobile(activity, aClass, b);
        leftIcon.setVisibility(GONE);
        chosedCountryNumSub.setVisibility(GONE);
        chosedCountryNumSub.setVisibility(GONE);
        countryChooseButton.setVisibility(GONE);
    }
}
