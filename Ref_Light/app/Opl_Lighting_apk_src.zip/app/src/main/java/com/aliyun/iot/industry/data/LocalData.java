package com.aliyun.iot.industry.data;

import android.content.Context;

import com.aliyun.iot.industry.data.helper.SharedPreferencesHelper;

public class LocalData {
    private static final String TAG = "LocalData";
    private static final String FILE_NAME = "LOCAL_FILE";
    private static final String DEVICE_AUTO_REFRESH = "DEVICE_AUTO_REFRESH";

    private static SharedPreferencesHelper helper;

    public static void init(Context context) {
        helper = new SharedPreferencesHelper(context, FILE_NAME);
    }

    public static boolean getDeviceAutoRefresh() {
        return (boolean) helper.getSharedPreference(DEVICE_AUTO_REFRESH, false);
    }

    public static void setDeviceAutoRefresh(boolean on) {
        helper.put(DEVICE_AUTO_REFRESH, on);
    }

}
