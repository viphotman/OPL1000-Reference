package com.aliyun.iot.industry.page.myhome;


import com.aliyun.iot.industry.base.OnItemClickListener;

public   interface HomeItemClickListener<T> extends OnItemClickListener <T> {
    /**
     * HOME ITEM    title 点击事件
     * @param item
     */
    abstract void onListTitleClick(T item);
}
