package com.aliyun.iot.industry.base;


import android.view.View;

public interface OnItemClickListener<T> {

    void onListItemClick(T item);

    void onListItemLongClick(View view, T item);

    void onListItemMarkClick(T item);

}
