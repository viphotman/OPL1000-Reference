package com.aliyun.iot.industry.util;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.support.v4.content.LocalBroadcastManager;

import java.util.HashMap;

public class BroadCastUtil {

    private static final int MAX_INTENT = 100;

    private static HashMap<String, Intent> sIntentMap = new HashMap<>(MAX_INTENT);

    public static void broadCast(Context context, Intent intent) {
        LocalBroadcastManager.getInstance(context).sendBroadcast(intent);
    }
    public static void broadCastSticky(Context context, Intent intent) {
        LocalBroadcastManager.getInstance(context).sendBroadcast(intent);
        sIntentMap.put(intent.getAction(), intent);
    }

    public static void register(Context context, BroadcastReceiver receiver, IntentFilter filter) {
        LocalBroadcastManager.getInstance(context).registerReceiver(receiver, filter);
        for (int i=0; i<filter.countActions(); i++) {
            String action = filter.getAction(i);
            Intent in = sIntentMap.get(action);
            if (in != null) {
                receiver.onReceive(context, in);
            }
        }

    }

    public static void unRegister(Context context, BroadcastReceiver receiver) {
        LocalBroadcastManager.getInstance(context).unregisterReceiver(receiver);
    }
}
