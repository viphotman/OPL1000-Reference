package com.aliyun.iot.industry.widget;

import android.app.AlertDialog;
import android.content.Context;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.Window;


public class BottomDialog {
    private AlertDialog mDialog;
    private BottomDialogView mView;

    public BottomDialog(Context context, int resId) {
        if (context == null || resId <= 0) return;

        mDialog = new AlertDialog.Builder(context).create();

        mView = (BottomDialogView) LayoutInflater.from(context).inflate(resId, null);

        if (mView == null) return;

        mDialog.setView(mView);


        Window window = mDialog.getWindow();
        if (window != null) {
            window.setGravity(Gravity.BOTTOM);
            window.setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));

        }

    }

    public void show() {
        if (mDialog != null && !mDialog.isShowing()) {
            mDialog.show();
        }
    }

    public void dismiss() {
        if (mDialog != null) {
            mDialog.dismiss();
        }
    }

    public void setOnClickListener(final View.OnClickListener listener) {
        if (mView == null || listener == null) return;
        View.OnClickListener innerListener = new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                listener.onClick(view);
                dismiss();
            }
        };
        mView.setOnClickListener(innerListener);
    }


}
