package com.aliyun.iot.industry.base;

import java.io.Serializable;

public abstract class BaseModule implements Serializable {
}
