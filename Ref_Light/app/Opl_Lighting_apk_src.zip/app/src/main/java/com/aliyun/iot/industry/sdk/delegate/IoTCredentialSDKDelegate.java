package com.aliyun.iot.industry.sdk.delegate;

import android.app.Application;

import com.aliyun.iot.aep.sdk.apiclient.IoTAPIClientImpl;
import com.aliyun.iot.aep.sdk.apiclient.hook.IoTAuthProvider;
import com.aliyun.iot.aep.sdk.credential.IoTCredentialProviderImpl;
import com.aliyun.iot.aep.sdk.credential.IotCredentialManager.IoTCredentialManageImpl;
import com.aliyun.iot.aep.sdk.credential.listener.IoTTokenInvalidListener;
import com.aliyun.iot.aep.sdk.framework.sdk.SDKConfigure;
import com.aliyun.iot.aep.sdk.framework.sdk.SimpleSDKDelegateImp;
import com.aliyun.iot.aep.sdk.log.ALog;

import java.util.Map;

import com.aliyun.iot.industry.util.LoginUtils;

public final class IoTCredentialSDKDelegate extends SimpleSDKDelegateImp {
    static final private String TAG = "IoTCredentialSDKDelegate";
    static final public String KEY_APPKEY = "KEY_APPKEY";

    /* API: IoTCredentialSDKDelegate */

    @Override
    public int init(Application app, SDKConfigure configure, Map<String, String> args) {

        IoTCredentialManageImpl.init(args.get(KEY_APPKEY));

        IoTAuthProvider provider = new IoTCredentialProviderImpl(IoTCredentialManageImpl.getInstance(app));
        IoTAPIClientImpl.getInstance().registerIoTAuthProvider("iotAuth", provider);

//        TODO
        IoTCredentialManageImpl.getInstance(app).setIotCredentialListenerList(new IoTTokenInvalidListener() {
            @Override
            public void onIoTTokenInvalid() {
                ALog.d("IoTCredentialSDK", "onIoTTokenInvalid");
                LoginUtils.logout();
            }
        });
        IoTCredentialManageImpl.DefaultDailyALiYunCreateIotTokenRequestHost = "system.service.daily.aliplus.com";
        return 0;

    }


}
