package com.aliyun.iot.industry.widget;

import android.content.Context;
import android.support.v4.widget.SwipeRefreshLayout;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.RecyclerView.OnScrollListener;
import android.util.AttributeSet;
import android.util.TypedValue;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.view.animation.LinearInterpolator;
import android.widget.FrameLayout;

import com.aliyun.iot.industry.R;

/**
 * 继承自SwipeRefreshLayout,实现RecycleView滑动到底部时上拉加载更多的功能.
 */
public class RefreshRecycleViewLayout extends SwipeRefreshLayout {

    // 内嵌的子View
    private FrameLayout contentView = null;

    // 内嵌的RecyclerView
    private RecyclerView targetView = null;

    private LoadMoreWrapperAdapter loadMoreWrapperAdapter = null;

    // 上拉接口监听器, 到了最底部的上拉加载操作
    private OnLoadMoreListener onLoadMoreListener = null;

    // 当item为空时显示
    private View emptyView = null;

    public RefreshRecycleViewLayout(Context context) {
        this(context, null);
    }

    public RefreshRecycleViewLayout(Context context, AttributeSet attrs) {
        super(context, attrs);
        initView();
    }

    private void initView() {
        //设置下拉出现小圆圈是否是缩放出现，出现的位置，最大的下拉位置
        setProgressViewOffset(false, 0, (int) TypedValue
                .applyDimension(TypedValue.COMPLEX_UNIT_DIP, 24, getResources()
                        .getDisplayMetrics()));
        // 设置下拉圆圈上的颜色
        setColorSchemeColors(0xFF999999);
        //设置下拉圆圈的大小，两个值 LARGE， DEFAULT
        setSize(SwipeRefreshLayout.DEFAULT);
        // 设定下拉圆圈的背景
        setProgressBackgroundColorSchemeColor(0xFFFFFFFF);
        addContentView();
    }

    private void addContentView() {
        contentView = new FrameLayout(getContext());
        LayoutParams layoutParams1 = new LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.WRAP_CONTENT);
        contentView.setLayoutParams(layoutParams1);
        this.addView(contentView);
        targetView = new RecyclerView(getContext());
        FrameLayout.LayoutParams layoutParams2 = new FrameLayout.LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.WRAP_CONTENT);
        targetView.setLayoutParams(layoutParams2);
        targetView.addOnScrollListener(new OnScrollListenerImpl());
        contentView.addView(targetView);
    }

    /**
     * 用来获取内部的RecyclerView
     * 由于RefreshRecycleViewLayout目前只提供setAdapter、setLayoutManager、addItemDecoration三个方法，
     * 因此如果想要使用RecyclerView的其他方法，通过获取内部的RecyclerView来完成其他方法的调用
     */
    public RecyclerView getTargetView() {
        return targetView;
    }

    public void setEmptyView(int emptyViewResId) {
        if (emptyViewResId <= 0) {
            return;
        }

        if (null != this.emptyView) {
            contentView.removeView(this.emptyView);
            this.emptyView = null;
        }
        LayoutInflater inflater = LayoutInflater.from(getContext());
        this.emptyView = inflater.inflate(emptyViewResId, contentView, false);
        this.emptyView.setVisibility(GONE);
        contentView.addView(this.emptyView);
    }

    public void setEmptyView(View emptyView) {
        if (null == emptyView) {
            return;
        }

        if (null != this.emptyView) {
            contentView.removeView(this.emptyView);
            this.emptyView = null;
        }
        this.emptyView = emptyView;
        this.emptyView.setVisibility(GONE);
        contentView.addView(this.emptyView);
    }

    /**
     * 用于手动显示或者隐藏EmptyView
     */
    public void updateEmptyView(boolean show) {
        if (null == this.emptyView) {
            return;
        }
        if ((show && this.emptyView.getVisibility() == VISIBLE) || (!show && this.emptyView.getVisibility() == GONE)) {
            return;
        }
        this.emptyView.setVisibility(show ? VISIBLE : GONE);
    }

    @Override
    public void setOnRefreshListener(final OnRefreshListener listener) {
        super.setOnRefreshListener(new OnRefreshListener() {
            @Override
            public void onRefresh() {
                if (null != loadMoreWrapperAdapter) {
                    loadMoreWrapperAdapter.setFullLoad(false);
                }
                listener.onRefresh();
            }
        });
    }

    public void setAdapter(RecyclerView.Adapter adapter) {
        if (null == adapter) {
            return;
        }

        loadMoreWrapperAdapter = new LoadMoreWrapperAdapter(this, adapter);
        targetView.setAdapter(loadMoreWrapperAdapter);
    }

    public void setLayoutManager(RecyclerView.LayoutManager layout) {
        if (null == layout) {
            return;
        }

        targetView.setLayoutManager(layout);
    }

    public void addItemDecoration(RecyclerView.ItemDecoration decor) {
        if (null == decor) {
            return;
        }

        targetView.addItemDecoration(decor);
    }

    /**
     * 当完全加载调用该方法取消上拉加载
     */
    public void fullLoad() {
        if (null != loadMoreWrapperAdapter) {
            loadMoreWrapperAdapter.setFullLoad(true);
        }
    }

    public void stopLoading() {
        setRefreshing(false);
        loadMoreWrapperAdapter.setShowLoadMore(false);
    }

    // 设置监听器
    public void setOnLoadMoreListener(OnLoadMoreListener loadListener) {
        onLoadMoreListener = loadListener;
    }

    // 加载更多的接口
    public interface OnLoadMoreListener {
        void onLoadMore();
    }

    static class LoadMoreWrapperAdapter extends RecyclerView.Adapter {

        private static final int ITEM_TYPE_LOAD_MORE = Integer.MAX_VALUE - 2;

        private RecyclerView.Adapter innerAdapter;
        private RefreshRecycleViewLayout refreshRecycleViewLayout = null;

        // 代表是否完全加载
        private boolean fullLoad = false;

        // 用来表示是否显示最后面的加载更多item,默认不显示
        private boolean showLoadMore = false;

        protected LoadMoreWrapperAdapter(RefreshRecycleViewLayout refreshRecycleViewLayout, RecyclerView.Adapter adapter) {
            this.refreshRecycleViewLayout = refreshRecycleViewLayout;
            this.innerAdapter = adapter;
            adapter.registerAdapterDataObserver(new RecyclerView.AdapterDataObserver() {
                @Override
                public void onChanged() {
                    super.onChanged();
                    updateView();
                    LoadMoreWrapperAdapter.this.notifyDataSetChanged();
                }

                @Override
                public void onItemRangeChanged(int positionStart, int itemCount) {
                    super.onItemRangeChanged(positionStart, itemCount);
                    LoadMoreWrapperAdapter.this.notifyItemRangeChanged(positionStart, itemCount);
                }

                @Override
                public void onItemRangeChanged(int positionStart, int itemCount, Object payload) {
                    super.onItemRangeChanged(positionStart, itemCount, payload);
                    LoadMoreWrapperAdapter.this.notifyItemRangeChanged(positionStart, itemCount, payload);
                }

                @Override
                public void onItemRangeInserted(int positionStart, int itemCount) {
                    super.onItemRangeInserted(positionStart, itemCount);
                    updateView();
                    LoadMoreWrapperAdapter.this.notifyItemRangeInserted(positionStart, itemCount);
                }

                @Override
                public void onItemRangeRemoved(int positionStart, int itemCount) {
                    super.onItemRangeRemoved(positionStart, itemCount);
                    updateView();
                    LoadMoreWrapperAdapter.this.notifyItemRangeRemoved(positionStart, itemCount);
                }

                @Override
                public void onItemRangeMoved(int fromPosition, int toPosition, int itemCount) {
                    super.onItemRangeMoved(fromPosition, toPosition, itemCount);
                    LoadMoreWrapperAdapter.this.notifyItemMoved(fromPosition, toPosition);
                }
            });
        }

        @Override
        public RecyclerView.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
            if (viewType == ITEM_TYPE_LOAD_MORE) {
                return LoadMoreViewHolder.getInstance(parent);
            }
            return innerAdapter.onCreateViewHolder(parent, viewType);
        }

        @Override
        public void onBindViewHolder(RecyclerView.ViewHolder holder, int position) {
            if (isShowLoadMore(position)) {
                ((LoadMoreViewHolder) holder).update(showLoadMore);
                return;
            }
            innerAdapter.onBindViewHolder(holder, position);
        }

        @Override
        public int getItemCount() {
            return innerAdapter.getItemCount() + 1;
        }

        @Override
        public int getItemViewType(int position) {
            if (isShowLoadMore(position)) {
                return ITEM_TYPE_LOAD_MORE;
            }
            return innerAdapter.getItemViewType(position);
        }

        private boolean isShowLoadMore(int position) {
            return (position >= innerAdapter.getItemCount());
        }

        private boolean isFullLoad() {
            return fullLoad;
        }

        private void setFullLoad(boolean fullLoad) {
            if (this.fullLoad == fullLoad) {
                return;
            }
            this.fullLoad = fullLoad;
            this.showLoadMore = false;
            notifyDataSetChanged();
        }

        private void setShowLoadMore(boolean showLoadMore) {
            this.showLoadMore = showLoadMore;
            notifyDataSetChanged();
        }

        private void updateView() {
            // 当第一次获取数据并且没有完全加载时,显示加载更多的item
            if (!this.showLoadMore && !isFullLoad()) {
                //this.showLoadMore = true;
            }

            if (innerAdapter.getItemCount() > 0) {
                this.refreshRecycleViewLayout.updateEmptyView(false);
                return;
            }

            this.showLoadMore = false;
            this.refreshRecycleViewLayout.updateEmptyView(true);
        }
    }

    static class LoadMoreViewHolder extends RecyclerView.ViewHolder {

        private View iconView = null;
        private Animation loadAnimation = null;
        private View loadMoreView = null;

        private LoadMoreViewHolder(View itemView) {
            super(itemView);
            iconView = itemView.findViewById(R.id.refreshlayout_load_more_icon);
            loadAnimation = AnimationUtils.loadAnimation(itemView.getContext(), R.anim.refreshlayout_load_more_cicle);
            loadAnimation.setInterpolator(new LinearInterpolator());
            loadMoreView = itemView.findViewById(R.id.ll_load_more);
        }

        static RecyclerView.ViewHolder getInstance(ViewGroup parent) {
            LayoutInflater inflater = LayoutInflater.from(parent.getContext());
            return new LoadMoreViewHolder(inflater.inflate(R.layout.refreshlayout_recycle_item_load_more, parent, false));
        }

        void update(boolean visible) {
            iconView.clearAnimation();
            iconView.startAnimation(loadAnimation);
            loadMoreView.setVisibility(visible? VISIBLE : INVISIBLE);
        }
    }

    public class OnScrollListenerImpl extends OnScrollListener {
        @Override
        public void onScrollStateChanged(RecyclerView recyclerView, int newState) {
            super.onScrollStateChanged(recyclerView, newState);
            if (newState == RecyclerView.SCROLL_STATE_IDLE && !recyclerView.canScrollVertically(1)) {
                if (null != loadMoreWrapperAdapter) {
                    if (loadMoreWrapperAdapter.isFullLoad()) {
                        return;
                    }
                    loadMoreWrapperAdapter.setShowLoadMore(true);
                    if (null != onLoadMoreListener) {
                        onLoadMoreListener.onLoadMore();
                    }
                }
            }
        }
    }
}
