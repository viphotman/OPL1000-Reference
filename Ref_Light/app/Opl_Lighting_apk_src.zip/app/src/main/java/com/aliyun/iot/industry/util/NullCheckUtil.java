package com.aliyun.iot.industry.util;

public class NullCheckUtil {

    public static <T> T checkNotNull(T reference) {
        if (reference == null) {
            throw new NullPointerException();
        }
        return reference;
    }
}
