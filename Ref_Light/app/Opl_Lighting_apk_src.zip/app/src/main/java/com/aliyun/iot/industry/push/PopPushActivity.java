package com.aliyun.iot.industry.push;

import android.content.Intent;
import android.os.Bundle;

import com.alibaba.sdk.android.push.AndroidPopupActivity;
import com.aliyun.iot.aep.sdk.log.ALog;

import java.util.Map;

import com.aliyun.iot.industry.page.main.MainActivity;

public class PopPushActivity extends AndroidPopupActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    /**
     * 实现通知打开回调方法，获取通知相关信息
     * @param title     标题
     * @param summary   内容
     * @param extMap    额外参数
     */
    @Override
    protected void onSysNoticeOpened(String title, String summary, Map<String, String> extMap) {
        ALog.d("PopPushActivity","OnMiPushSysNoticeOpened, title: "
                + title + ", content: " + summary + ", extMap: " + extMap);
        gotoMainActivity();
        finish();
    }

    private void gotoMainActivity() {
        Intent in = new Intent(this, MainActivity.class);
        startActivity(in);
    }
}
