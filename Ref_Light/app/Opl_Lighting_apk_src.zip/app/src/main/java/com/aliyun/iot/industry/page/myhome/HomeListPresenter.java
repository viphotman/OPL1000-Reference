package com.aliyun.iot.industry.page.myhome;

import android.os.Handler;
import android.os.Looper;
import android.text.TextUtils;

import com.aliyun.iot.aep.sdk.log.ALog;

import com.aliyun.iot.industry.data.DataCallBack;
import com.aliyun.iot.industry.data.HomeDataSource;
import com.aliyun.iot.industry.module.MyDevicesModule;

import static com.aliyun.iot.industry.util.NullCheckUtil.checkNotNull;

public class HomeListPresenter implements HomeListContract.Presenter {

    String TAG ="HomeListPresenter";
    private final static int TIME_REFRESH = 60 * 1000; // 1 min
    private final Handler mHandler = new Handler(Looper.getMainLooper());
    private HomeListContract.View mView;
    private HomeDataSource mRepository;
    private final Runnable mRefreshRunnable = new Runnable() {
        @Override
        public void run() {
            getMyHomes();
            autoRefresh();
        }
    };

    public HomeListPresenter() {
    }

    public HomeListPresenter(HomeListContract.View mView, HomeDataSource mRepository) {
        this.mView = mView;
        this.mRepository = mRepository;
    }

    @Override
    public void getMyHomes() {

        checkNotNull(mRepository);
        checkNotNull(mView);
        mRepository.getMyHomes(new DataCallBack<MyDevicesModule>() {
            @Override
            public void onSuccess(MyDevicesModule data) {
                if (data != null) {

                    ALog.i(TAG,"data = "+data.toString());
                    //mView.showActivityAddDeviceIcon(data.isOperator());

                    if (data.getList() != null && !data.getList().isEmpty()) {
                        mView.showDeviceList(data.getList());
                    } else {
                        mView.showNoDevice();
                    }
                } else {
                    mView.showNoDevice();
                }
            }

            @Override
            public void onFail(String msg) {

                mView.showNoDevice();
                if (TextUtils.isEmpty(msg)) {
                    mView.showNetworkError();
                } else {
                    mView.toastMessage(msg);
                }
            }
        });

    }


    @Override
    public void startRefresh() {
        autoRefresh();
    }

    private void autoRefresh() {
        mHandler.removeCallbacks(mRefreshRunnable);
        if (mRepository.getAutoRefresh()) {
            mHandler.postDelayed(mRefreshRunnable, TIME_REFRESH);
        }
    }

    @Override
    public void stopRefresh() {
        mHandler.removeCallbacks(mRefreshRunnable);
    }


    @Override
    public String getRole() {
        if (mRepository == null)  return  "";
        return mRepository.getRole();
    }
}
