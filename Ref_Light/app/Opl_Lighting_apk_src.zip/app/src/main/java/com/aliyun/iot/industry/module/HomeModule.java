package com.aliyun.iot.industry.module;

import com.aliyun.iot.industry.base.BaseModule;

public class HomeModule extends BaseModule {




    /**
     * 设备名称
     */
    private String title;
    /**
     * 链接
     */
    private String url;

    private String imageUrl;

    private String des;

    public HomeModule() {
    }



    public String getTitle() {
        return title==null?"页面标题":title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }

    public String getImageUrl() {
        return imageUrl;
    }

    public void setImageUrl(String imageUrl) {
        this.imageUrl = imageUrl;
    }

    public String getDes() {
        return des;
    }

    public void setDes(String des) {
        this.des = des;
    }
}
