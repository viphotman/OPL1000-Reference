package com.aliyun.iot.industry.module;

public class Constants {

    public final static String MESSAGE = "MESSAGE";

    public final static int LABEL_MESSAGE_ALL = 0;
    public final static int LABEL_MESSAGE_READ = 1;
    public final static int LABEL_MESSAGE_UNREAD = 2;
    public final static int LABEL_MESSAGE_MARKED = 3;
    public final static int LABEL_MESSAGE_SEARCH = 4;
    public final static int LABEL_MESSAGE_TOTAL_ALL = 5;

    public final static int ACTION_MESSAGE_REFRESH = 0;
    public final static int ACTION_MESSAGE_MORE = 1;

    public final static String SEARCH_TYPE = "search_type";
    public final static String SEARCH_HINT = "search_hint";
    public final static int SEARCH_TYPE_HOME = 0;
    public final static int SEARCH_TYPE_MESSAGE = 1;
    public final static String SEARCH_KEYWORD = "key_word";
    public final static String MESSAGE_TAB_INDEX = "message_tab_index";

    public static final int MESSAGE_TYPE_UNREAD = 0;
    public static final int MESSAGE_TYPE_READ = 1;
    public static final int MESSAGE_TYPE_UNTAG = 0;
    public static final int MESSAGE_TYPE_TAG = 1;

    public static final String URL_ADD_DEVICES = "https://g.alicdn.com/aic/kinco-h5/0.0.54/device.html";
    public static final String URL_HOME_DETAIL = "https://g.alicdn.com/aic/kinco-h5/0.0.54/system.html";

    // for test
    //public static final String URL_ADD_DEVICES = "http://30.6.98.223:3000/device";
    //public static final String URL_HOME_DETAIL = "http://30.6.98.223:3000/system/0";

    public static final String ACTION_LOGIN_STATUS = "com.aliyun.iot.sdk.LoginStatusChange";
}
