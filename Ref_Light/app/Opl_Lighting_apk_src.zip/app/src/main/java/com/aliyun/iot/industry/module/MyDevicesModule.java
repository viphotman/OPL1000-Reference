package com.aliyun.iot.industry.module;

import com.aliyun.iot.industry.base.BaseModule;

import java.util.List;

public class MyDevicesModule extends BaseModule {

    public static final String PERMISSION_QUERY = "QUERY";
    public static final String PERMISSION_UPDATE = "UPDATE";
    public static final String PERMISSION_DELETE = "DELETE";

    private String perm;

    private List<HomeModule> list;


    public String getPerm() {
        return perm;
    }

    public void setPerm(String perm) {
        this.perm = perm;
    }

    public List<HomeModule> getList() {
        return list;
    }

    public void setList(List<HomeModule> list) {
        this.list = list;
    }

    public MyDevicesModule() {
    }

    @Override
    public String toString() {
        return "MyDevicesModule{" +
                "perm='" + perm + '\'' +
                ", devices=" + list +
                '}';
    }
}
