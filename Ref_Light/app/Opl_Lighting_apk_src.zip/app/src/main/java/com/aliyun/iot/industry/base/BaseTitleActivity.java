package com.aliyun.iot.industry.base;

import android.os.Bundle;
import android.os.PersistableBundle;
import android.support.annotation.Nullable;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.aliyun.iot.industry.R;
import com.aliyun.iot.link.ui.component.LinkToast;

public abstract class BaseTitleActivity extends BaseActivity {


    @Override
    public void onPostCreate(@Nullable Bundle savedInstanceState, @Nullable PersistableBundle persistentState) {
        super.onPostCreate(savedInstanceState, persistentState);
        initBaseListener();
    }

    @Override
    protected void onPostCreate(@Nullable Bundle savedInstanceState) {
        super.onPostCreate(savedInstanceState);
        initBaseListener();
    }

    @Override
    public void toastMessage(String msg) {
        LinkToast.makeText(this, msg, Toast.LENGTH_LONG).show();
    }

    public void setTitle(int resId) {

        setTitle(getString(resId));
    }

    public void setTitle(String title) {
        TextView tvTitle = findViewById(R.id.title_bar_title_tv);
        if (tvTitle != null) {
            tvTitle.setText(title);
        }
    }

    private void initBaseListener() {
        ImageView backIv = findViewById(R.id.title_bar_back_iv);

        if (backIv != null) {
            backIv.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    onBackPressed();
                }
            });
        }
    }
}
