package com.aliyun.iot.industry.util;

import com.aliyun.iot.industry.base.BaseApplication;

public class StringUtil {

    public static String getString(int resId) {
        String s = "";
        try {
            s = BaseApplication.getInstance().getString(resId);
        } catch (Exception e) {
            // do nothing
        }
        return s;
    }
}
