package com.aliyun.iot.industry.base;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.content.LocalBroadcastManager;

import com.aliyun.iot.aep.sdk.log.ALog;
import com.aliyun.iot.aep.sdk.login.LoginBusiness;

import static com.aliyun.iot.industry.module.Constants.ACTION_LOGIN_STATUS;

public abstract class LoginStatusFragment extends BaseFragment {

    private BroadcastReceiver mLoginStatusReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            if (LoginBusiness.isLogin()) {
                ALog.d(TAG, "login:" + intent);
                if (getActivity() == null || getActivity().isFinishing() || !isAdded()) return;

                onLogin();

            } else {
                ALog.d(TAG, "logout:" + intent);
                if (getActivity() == null || getActivity().isFinishing() || !isAdded()) return;

                onLogout();
            }
        }
    };

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        LocalBroadcastManager.getInstance(getContext()).
                registerReceiver(mLoginStatusReceiver, new IntentFilter(ACTION_LOGIN_STATUS));

    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        if (mLoginStatusReceiver != null) {
            LocalBroadcastManager.getInstance(getContext()).unregisterReceiver(mLoginStatusReceiver);
            mLoginStatusReceiver = null;
        }
    }

    public abstract void onLogin();
    public abstract void onLogout();
}
