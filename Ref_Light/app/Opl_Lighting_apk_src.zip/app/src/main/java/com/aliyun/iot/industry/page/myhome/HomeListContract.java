package com.aliyun.iot.industry.page.myhome;

import java.util.List;

import com.aliyun.iot.industry.base.BasePresenter;
import com.aliyun.iot.industry.base.BaseView;
import com.aliyun.iot.industry.module.HomeModule;

public interface HomeListContract {

    interface View extends BaseView {

        void showActivityAddDeviceIcon(boolean show);

        void showDeviceList(List<HomeModule> list);

        void showNoDevice();

        void showNetworkError();

    }

    interface Presenter extends BasePresenter {

        void getMyHomes();

        void startRefresh();

        void stopRefresh();

        String getRole();
    }
}
