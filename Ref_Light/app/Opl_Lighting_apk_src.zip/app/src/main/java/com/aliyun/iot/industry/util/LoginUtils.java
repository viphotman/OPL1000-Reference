package com.aliyun.iot.industry.util;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;

import com.alibaba.sdk.android.openaccount.ui.LayoutMapping;
import com.alibaba.sdk.android.openaccount.ui.OpenAccountUIConfigs;
import com.aliyun.iot.aep.oa.OAUIInitHelper;
import com.aliyun.iot.aep.oa.page.OALoginActivity;
import com.aliyun.iot.aep.oa.page.OAMobileCountrySelectorActivity;
import com.aliyun.iot.aep.oa.page.OARegisterActivity;
import com.aliyun.iot.aep.oa.page.OARegisterFillPasswordActivity;
import com.aliyun.iot.aep.oa.page.OAResetPasswordActivity;
import com.aliyun.iot.aep.oa.page.OAResetPasswordFillPasswordActivity;
import com.aliyun.iot.aep.sdk.login.ILoginCallback;
import com.aliyun.iot.aep.sdk.login.ILogoutCallback;
import com.aliyun.iot.aep.sdk.login.LoginBusiness;
import com.aliyun.iot.aep.sdk.threadpool.ThreadPool;

import com.aliyun.iot.industry.R;
import com.aliyun.iot.industry.base.BaseApplication;
import com.aliyun.iot.industry.page.main.MainActivity;
import com.aliyun.iot.industry.page.main.MyOAResetPasswordActivity;

public class LoginUtils {

    public static void logout() {
        ThreadPool.MainThreadHandler.getInstance().post(new Runnable() {
            @Override
            public void run() {
                logout(BaseApplication.getInstance(), MainActivity.class);
            }
        });
    }

    public static void logout(final Context context, final Class z) {


        LoginBusiness.logout(new ILogoutCallback() {
            @Override
            public void onLogoutSuccess() {

                login(context, z);
                BaseApplication.finishAllMyActivitiesQuietly();

            }

            @Override
            public void onLogoutFailed(int i, String s) {

                login(context, z);
                BaseApplication.finishAllMyActivitiesQuietly();

            }
        });
    }

    public static void login() {
        login(null, null);
    }


    public static void login(final Context context, final Class z) {
//        隐藏地区选择
        OpenAccountUIConfigs.AccountPasswordLoginFlow.supportForeignMobileNumbers = false;
        OpenAccountUIConfigs.ChangeMobileFlow.supportForeignMobileNumbers = false;
        OpenAccountUIConfigs.MobileRegisterFlow.supportForeignMobileNumbers = false;
        OpenAccountUIConfigs.MobileResetPasswordLoginFlow.supportForeignMobileNumbers = false;
        OpenAccountUIConfigs.OneStepMobileRegisterFlow.supportForeignMobileNumbers = false;

        LayoutMapping.put(OALoginActivity.class, R.layout.kinco_ali_sdk_openaccount_login2);
        LayoutMapping.put(OARegisterActivity.class, R.layout.kinco_ali_sdk_openaccount_register2);
        LayoutMapping.put(OARegisterFillPasswordActivity.class, R.layout.kinco_ali_sdk_openaccount_register_fill_password2);
        LayoutMapping.put(MyOAResetPasswordActivity.class, R.layout.kinco_ali_sdk_openaccount_reset_password2);
        LayoutMapping.put(OAResetPasswordFillPasswordActivity.class, R.layout.kinco_ali_sdk_openaccount_reset_password_fill_password2);
        LayoutMapping.put(OAMobileCountrySelectorActivity.class, R.layout.kinco_ali_sdk_openaccount_mobile_country_selector2);

        OAUIInitHelper.setCustomSelectCountryActivityUIConfig(com.aliyun.iot.industry.page.account.OAMobileCountrySelectorActivity.class);


        //OpenAccountUIConfigs.MobileRegisterFlow.registerFillPasswordActivityClazz = OARegisterFillPasswordActivity.class;
        OpenAccountUIConfigs.UnifyLoginFlow.resetPasswordActivityClass = MyOAResetPasswordActivity.class;


        if (LoginBusiness.isLogin()) {
            gotoActivity(context, z);
            return;
        }

        LoginBusiness.login(new ILoginCallback() {
            @Override
            public void onLoginSuccess() {
                gotoActivity(context, z);
            }

            @Override
            public void onLoginFailed(int i, String s) {

                // do nothing
            }
        });

    }

    private static void gotoActivity(Context context, Class z) {
        if (context == null || z == null) return;

        try {
            Intent in = new Intent(context, z);
            if (!(context instanceof Activity)) {
                in.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            }
            context.startActivity(in);
        } catch (Exception e) {
            // do nothing
        }

    }

}
