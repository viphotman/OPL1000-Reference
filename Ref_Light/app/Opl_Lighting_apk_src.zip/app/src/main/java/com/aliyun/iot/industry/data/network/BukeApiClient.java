package com.aliyun.iot.industry.data.network;

import android.text.TextUtils;

import com.alibaba.fastjson.JSON;
import com.aliyun.iot.aep.sdk.apiclient.IoTAPIClient;
import com.aliyun.iot.aep.sdk.apiclient.IoTAPIClientFactory;
import com.aliyun.iot.aep.sdk.apiclient.callback.IoTCallback;
import com.aliyun.iot.aep.sdk.apiclient.callback.IoTResponse;
import com.aliyun.iot.aep.sdk.apiclient.request.IoTRequest;
import com.aliyun.iot.aep.sdk.apiclient.request.IoTRequestBuilder;
import com.aliyun.iot.aep.sdk.log.ALog;
import com.aliyun.iot.aep.sdk.threadpool.ThreadPool;
import com.aliyun.iot.industry.data.BaseDataCallBack;
import com.aliyun.iot.industry.module.HomeModule;
import com.aliyun.iot.industry.module.MyDevicesModule;

import java.lang.reflect.ParameterizedType;
import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

public class BukeApiClient {

    private static final String PATH_MESSAGE_COUNT = "/message/center/record/messagetype/count";
    private static final String PATH_MESSAGE_QUERY = "/message/center/record/query";
    private static final String PATH_MESSAGE_DELETE = "/message/center/record/delete";
    private static final String PATH_MESSAGE_MODIFY = "/message/center/record/modify";
//    /industry/device/list   /device/center/queryDeviceList
    private static final String PATH_HOME_QUERY = "/app/mobile/manifest/template/home";
    private static final String PATH_SEND_SHORT_MESSAGE = "/industry/verifycode/send";
    private static final String PATH_DEVICE_BIND="/industry/device/bind";
    private static String TAG="BukeApiClient";

    public static void send(final BaseRequest req, final BaseDataCallBack dataCallBack) {
        if (req == null) return;

        // get the mapping Class for return value
        Type type = null;
        try {
            if (dataCallBack != null) {
                type = ((ParameterizedType) (dataCallBack.getClass().getGenericSuperclass())).getActualTypeArguments()[0];
            }
        } catch (Exception e) {
            // do nothing
        }
        final Class mappingClazz = (Class) type;

        Map<String, Object> params = req.getParams();

        IoTRequestBuilder builder = new IoTRequestBuilder()
                .setScheme(req.getScheme())
                .setPath(req.getPath())
                .setAuthType("iotAuth")
                .setApiVersion(req.getApiVersion());

        if (params != null && !params.isEmpty()) {
            builder.setParams(params);
        }

        if (!TextUtils.isEmpty(req.getHost())) {
            builder.setHost(req.getHost());
        }

        IoTRequest request = builder.build();

        IoTAPIClient ioTAPIClient = new IoTAPIClientFactory().getClient();


        ioTAPIClient.send(request, new IoTCallback() {
            @Override
            public void onFailure(IoTRequest request, final Exception e) {

                if (dataCallBack != null) {
                    ThreadPool.MainThreadHandler.getInstance().post(new Runnable() {
                        @Override
                        public void run() {
                            dataCallBack.onFail(e.getLocalizedMessage());
                        }
                    });
                }
            }

            @Override
            public void onResponse(IoTRequest request, final IoTResponse response) {
                if (dataCallBack == null) return;

                ThreadPool.MainThreadHandler.getInstance().post(new Runnable() {
                    @Override
                    public void run() {
                        if (response == null || (response.getCode() != 200)) {

                            dataCallBack.onFail(response == null ? "" : response.getLocalizedMsg());
                            // do the logout when onIoTTokenInvalid
//                            if (response != null && (response.getCode() == 401 || response.getCode()==460)) {
//                                //LoginUtils.logout();
//                            }
                            return;
                        }
                        if (response.getData() != null) {
                            Object object = null;
                            try {
                                String s = response.getData().toString();
                                //Log.d(TAG,"s= "+s);
                                object = JSON.parseObject(s, mappingClazz);
                            } catch (Exception e) {
                                // do nothing
                                ALog.e(TAG,"Exception: "+e.toString());
                            }
                            dataCallBack.onSuccess(object);

                        } else {
                            dataCallBack.onSuccess(null);
                        }

                    }
                });
            }

        });
    }

    public static void homeQuery(BaseDataCallBack dataCallBack) {
        BaseRequest baseRequest = new BaseRequest();
        baseRequest.setPath(PATH_HOME_QUERY);
        baseRequest.setApiVersion("1.4.0");
        send(baseRequest, dataCallBack);
        //mockData(dataCallBack);
    }

    public static void sendShortMessage(String phoneNum,BaseDataCallBack callBack){
        SendShortMessageRequest request = new SendShortMessageRequest(phoneNum);
        BaseRequest baseRequest = new BaseRequest();
        baseRequest.setData(request);
        baseRequest.setPath(PATH_SEND_SHORT_MESSAGE);
        baseRequest.setApiVersion("1.0.5");
        send(baseRequest,callBack);
    }

    public static void deviceBind(DeviceBindRequest request,BaseDataCallBack dataCallBack){
        BaseRequest baseRequest = new BaseRequest();
        baseRequest.setPath(PATH_DEVICE_BIND);
        baseRequest.setData(request);
        baseRequest.setApiVersion("1.0.5");
        send(baseRequest,dataCallBack);
    }

    private static void mockData(BaseDataCallBack dataCallBack) {
        MyDevicesModule myDevicesModule = new MyDevicesModule();
        List<HomeModule> list = new ArrayList<>();

        HomeModule module1 = new HomeModule();
        module1.setTitle("title1");
        module1.setDes("des1");
        module1.setUrl("www.baidu.com");
        module1.setImageUrl("https://work.alibaba-inc.com/photo/59522.220x220.jpg");
        list.add(module1);

        HomeModule module2 = new HomeModule();
        module2.setTitle("title2");
        module2.setDes("des2");
        module2.setUrl("www.google.com");
        module2.setImageUrl("");
        list.add(module2);

        myDevicesModule.setList(list);
        dataCallBack.onSuccess(myDevicesModule);
    }
}
