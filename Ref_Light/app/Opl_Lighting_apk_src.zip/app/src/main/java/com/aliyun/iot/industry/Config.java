package com.aliyun.iot.industry;

public class Config {

    public static final boolean DEBUG = false;
    public static final String DEFAULT_HOST = "api.link.aliyun.com";
    public static final String DEFAULT_OA_HOST = " ";
    public static final String ENV = "release";

}
