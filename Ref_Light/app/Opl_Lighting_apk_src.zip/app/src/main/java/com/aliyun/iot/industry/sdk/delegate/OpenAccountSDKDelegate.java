package com.aliyun.iot.industry.sdk.delegate;

import android.app.Application;
import android.content.Context;
import android.content.Intent;
import android.text.TextUtils;

import com.alibaba.sdk.android.openaccount.ConfigManager;
import com.alibaba.sdk.android.openaccount.ui.LayoutMapping;
import com.aliyun.iot.aep.oa.OAUIInitHelper;
import com.aliyun.iot.aep.sdk.framework.sdk.SDKConfigure;
import com.aliyun.iot.aep.sdk.framework.sdk.SimpleSDKDelegateImp;
import com.aliyun.iot.aep.sdk.log.ALog;
import com.aliyun.iot.aep.sdk.login.LoginBusiness;
import com.aliyun.iot.aep.sdk.login.oa.OALoginAdapter;
import com.aliyun.iot.industry.R;
import com.aliyun.iot.industry.page.main.MyOAResetPasswordActivity;
import com.aliyun.iot.industry.util.BroadCastUtil;

import java.util.Map;

/**
 * Created by wuwang on 2017/10/30.
 */

public final class OpenAccountSDKDelegate extends SimpleSDKDelegateImp {
    static final private String TAG = "OpenAccountSDKDelegate";
    public static final String ACTION_OA_INIT_DONE = "ACTION_OA_INIT_DONE";
    public static final String SUCCESS = "success";
    public final static String ENV_KEY_OPEN_ACCOUNT_HOST = "ENV_KEY_OPEN_ACCOUNT_HOST";

    /* API: ISDKDelegate */

    @Override
    public int init(final Application app, SDKConfigure configure, Map<String, String> args) {

        String env = args == null ? "" : args.get(APIGatewaySDKDelegate.ENV_KEY_API_CLIENT_API_ENV);

        //使用系统默认OA
        ALog.d(TAG, "init start");
        String host = args == null ? "" : args.get(ENV_KEY_OPEN_ACCOUNT_HOST);

        //使用系统默认OA
        OALoginAdapter loginAdapter = new OALoginAdapter(app);
        if (host != null && !TextUtils.isEmpty(host.trim())) {
            loginAdapter.setDefaultOAHost(host);
        }

        loginAdapter.init(env, null, new OALoginAdapter.OALoginAdapterInitResultCallback() {
            @Override
            public void onInitSuccess() {
                ALog.d(TAG, "onInitSuccess");
                broadcastOAInitDone(app,true);
            }

            @Override
            public void onInitFailed(int i, String s) {
                ALog.d(TAG, "onInitFailed:" + i + s);
                broadcastOAInitDone(app,false);

            }
        });
        LayoutMapping.put(MyOAResetPasswordActivity.class, R.layout.kinco_ali_sdk_openaccount_change_password2);
//        OAUIInitHelper.setCustomLoginActivityUIConfig(loginAdapter,null,BKLoginActivity.class);  设置login 页面
        LoginBusiness.init(app, loginAdapter, true, env);
        OAUIInitHelper.initConfig(loginAdapter, false, null);

        ConfigManager.getInstance().setBundleName("com.aliyun.iot.industry");

        return 0;
    }

    private void broadcastOAInitDone(Context context, boolean success) {
        Intent intent = new Intent(ACTION_OA_INIT_DONE);
        intent.putExtra(SUCCESS, success);

        BroadCastUtil.broadCastSticky(context, intent);
    }


}
