package com.aliyun.iot.industry.page.main;

import android.os.Bundle;
import android.widget.Button;

import com.aliyun.iot.aep.oa.page.OAResetPasswordActivity;
import com.aliyun.iot.industry.R;

public class MyOAResetPasswordActivity extends OAResetPasswordActivity {
    @Override
    protected void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        Button send = findViewById(R.id.send);
        if (send!=null)
            send.setTextColor(getResources().getColor(R.color.industry_common_background));
    }
}
