package com.aliyun.iot.industry.base;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.res.Resources;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.content.LocalBroadcastManager;
import android.widget.Toast;

import com.aliyun.iot.aep.sdk.framework.AActivity;
import com.aliyun.iot.aep.sdk.log.ALog;
import com.aliyun.iot.link.ui.component.LinkToast;

public abstract class BaseActivity extends AActivity implements com.aliyun.iot.industry.base.BaseView {

    public static final String QUIT_ACTION = "QUIT_ACTION";
    public static final String QUIT_TIME = "QUIT_TIME";
    public String TAG = "BaseActivity";
    private LocalBroadcastManager localBroadcastManager;
    private BroadcastReceiver quitReceiver = new MyBroadcastReceiver();
    private long mCreateTime = 0;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        TAG = this.getClass().getSimpleName();
        ALog.d(TAG, "onCreate");
        mCreateTime = System.currentTimeMillis();
        localBroadcastManager = LocalBroadcastManager.getInstance(this);

        localBroadcastManager.registerReceiver(quitReceiver, new IntentFilter(QUIT_ACTION));

    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        ALog.d(TAG, "onNewIntent");
        mCreateTime = System.currentTimeMillis();
    }

    @Override
    protected void onDestroy() {
        ALog.d(TAG, "onDestroy");
        super.onDestroy();
        localBroadcastManager.unregisterReceiver(quitReceiver);
    }

    @Override
    public void toastMessage(String msg) {
        LinkToast.makeText(this, msg, Toast.LENGTH_LONG).show();
    }

    public void quitApp() {
        if (localBroadcastManager != null) {
            Intent intent = new Intent(QUIT_ACTION);
            final long quitTime= System.currentTimeMillis();
            intent.putExtra(QUIT_TIME, quitTime);
            localBroadcastManager.sendBroadcast(intent);
        }
    }

    private class MyBroadcastReceiver extends BroadcastReceiver {

        @Override
        public void onReceive(Context context, Intent intent) {
            if (context == null || intent == null) return;
            String action = intent.getAction();
            long quitTime = intent.getLongExtra(QUIT_TIME, 0);
            if (QUIT_ACTION.equals(action)) {
                if (isFinishing()) return;
                if (mCreateTime != 0 && mCreateTime < quitTime){
                    ALog.d(TAG, "finish:"+ BaseActivity.this);
                    finish();
                }
            }

        }
    }

    public Resources getRes() {
        Resources res = null;
        try {
            res = getResources();
        } catch (Exception e) {
            // do nothing
        }
        if (res == null) {
            res = BaseApplication.getInstance().getResources();
        }
        return res;
    }

}
