package com.aliyun.iot.industry.page.view;

import android.content.Context;
import android.support.annotation.Nullable;
import android.util.AttributeSet;
import android.widget.ImageView;
import android.widget.TextView;

import com.aliyun.iot.industry.R;
import com.aliyun.iot.industry.base.BaseModule;
import com.aliyun.iot.industry.base.GlideApp;
import com.aliyun.iot.industry.base.OnItemClickListener;
import com.aliyun.iot.industry.module.HomeModule;

public class DeviceViewIndustry extends ItemView {
    public DeviceViewIndustry(Context context) {
        super(context);
    }
    public DeviceViewIndustry(Context context, @Nullable AttributeSet attrs) {
        super(context, attrs);
    }

    public DeviceViewIndustry(Context context, @Nullable AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
    }

    @Override
    public void bindDataToView(final BaseModule item, final OnItemClickListener listener) {
        HomeModule deviceModule = (HomeModule) item;

        TextView titleTV = findViewById(R.id.page_title);
        titleTV.setText(deviceModule.getTitle());

        TextView desTv = findViewById(R.id.page_des);
        desTv.setText(deviceModule.getDes());

        ImageView iconIv = findViewById(R.id.image_icon);
        GlideApp.with(this).load(deviceModule.getImageUrl())
                .fitCenter().placeholder(R.drawable.ic_default_page).into(iconIv);
    }
}
