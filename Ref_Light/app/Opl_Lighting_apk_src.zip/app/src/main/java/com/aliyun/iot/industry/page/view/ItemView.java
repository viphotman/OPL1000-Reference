package com.aliyun.iot.industry.page.view;

import android.content.Context;
import android.support.annotation.Nullable;
import android.util.AttributeSet;
import android.widget.LinearLayout;

import com.aliyun.iot.industry.base.BaseModule;
import com.aliyun.iot.industry.base.OnItemClickListener;


public abstract class ItemView<T extends BaseModule> extends LinearLayout {

    public ItemView(Context context) {
        super(context);
    }

    public ItemView(Context context, @Nullable AttributeSet attrs) {
        super(context, attrs);
    }

    public ItemView(Context context, @Nullable AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
    }


    abstract public void bindDataToView(T item, OnItemClickListener listener);
}
