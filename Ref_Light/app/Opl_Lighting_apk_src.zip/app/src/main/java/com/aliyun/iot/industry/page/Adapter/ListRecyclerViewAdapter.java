package com.aliyun.iot.industry.page.Adapter;

import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.aliyun.iot.industry.base.BaseModule;
import com.aliyun.iot.industry.base.OnItemClickListener;
import com.aliyun.iot.industry.page.myhome.HomeListFragment.OnListFragmentInteractionListener;
import com.aliyun.iot.industry.page.view.ItemView;

import java.util.List;

/**
 * {@link RecyclerView.Adapter} that can display a {@link BaseModule} and makes a call to the
 * specified {@link OnListFragmentInteractionListener}.
 */
public class ListRecyclerViewAdapter<T extends BaseModule> extends RecyclerView.Adapter<ListRecyclerViewAdapter.ViewHolder> {

    private final OnItemClickListener mListener;
    private final int mResLayoutId;
    private List<T> mValues;

    public ListRecyclerViewAdapter(List<T> items, int resLayoutId, OnItemClickListener listener) {
        mValues = items;
        mListener = listener;
        mResLayoutId = resLayoutId;
    }

    public void setList(List<T> list) {
        mValues = list;
        notifyDataSetChanged();
    }

    public List<T> getList() {
        return mValues;
    }

    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        ItemView view = (ItemView) LayoutInflater.from(parent.getContext())
                .inflate(mResLayoutId, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(final ViewHolder holder, int position) {
        holder.setItem(mValues.get(position));


        holder.mView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (null != mListener) {
                    mListener.onListItemClick(holder.mItem);
                }
            }
        });

        holder.mView.setOnLongClickListener(new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View view) {
                mListener.onListItemLongClick(view, holder.mItem);
                return true;
            }
        });

    }

    @Override
    public int getItemCount() {
        return mValues.size();
    }

    public class ViewHolder<M extends BaseModule> extends RecyclerView.ViewHolder {
        private final ItemView mView;

        public M mItem;

        ViewHolder(ItemView view) {
            super(view);
            mView = view;
        }

        private void setItem(M item) {
            mItem = item;

            if (mItem == null) return;
            mView.bindDataToView(item, mListener);

        }


        @Override
        public String toString() {
            return super.toString() + " '" + mItem + "'";
        }
    }
}
