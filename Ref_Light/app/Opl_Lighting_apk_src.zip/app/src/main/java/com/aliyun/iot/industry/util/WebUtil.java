package com.aliyun.iot.industry.util;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;

import com.aliyun.alink.sdk.bone.plugins.BaseBoneAPIRegister;
import com.aliyun.alink.sdk.jsbridge.BonePluginRegistry;
import com.aliyun.iot.aep.component.router.IUrlHandler;
import com.aliyun.iot.aep.component.router.Router;
import com.aliyun.iot.aep.component.router.RouterRequest;
import com.aliyun.iot.aep.page.briage.BoneBridge;
import com.aliyun.iot.industry.page.web.WebActivity;

import java.net.URLDecoder;


public class WebUtil {

    public static void gotoUrl(String url, Activity activity, Bundle bundle, int requestCode) {
        Intent intent = new Intent(activity, WebActivity.class);
        if (bundle != null) {
            intent.putExtras(bundle);
        }
        Uri uriPass = Uri.parse(url);
        if (uriPass != null) {
            intent.setData(uriPass);
        }
        activity.startActivityForResult(intent, requestCode);
        //Router.getInstance().toUrlForResult(activity, code, 1, bundle);
    }

    public static final void initWebRouter(){
        //plugin register
        new BaseBoneAPIRegister().register();
        BonePluginRegistry.register(BoneBridge.TAG, BoneBridge.class);
        //register router
        Router.getInstance().addUrlInterceptor(new Router.UrlInterceptor() {
            @Override
            public RouterRequest onIntercept(RouterRequest routerRequest) {
                String url = routerRequest.getUrl();
                if(url.contains("link://boneweb/code?")){
                    routerRequest.setUrl("link://page/web");
                    Bundle bundle = new Bundle();
                    bundle.putString("url", URLDecoder.decode(url.substring(url.indexOf("=") + 1)));
                    routerRequest.setBundle(bundle);
                }
                return routerRequest;
            }
        });
        Router.getInstance().registerModuleUrlHandler("link://page/web", new IUrlHandler() {
            @Override
            public void onUrlHandle(Context context, String s, Bundle bundle, boolean b, int i) {
                Uri uri = null;
                try {
                    uri = Uri.parse(s);
                } catch (Exception e) {
                    e.printStackTrace();
                }

                if (null == uri) {
                    return;
                }

                Intent intent = new Intent(context, WebActivity.class);

                if (null != bundle) {
                    intent.setData(Uri.parse(bundle.getString("url")));
                }

                if (b && context instanceof Activity) {
                    ((Activity) context).startActivityForResult(intent, i);
                    return;
                }
                context.startActivity(intent);
            }
        });
    }
}
