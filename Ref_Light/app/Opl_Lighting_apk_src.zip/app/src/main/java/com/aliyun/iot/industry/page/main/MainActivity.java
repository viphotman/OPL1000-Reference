package com.aliyun.iot.industry.page.main;

import android.content.Intent;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.View;

import com.aliyun.iot.industry.R;
import com.aliyun.iot.industry.base.BaseActivity;
import com.aliyun.iot.industry.page.myhome.HomeListFragment;
import com.aliyun.iot.industry.page.settings.SettingsAccountActivity;
import com.aliyun.iot.industry.util.LoginUtils;
import com.aliyun.iot.industry.widget.BottomDialog;
import com.aliyun.iot.industry.widget.CustomViewPager;
import com.aliyun.iot.industry.widget.TabLayoutView;
import com.aliyun.iot.industry.widget.ViewPagerAdapter;

import java.util.Arrays;

public class MainActivity extends BaseActivity
        implements HomeListFragment.OnListFragmentInteractionListener {
    private final static int TAB_MESSAGE = 1;

    private TabLayoutView tabLayoutView;
    public static final String TAG_EXIT = "exit";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        LoginUtils.login();

        final CustomViewPager viewPager = findViewById(R.id.viewpager);
        tabLayoutView = findViewById(R.id.tabview);
        initTabLayout(viewPager);
        tabLayoutView.setVisibility(View.GONE);
    }

    private void initTabLayout(final CustomViewPager viewPager) {
        if (viewPager == null) return;

        final String[] titles = {getRes().getString(R.string.title_home)};
        final int[] drawables = {R.drawable.tab_device_btn};
        final Fragment[] fragments = {HomeListFragment.newInstance()};

        ViewPagerAdapter viewPagerAdapter = new ViewPagerAdapter(getSupportFragmentManager(), Arrays.asList(fragments));
        viewPager.setAdapter(viewPagerAdapter);

        tabLayoutView.setDataSource(titles, drawables);
        tabLayoutView.setTextColor(R.color.device_unselect, R.color.device_select);
        tabLayoutView.initDatas();
        tabLayoutView.setOnItemOnclickListener(new TabLayoutView.OnItemOnclickListener() {
            @Override
            public void onItemClick(int index) {
                viewPager.setCurrentItem(index, true);
            }
        });
        viewPager.setTabs(tabLayoutView);

    }


    public void showMsgUnRead(boolean show) {
        tabLayoutView.showDot(TAB_MESSAGE, show);
    }

    @Override
    public void onMoreOption() {

        popMoreOption();
    }


    private void popMoreOption() {
        final BottomDialog bottomDialog = new BottomDialog(this,
                R.layout.bottom_dialog_more_options);
        bottomDialog.show();

        bottomDialog.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (view == null) return;
                Class c = null;
                switch (view.getId()) {
                    case R.id.btn_account_settings:
                        c = SettingsAccountActivity.class;
                        break;
                    default:
                        break;

                }

                if (c != null) {
                    Intent intent = new Intent(MainActivity.this, c);
                    startActivity(intent);
                }
            }
        });

    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        if (intent != null) {
            boolean isExit = intent.getBooleanExtra(TAG_EXIT, false);
            if (isExit) {
                this.finish();
            }
        }
    }

}
