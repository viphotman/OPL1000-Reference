package com.aliyun.iot.industry.base;

import android.content.Context;
import android.content.res.Resources;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;

import com.aliyun.iot.aep.sdk.log.ALog;

public abstract class BaseFragment extends Fragment implements BaseView {
    public String TAG = "BaseFragment";

    private BaseActivity mActivity = null;
    public BaseFragment() {
    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        if (context instanceof BaseActivity) {
            mActivity = (BaseActivity) context;
        } else {
            throw new RuntimeException(context.toString()
                    + " must attach to BaseActivity");
        }
    }

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        TAG = this.getClass().getSimpleName();
        ALog.d(TAG, "onCreate");

    }

    @Override
    public void toastMessage(String msg) {

        if (mActivity != null && isAdded() && !mActivity.isFinishing()) {
            mActivity.toastMessage(msg);
        }

    }


    @Override
    public void onDetach() {
        super.onDetach();
        mActivity = null;
    }

    public Resources getRes() {
        Resources res = null;
        try {
            if (mActivity != null && isAdded() && !mActivity.isFinishing()) {
                res = mActivity.getResources();
            }
            if (res == null) {
                res = getResources();
            }
        } catch (Exception e) {
            // do nothing
        }
        if (res == null) {
            res = BaseApplication.getInstance().getResources();
        }
        return res;
    }

}
