package com.aliyun.iot.industry.page.web;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.support.annotation.NonNull;
import android.text.SpannableString;
import android.text.Spanned;
import android.text.TextPaint;
import android.text.method.LinkMovementMethod;
import android.text.style.ClickableSpan;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.WebViewClient;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.aliyun.iot.aep.sdk.core.BoneInterfaceImpl;
import com.aliyun.iot.aep.sdk.core.IBoneWebView;
import com.aliyun.iot.aep.sdk.enginer.BoneWebView;
import com.aliyun.iot.aep.sdk.log.ALog;
import com.aliyun.iot.industry.R;

import org.json.JSONException;
import org.json.JSONObject;


public class WebActivity extends Activity {
    public static String TAG = "WebActivity";

    protected IBoneWebView appView;
    protected boolean keepRunning = true;

    protected String launchUrl;
    protected BoneInterfaceImpl cordovaInterface;

    private ProgressHandler progressHandler = new ProgressHandler();

    private RelativeLayout relativeLayout;
    private ImageView backBtn;

    private ProgressBar mProgressBar;

    private BoneWebView mWebview;

    private RelativeLayout loadErrorLayout;
    private TextView reloadTV;


    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_web);
        ALog.setLevel(ALog.LEVEL_DEBUG);
        relativeLayout = (RelativeLayout) findViewById(R.id.activity_web_container);
        loadErrorLayout = (RelativeLayout) findViewById(R.id.webview_load_error_layout);
        backBtn = (ImageView) findViewById(R.id.activity_web_close);
        reloadTV = (TextView) findViewById(R.id.webview_load_error_tips);
        mProgressBar = (ProgressBar) findViewById(R.id.activity_web_progressbar);
        backBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                WebActivity.this.finish();
            }
        });
        cordovaInterface = makeCordovaInterface();

        String url = "";
        Intent intent = getIntent();
        if (null != intent.getData()) {
            url = intent.getData().toString();
        }
        Bundle bundle = getIntent().getExtras();
        if (null != bundle && !bundle.isEmpty()) {
            StringBuffer urlBuffer = new StringBuffer(url);
            urlBuffer.append("?");
            for (String key : bundle.keySet()) {
                urlBuffer.append(key)
                        .append("=")
                        .append(bundle.get(key))
                        .append("&");
            }
            url = urlBuffer.substring(0, urlBuffer.length() - 1);
        }
        launchUrl = url;
        mWebview = new BoneWebView(this);
        appView = mWebview.init(cordovaInterface, null);
        createViews();
        mWebview.load(launchUrl);
    }


    //Suppressing warnings in AndroidStudio
    @SuppressWarnings({"deprecation", "ResourceType"})
    protected void createViews() {
        appView.getView().setId(100);
        appView.getView().setLayoutParams(new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT));
        relativeLayout.addView(appView.getView());
        appView.getView().requestFocusFromTouch();
    }

    private class ProgressHandler extends Handler {

        @Override
        public void handleMessage(Message msg) {
            //update progress
            int progress = (int) msg.obj;
            if (progress == 100) {
                //hide
                mProgressBar.setVisibility(View.GONE);
            } else {
                //update
                if (mProgressBar.getVisibility() == View.GONE) {
                    mProgressBar.setVisibility(View.VISIBLE);
                }
                mProgressBar.setProgress(progress);
            }
        }
    }

    protected BoneInterfaceImpl makeCordovaInterface() {
        return new BoneInterfaceImpl(this) {
            @Override
            public Object onMessage(String id, Object data) {
                return WebActivity.this.onMessage(id, data);
            }
        };
    }

    @Override
    protected void onPause() {
        super.onPause();
        ALog.d(TAG, "Paused the activity.");

        if (this.appView != null) {
            boolean keepRunning = this.keepRunning || this.cordovaInterface.activityResultCallback != null;
            this.appView.handlePause(keepRunning);
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        ALog.d(TAG, "Resumed the activity.");

        if (this.appView == null) {
            return;
        }
        this.getWindow().getDecorView().requestFocus();

        this.appView.handleResume(this.keepRunning);
    }

    @Override
    protected void onStop() {
        super.onStop();
        ALog.d(TAG, "Stopped the activity.");

        if (this.appView == null) {
            return;
        }
        this.appView.handleStop();
    }

    @Override
    protected void onStart() {
        super.onStart();
        ALog.d(TAG, "Started the activity.");

        if (this.appView == null) {
            return;
        }
        this.appView.handleStart();
    }

    @Override
    public void onDestroy() {
        ALog.d(TAG, "Activity.onDestroy()");
        super.onDestroy();

        if (this.appView != null) {
            appView.handleDestroy();
        }
    }

    @SuppressLint("NewApi")
    @Override
    public void startActivityForResult(Intent intent, int requestCode, Bundle options) {
        cordovaInterface.setActivityResultRequestCode(requestCode);
        super.startActivityForResult(intent, requestCode, options);
    }

    /**
     * Called when an activity you launched exits, giving you the requestCode you started it with,
     * the resultCode it returned, and any additional data from it.
     *
     * @param requestCode The request code originally supplied to startActivityForResult(),
     *                    allowing you to identify who this result came from.
     * @param resultCode  The integer result code returned by the child activity through its setResult().
     * @param intent      An Intent, which can return result data to the caller (various data can be attached to Intent "extras").
     */
    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent intent) {
        ALog.d(TAG, "Incoming Result. Request code = " + requestCode);
        super.onActivityResult(requestCode, resultCode, intent);
        cordovaInterface.onActivityResult(requestCode, resultCode, intent);
    }

    /**
     * Report an error to the host application. These errors are unrecoverable (i.e. the main resource is unavailable).
     * The errorCode parameter corresponds to one of the ERROR_* constants.
     *
     * @param errorCode   The error code corresponding to an ERROR_* value.
     * @param description A String describing the error.
     * @param failingUrl  The url that failed to load.
     */
    public void onReceivedError(final int errorCode, final String description, final String failingUrl) {
        final WebActivity me = this;
        final boolean exit = !(errorCode == WebViewClient.ERROR_HOST_LOOKUP);
//        me.runOnUiThread(new Runnable() {
//            public void run() {
//                if (exit) {
//                    me.appView.getView().setVisibility(View.GONE);
//                    me.displayError("Application Error", description + " (" + failingUrl + ")", "OK", exit);
//                }
//            }
//        });
        setReload();
        loadErrorLayout.setVisibility(View.VISIBLE);
    }

    /**
     * Display an error dialog and optionally exit application.
     */
    public void displayError(final String title, final String message, final String button, final boolean exit) {
        final WebActivity me = this;
        me.runOnUiThread(new Runnable() {
            public void run() {
                try {
                    AlertDialog.Builder dlg = new AlertDialog.Builder(me);
                    dlg.setMessage(message);
                    dlg.setTitle(title);
                    dlg.setCancelable(false);
                    dlg.setPositiveButton(button,
                            new AlertDialog.OnClickListener() {
                                public void onClick(DialogInterface dialog, int which) {
                                    dialog.dismiss();
                                    if (exit) {
                                        finish();
                                    }
                                }
                            });
                    dlg.create();
                    dlg.show();
                } catch (Exception e) {
                    finish();
                }
            }
        });
    }

    /**
     * Called when a message is sent to plugin.
     *
     * @param id   The message id
     * @param data The message data
     * @return Object or null
     */
    public Object onMessage(String id, Object data) {
        if ("onReceivedError".equals(id)) {
            JSONObject d = (JSONObject) data;
            try {
                this.onReceivedError(d.getInt("errorCode"), d.getString("description"), d.getString("url"));
            } catch (JSONException e) {
                e.printStackTrace();
            }
        } else if ("exit".equals(id)) {
            finish();
        } else if ("onPageFinished".equals(id)) {
        } else if ("onPageStarted".equals(id)) {
            //hide error page
            loadErrorLayout.setVisibility(View.GONE);
        } else if ("onProgressChanged".equals(id)) {
            //hide error page
            Message message = Message.obtain();
            message.obj = data;
            progressHandler.sendMessage(message);
        }
        return null;
    }

    private void setReload(){
        String tips = reloadTV.getText().toString();
        SpannableString spannableString = new SpannableString(tips);
        ClickableSpan clickableSpan = new ClickableSpan() {
            @Override
            public void onClick(View widget) {
                mWebview.load(launchUrl);
            }
            @Override
            public void updateDrawState(@NonNull TextPaint ds) {
                super.updateDrawState(ds);
                ds.setColor(getResources().getColor(R.color.industry_common_background));
                ds.setUnderlineText(false);
                ds.clearShadowLayer();
            }
        };
        spannableString.setSpan(clickableSpan,tips.indexOf("刷新重试"),tips.length(), Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
        reloadTV.setText(spannableString);
        reloadTV.setHighlightColor(getResources().getColor(android.R.color.transparent));
        reloadTV.setMovementMethod(LinkMovementMethod.getInstance());
    }
}
