package com.aliyun.iot.industry.data;

import android.text.TextUtils;

import com.aliyun.iot.industry.data.network.BukeApiClient;
import com.aliyun.iot.industry.module.HomeModule;
import com.aliyun.iot.industry.module.MyDevicesModule;

import java.util.ArrayList;
import java.util.List;

import static com.aliyun.iot.industry.util.NullCheckUtil.checkNotNull;


public class HomeRepository implements HomeDataSource {

    private static HomeRepository homeRepository = null;


    private String mPerm;

    private HomeRepository() {
    }

    public static HomeRepository getInstance() {
        if (homeRepository == null) {
            homeRepository = new HomeRepository();
        }

        return homeRepository;
    }

    @Override
    public void getMyHomes(final DataCallBack dataCallBack) {

        checkNotNull(dataCallBack);

        BukeApiClient.homeQuery(new BaseDataCallBack<MyDevicesModule>() {
            @Override
            public void onSuccess(MyDevicesModule data) {

                if (data != null) {
                    mPerm = data.getPerm();
                }

                dataCallBack.onSuccess(data);
            }

            @Override
            public void onFail(String msg) {
                dataCallBack.onFail(msg);
            }
        });
    }

    @Override
    public void searchHomes(final String keyWord, final DataCallBack dataCallBack) {

        checkNotNull(dataCallBack);
        BukeApiClient.homeQuery(new BaseDataCallBack<MyDevicesModule>() {
            @Override
            public void onSuccess(MyDevicesModule data) {

                List<HomeModule> deviceList = null;
                if (data != null) {
                    mPerm = data.getPerm();
                    deviceList = data.getList();
                }
                dataCallBack.onSuccess(filterHomes(deviceList,keyWord));

            }

            @Override
            public void onFail(String msg) {
                dataCallBack.onFail(msg);
            }
        });
    }

    private List<HomeModule> filterHomes(List<HomeModule> homeList, String keyWord) {
        if (TextUtils.isEmpty(keyWord) || homeList == null || homeList.isEmpty()) return null;

        List<HomeModule> list = new ArrayList<>();
        for (HomeModule item : homeList) {
            if (item.getTitle() == null) continue;
            if (item.getTitle().contains(keyWord)) {
                list.add(item);
            }
        }

        return list;
    }

    @Override
    public boolean getAutoRefresh() {
        return LocalData.getDeviceAutoRefresh();
    }

    @Override
    public String getRole() {
        return mPerm;
    }
}
