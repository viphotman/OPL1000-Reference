package com.aliyun.iot.industry.page.main;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.Bundle;
import android.os.Handler;
import android.widget.Toast;

import com.aliyun.iot.aep.sdk.log.ALog;
import com.aliyun.iot.industry.R;
import com.aliyun.iot.industry.base.BaseActivity;
import com.aliyun.iot.industry.sdk.delegate.OpenAccountSDKDelegate;
import com.aliyun.iot.industry.util.BroadCastUtil;
import com.aliyun.iot.industry.util.LoginUtils;
import com.aliyun.iot.link.ui.component.LinkToast;

public class StartActivity extends BaseActivity {

    private static final int TIME_MAX = 800;
    private MyBroadcastReceiver mReceiver = new MyBroadcastReceiver();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_start);
        //registerInitDone();
        countDown();
    }
    private void countDown() {
        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {
                registerInitDone();
            }
        }, TIME_MAX);
    }

    private void gotoLogin() {
        LoginUtils.login(this, MainActivity.class);
    }

    private void registerInitDone() {
        BroadCastUtil.register(this, mReceiver,
                new IntentFilter(OpenAccountSDKDelegate.ACTION_OA_INIT_DONE));
    }

    private class MyBroadcastReceiver extends BroadcastReceiver {

        @Override
        public void onReceive(Context context, Intent intent) {

            if (context == null || intent == null) return;
            String action = intent.getAction();
            if (OpenAccountSDKDelegate.ACTION_OA_INIT_DONE.equals(action)) {
                if (isFinishing()) return;

                if (intent.getBooleanExtra(OpenAccountSDKDelegate.SUCCESS, false)) {
                    gotoLogin();
                } else {
                    ALog.d(TAG, "init fail");
                    LinkToast.makeText(context, "OA init FAILED! Try agin", Toast.LENGTH_LONG)
                            .show();
                }
                finish();

            }

        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        BroadCastUtil.unRegister(this, mReceiver);
    }

}
