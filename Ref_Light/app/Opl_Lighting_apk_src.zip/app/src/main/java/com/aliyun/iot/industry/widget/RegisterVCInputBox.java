package com.aliyun.iot.industry.widget;

import android.content.Context;
import android.util.AttributeSet;
import android.view.View;

import com.alibaba.sdk.android.openaccount.ui.widget.SmsCodeInputBox;

/**
 * 注册验证码输入框
 *  隐藏“发送短信验证码” 左边的竖线
 */
public class RegisterVCInputBox extends SmsCodeInputBox{
    View verticalLine = this.findViewById("viewLine");

    public RegisterVCInputBox(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        if (verticalLine!=null && verticalLine.getVisibility()==VISIBLE)
            verticalLine.setVisibility(GONE);
    }

    @Override
    protected void setViewVisibility(int i, View... views) {
        super.setViewVisibility(i, views);
    }
}
