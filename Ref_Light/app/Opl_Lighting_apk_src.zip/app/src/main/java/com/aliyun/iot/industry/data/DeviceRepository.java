package com.aliyun.iot.industry.data;

import com.aliyun.iot.industry.data.network.BukeApiClient;
import com.aliyun.iot.industry.data.network.DeviceBindRequest;

import static com.aliyun.iot.industry.util.NullCheckUtil.checkNotNull;

public class DeviceRepository implements DeviceDataSource {
    private static DeviceRepository deviceRepository;

    private DeviceRepository() {
    }

    public static DeviceRepository getInstance() {
        if (deviceRepository == null) {
            deviceRepository = new DeviceRepository();
        }

        return deviceRepository;
    }

    @Override
    public void sendShortMessage(String phoneNum, final DataCallBack dataCallBack) {
        checkNotNull(dataCallBack);
        BukeApiClient.sendShortMessage(phoneNum, new BaseDataCallBack() {
            @Override
            public void onSuccess(Object data) {
            }

            @Override
            public void onFail(String msg) {
                dataCallBack.onFail(msg);
            }
        });
    }

    @Override
    public void deviceBind(String productKey, String deviceName, String phoneNumber, String securityCode, final DataCallBack dataCallBack) {
        checkNotNull(dataCallBack);
        DeviceBindRequest request = new DeviceBindRequest(productKey,deviceName,phoneNumber,securityCode);
        BukeApiClient.deviceBind(request, new BaseDataCallBack<Boolean>() {
            @Override
            public void onSuccess(Boolean data) {
                if (data)
                    dataCallBack.onSuccess(data);
                else
                    dataCallBack.onFail("綁定失敗");
            }

            @Override
            public void onFail(String msg) {
                dataCallBack.onFail(msg);
            }
        });
    }
}
