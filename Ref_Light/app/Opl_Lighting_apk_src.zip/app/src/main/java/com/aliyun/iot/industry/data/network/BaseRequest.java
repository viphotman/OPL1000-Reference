package com.aliyun.iot.industry.data.network;

import com.aliyun.iot.aep.sdk.apiclient.emuns.Scheme;

import java.io.Serializable;
import java.util.Map;

import com.aliyun.iot.industry.Config;
import com.aliyun.iot.industry.util.ObjectUtil;

public class BaseRequest<T> implements Serializable {

    T data;
    private Scheme scheme = Scheme.HTTPS;
    private String host = Config.DEFAULT_HOST;
    private String path;
    private String apiVersion = "1.0.4";

    public BaseRequest() {
    }

    public BaseRequest(T data, String path, String apiVersion) {
        this.data = data;
        this.path = path;
        this.apiVersion = apiVersion;
    }

    public Scheme getScheme() {
        return scheme;
    }

    public void setScheme(Scheme scheme) {
        this.scheme = scheme;
    }

    public String getHost() {
        return host;
    }

    public void setHost(String host) {
        this.host = host;
    }

    public String getPath() {
        return path;
    }

    public void setPath(String path) {
        this.path = path;
    }

    public String getApiVersion() {
        return apiVersion;
    }

    public void setApiVersion(String apiVersion) {
        this.apiVersion = apiVersion;
    }

    public T getData() {
        return data;
    }

    public void setData(T data) {
        this.data = data;
    }

    public Map<String, Object> getParams() {
        return ObjectUtil.objectToMap(getData());

    }
}
