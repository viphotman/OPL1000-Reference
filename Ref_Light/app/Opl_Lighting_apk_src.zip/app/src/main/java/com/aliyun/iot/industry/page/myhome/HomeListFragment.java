package com.aliyun.iot.industry.page.myhome;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.aliyun.iot.industry.R;
import com.aliyun.iot.industry.base.LoginStatusFragment;
import com.aliyun.iot.industry.base.OnItemClickListener;
import com.aliyun.iot.industry.data.HomeRepository;
import com.aliyun.iot.industry.module.HomeModule;
import com.aliyun.iot.industry.page.Adapter.ListRecyclerViewAdapter;
import com.aliyun.iot.industry.util.WebUtil;
import com.aliyun.iot.industry.widget.CustomLinearLayoutManager;
import com.aliyun.iot.industry.widget.RefreshRecycleViewLayout;
import com.aliyun.iot.link.ui.component.LinkToast;

import java.util.ArrayList;
import java.util.List;

/**
 * A fragment representing a list of Items.
 * <p/>
 * Activities containing this fragment MUST implement the {@link OnListFragmentInteractionListener}
 * interface.
 */
public class HomeListFragment extends LoginStatusFragment
        implements HomeListContract.View,
        OnItemClickListener<HomeModule>,
        RefreshRecycleViewLayout.OnLoadMoreListener,
        RefreshRecycleViewLayout.OnRefreshListener {


    String TAG ="HomeListFragment";
    private final List<HomeModule> EMPTY_LIST = new ArrayList<>();
    private OnListFragmentInteractionListener mListener;
    private HomeListPresenter mPresenter;
    private ListRecyclerViewAdapter mAdapter;
    private RefreshRecycleViewLayout mRefreshListView;

    private View mRootView;
    private ImageView mAddDeviceIV;
    private ImageView mOptionIv;
    private ImageView mSearchIv;
//    无设备列表，并且是运维人员展示：
    TextView mNoDeviceTv;

    private boolean mIsOperator;

    private static final int REQUEST_CODE_ADD_DEVICE = 10086;
    /**
     * Mandatory empty constructor for the fragment manager to instantiate the
     * fragment (e.g. upon screen orientation changes).
     */
    public HomeListFragment() {
    }


    public static HomeListFragment newInstance() {
        return new HomeListFragment();
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        mPresenter = new HomeListPresenter(this, HomeRepository.getInstance());

    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

        if (mRootView != null) return mRootView;

        mRootView = inflater.inflate(R.layout.fragment_home_list, container, false);

        // Set the adapter
        Context context = mRootView.getContext();
        mRefreshListView = mRootView.findViewById(R.id.list);
        mRefreshListView.setLayoutManager(new CustomLinearLayoutManager(context));
        mAdapter = new ListRecyclerViewAdapter(EMPTY_LIST, R.layout.fragment_home_industry, this);
        mRefreshListView.setAdapter(mAdapter);

        mRefreshListView.setOnLoadMoreListener(this);
        mRefreshListView.setOnRefreshListener(this);
        mRefreshListView.setRefreshing(true);

        mRefreshListView.setEmptyView(R.layout.view_no_home);
        mNoDeviceTv = mRefreshListView.findViewById(R.id.tv_no_home);

        initViews();
        initListeners();

        updateDevices();

        return mRootView;
    }

    @Override
    public void toastMessage(String msg) {
        super.toastMessage(msg);
        stopLoading();
    }

    private void initViews() {
        mAddDeviceIV = mRootView.findViewById(R.id.button_add_device);
        mOptionIv = mRootView.findViewById(R.id.button_more);
        mSearchIv = mRootView.findViewById(R.id.button_search);
    }

    private void initListeners() {


        mOptionIv.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (mListener != null) {
                    mListener.onMoreOption();
                }
            }
        });

    }


    @Override
    public void onStart() {
        super.onStart();
    }


    @Override
    public void onResume() {
        super.onResume();
    }

    @Override
    public void onPause() {
        super.onPause();
    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        if (context instanceof OnListFragmentInteractionListener) {
            mListener = (OnListFragmentInteractionListener) context;
        } else {
            throw new RuntimeException(context.toString()
                    + " must implement OnListFragmentInteractionListener");
        }
    }

    @Override
    public void onDetach() {
        super.onDetach();
        mListener = null;
    }

    @Override
    public void showActivityAddDeviceIcon(boolean show) {

        mIsOperator = show;

        mAddDeviceIV.setVisibility(show ? View.VISIBLE : View.GONE);
        if (mNoDeviceTv!=null) {
            Drawable topDrawable= getRes().getDrawable(R.drawable.add_device_btn);
            //mNoDeviceTv.setVisibility(show ? View.VISIBLE:View.GONE);
            mNoDeviceTv.setCompoundDrawablesRelativeWithIntrinsicBounds(null,mIsOperator ? topDrawable:null,null,null);

        }
    }

    @Override
    public void showDeviceList(List<HomeModule> list) {
        mAdapter.setList(list);
        stopLoading();
        mRefreshListView.updateEmptyView(false);
    }

    @Override
    public void showNoDevice() {
        stopLoading();
        mAdapter.setList(EMPTY_LIST);
        mRefreshListView.updateEmptyView(true);
    }

    @Override
    public void showNetworkError() {
        stopLoading();
        LinkToast.makeText(getContext(), getString(R.string.msg_network_error), Toast.LENGTH_LONG).show();

    }


    @Override
    public void onRefresh() {

        updateDevices();

    }

    @Override
    public void onLoadMore() {
        stopLoading();
    }

    private void stopLoading() {
        if (mRefreshListView == null) return;
        mRefreshListView.fullLoad();
        mRefreshListView.setRefreshing(false);

    }
    @Override
    public void onListItemClick(HomeModule item) {
        gotoHomeDetail(item);
    }

    @Override
    public void onListItemLongClick(View view, HomeModule item) {
        // do nothing
    }

    private void gotoHomeDetail(HomeModule item) {

        WebUtil.gotoUrl(item.getUrl(), getActivity(), null, 0);
    }

    @Override
    public void onListItemMarkClick(HomeModule item) {
        // do nothing
    }



    /**
     * This interface must be implemented by activities that contain this
     * fragment to allow an interaction in this fragment to be communicated
     * to the activity and potentially other fragments contained in that
     * activity.
     * <p/>
     * See the Android Training lesson <a href=
     * "http://developer.android.com/training/basics/fragments/communicating.html"
     * >Communicating with Other Fragments</a> for more information.
     */
    public interface OnListFragmentInteractionListener {
        void onMoreOption();

        void showMsgUnRead(boolean b);
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQUEST_CODE_ADD_DEVICE && resultCode == Activity.RESULT_OK) {
            updateDevices();
        }
    }

    private void updateDevices() {
        if (mPresenter != null) {
            mPresenter.getMyHomes();
        }
    }
    /**
     * 清空数据源
     */
    public void clearData() {
        if (getActivity()!=null && !getActivity().isDestroyed() && isAdded() ){
            stopLoading();
            if (mAdapter!=null ){
                mAdapter.setList(EMPTY_LIST);
            }
        }
    }

    @Override
    public void onLogin() {
        clearData();
    }

    @Override
    public void onLogout() {
        clearData();
    }
}
