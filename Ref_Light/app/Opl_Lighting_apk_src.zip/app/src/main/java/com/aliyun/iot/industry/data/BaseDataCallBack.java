package com.aliyun.iot.industry.data;

public abstract class BaseDataCallBack<T> implements DataCallBack<T> {

}
