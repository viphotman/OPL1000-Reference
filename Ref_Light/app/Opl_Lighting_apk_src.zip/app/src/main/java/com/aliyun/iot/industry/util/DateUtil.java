package com.aliyun.iot.industry.util;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;

import com.aliyun.iot.industry.R;

public class DateUtil {

    public static String getDisplayDate(long time) {

        SimpleDateFormat format = new SimpleDateFormat(StringUtil.getString(R.string.dateFormat_ymd), Locale.CHINA);

        String date = format.format(new Date(time));
        String week = dateToWeek(format, date);

        return date.substring(5) + ' ' + week;

    }

    public static String getDisplayTime(long time) {

        int ONE_HOUR = 59 * 60 * 1000;
        long cur = System.currentTimeMillis();

        long pass = cur - time;
        if (pass < 0) return "";

        long min = pass / 1000 / 60;

        if (min == 0) {
            return StringUtil.getString(R.string.just);
        }

        if (pass < ONE_HOUR) {
            return "" + pass / 1000 / 60 + StringUtil.getString(R.string.minutes_ago);
        }

        SimpleDateFormat format = new SimpleDateFormat(StringUtil.getString(R.string.dateFormat_hm), Locale.CHINA);

        return format.format(new Date(time));


    }

    public static String getDetailTime(long time) {

        SimpleDateFormat format = new SimpleDateFormat(StringUtil.getString(R.string.dateFormat_ymdhm), Locale.CHINA);

        return format.format(new Date(time));


    }

    /**
     * 日期转星期
     */
    private static String dateToWeek(SimpleDateFormat f, String datetime) {
        String[] weekDays = {StringUtil.getString(R.string.sunday),
                StringUtil.getString(R.string.monday),
                StringUtil.getString(R.string.tuesday),
                StringUtil.getString(R.string.wednesday),
                StringUtil.getString(R.string.thursday),
                StringUtil.getString(R.string.friday),
                StringUtil.getString(R.string.saturday)};
        Calendar cal = Calendar.getInstance(); // 获得一个日历
        Date date;
        try {
            date = f.parse(datetime);
            cal.setTime(date);
        } catch (ParseException e) {
            e.printStackTrace();
        }
        int w = cal.get(Calendar.DAY_OF_WEEK) - 1; // 指示一个星期中的某天。
        if (w < 0)
            w = 0;
        return weekDays[w];
    }

}
