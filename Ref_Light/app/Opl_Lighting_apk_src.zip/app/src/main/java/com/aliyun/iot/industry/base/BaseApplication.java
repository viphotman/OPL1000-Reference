package com.aliyun.iot.industry.base;

import android.app.Application;
import android.content.Intent;
import android.os.Handler;
import android.support.v4.content.LocalBroadcastManager;

import com.alibaba.sdk.android.push.register.HuaWeiRegister;
import com.alibaba.sdk.android.push.register.MiPushRegister;
import com.aliyun.iot.aep.page.container.DefaultWebHelper;
import com.aliyun.iot.aep.sdk.framework.AApplication;
import com.aliyun.iot.aep.sdk.framework.bundle.BundleManager;
import com.aliyun.iot.aep.sdk.framework.bundle.IBundleRegister;
import com.aliyun.iot.aep.sdk.framework.bundle.PageConfigure;
import com.aliyun.iot.aep.sdk.framework.config.AConfigure;
import com.aliyun.iot.aep.sdk.framework.sdk.SDKManager;
import com.aliyun.iot.aep.sdk.log.ALog;
import com.aliyun.iot.industry.Config;
import com.aliyun.iot.industry.data.LocalData;
import com.aliyun.iot.industry.push.PushManager;
import com.aliyun.iot.industry.sdk.delegate.APIGatewaySDKDelegate;
import com.aliyun.iot.industry.sdk.delegate.OpenAccountSDKDelegate;
import com.aliyun.iot.industry.util.WebUtil;

import static com.aliyun.iot.industry.base.BaseActivity.QUIT_ACTION;
import static com.aliyun.iot.industry.base.BaseActivity.QUIT_TIME;

public class BaseApplication extends AApplication {

    private static final int TIME_DELAY_TO_FINISH_ACTIVITIES = 300;

    public static void finishAllMyActivitiesQuietly() {
        final long quitTime = System.currentTimeMillis();
        ALog.d("BaseApplication", "finishAllMyActivitiesQuietly " + quitTime);
        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {
                ALog.d("BaseApplication", "finishAllMyActivitiesQuietly now");
                Intent intent = new Intent(QUIT_ACTION);
                intent.putExtra(QUIT_TIME, quitTime);

                LocalBroadcastManager.getInstance(getInstance()).sendBroadcast(intent);

            }
        }, TIME_DELAY_TO_FINISH_ACTIVITIES);

    }

    /* methods: helper init */

    @Override
    public void onCreate() {
        super.onCreate();

        PushManager.getInstance().init(this);
        initThirdPush();

        LocalData.init(getApplicationContext());

        this.init();
    }

    private void init() {

        initFramework();
        initWeb();

    }

    private void initWeb() {
        DefaultWebHelper.init();
        WebUtil.initWebRouter();
    }

    private void initFramework() {

        // 初始化，配置
        AConfigure.getInstance().init(this);

        initEnv();
        initSdk();

        BundleManager.init(this, new IBundleRegister() {
            @Override
            public void registerPage(Application application, PageConfigure pageConfigure) {
            }
        });
    }

    private void initSdk() {
        SDKManager.prepareForInitSdk(this);
        SDKManager.init_outOfUiThread(this);
        SDKManager.init_underUiThread(this);
    }

    private void initEnv() {
        AConfigure.getInstance().putConfig(APIGatewaySDKDelegate.ENV_KEY_API_CLIENT_API_ENV, Config.ENV);
        AConfigure.getInstance().putConfig(APIGatewaySDKDelegate.ENV_KEY_API_CLIENT_DEFAULT_HOST, Config.DEFAULT_HOST);
        AConfigure.getInstance().putConfig(APIGatewaySDKDelegate.ENV_KEY_LANGUAGE, "zh-CN");
        AConfigure.getInstance().putConfig(OpenAccountSDKDelegate.ENV_KEY_OPEN_ACCOUNT_HOST, Config.DEFAULT_OA_HOST);
    }

    private void initThirdPush() {
        // 注册方法会自动判断是否支持小米系统推送，如不支持会跳过注册。
        MiPushRegister.register(this,"请输入1-125个字符的AppId",
                "请输入1-125个字符的AppKey");
        // 注册方法会自动判断是否支持华为系统推送，如不支持会跳过注册。
        HuaWeiRegister.register(this);

    }

}
