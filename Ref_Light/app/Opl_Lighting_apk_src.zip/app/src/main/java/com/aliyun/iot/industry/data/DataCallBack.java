package com.aliyun.iot.industry.data;


public interface DataCallBack<T> {
    void onSuccess(T data);

    void onFail(String msg);
}
