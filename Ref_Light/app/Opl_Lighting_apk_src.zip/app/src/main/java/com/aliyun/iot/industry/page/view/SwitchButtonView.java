package com.aliyun.iot.industry.page.view;

import android.content.Context;
import android.support.constraint.ConstraintLayout;
import android.support.v7.widget.SwitchCompat;
import android.util.AttributeSet;
import android.widget.CompoundButton;
import android.widget.TextView;

import com.aliyun.iot.industry.R;

public class SwitchButtonView extends ConstraintLayout {


    public SwitchButtonView(Context context) {
        super(context);
    }

    public SwitchButtonView(Context context, AttributeSet attrs) {
        super(context, attrs);
    }

    public SwitchButtonView(Context context, AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
    }

    public void setTitle(String s) {
        TextView tv = findViewById(R.id.switch_button_title);
        tv.setText(s);
    }


    public void setSwitchListener(final OnSwitchChangeListener listener) {
        SwitchCompat switchCompat = findViewById(R.id.switch_btn);
        switchCompat.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton compoundButton, boolean b) {
                if (listener != null) {
                    listener.onSwitchChange(b);
                }
            }
        });
    }

    public void setSwitchOn(boolean on) {
        SwitchCompat switchCompat = findViewById(R.id.switch_btn);

        switchCompat.setChecked(on);
    }

    public interface OnSwitchChangeListener {
        void onSwitchChange(boolean on);
    }
}
