package com.aliyun.iot.industry.page.settings;

import android.content.Intent;
import android.os.Bundle;
import android.support.constraint.ConstraintLayout;
import android.text.TextUtils;
import android.view.View;
import android.widget.TextView;

import com.alibaba.sdk.android.openaccount.ui.LayoutMapping;
import com.aliyun.iot.aep.oa.page.OAResetPasswordActivity;
import com.aliyun.iot.aep.sdk.login.LoginBusiness;
import com.aliyun.iot.aep.sdk.login.data.UserInfo;

import com.aliyun.iot.industry.R;
import com.aliyun.iot.industry.base.BaseTitleActivity;
import com.aliyun.iot.industry.page.main.MainActivity;
import com.aliyun.iot.industry.page.main.MyOAResetPasswordActivity;
import com.aliyun.iot.industry.push.PushManager;
import com.aliyun.iot.industry.util.LoginUtils;

public class SettingsAccountActivity extends BaseTitleActivity {

    TextView mTvName;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_settings_account);

        setTitle(R.string.account_settings);

        if (!LoginBusiness.isLogin()) {
            LoginUtils.login();
        }

        initViews();
    }

    @Override
    protected void onResume() {
        super.onResume();
        updateView();
    }

    private void updateView() {
        if (mTvName == null) return;
        UserInfo userInfo = LoginBusiness.getUserInfo();
        if (userInfo == null) {
            LoginUtils.login();
            return;
        }
        String displayName = userInfo.userNick;

        if (TextUtils.isEmpty(displayName)) {

            displayName = userInfo.userPhone;
            if (displayName != null && displayName.length() > 8) {
                int len = displayName.length();
                displayName = displayName.substring(0,len - 8) + "****" + displayName.substring(len - 4,len);

            }

        }
        mTvName.setText(displayName);


    }
    private void initViews() {
        mTvName = findViewById(R.id.account_name);

        ConstraintLayout cLChangePw = findViewById(R.id.change_password);
        cLChangePw.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                LayoutMapping.put(MyOAResetPasswordActivity.class, R.layout.kinco_ali_sdk_openaccount_change_password2);

                String mobile = "";
                UserInfo userInfo = LoginBusiness.getUserInfo();

                if (userInfo != null) {
                    mobile = userInfo.userPhone;
                }

                Intent intent = new Intent(SettingsAccountActivity.this,MyOAResetPasswordActivity.class);
                intent.putExtra("mobile", mobile);
                startActivity(intent);
            }
        });


        TextView tvQuit = findViewById(R.id.quit_login);
        tvQuit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //quitApp();
                //finish();
                PushManager.getInstance().unbindUser();

                LoginUtils.logout(SettingsAccountActivity.this, MainActivity.class);
            }
        });
    }
}
