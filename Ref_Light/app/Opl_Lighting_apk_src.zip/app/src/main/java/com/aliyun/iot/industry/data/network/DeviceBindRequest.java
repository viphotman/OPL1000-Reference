package com.aliyun.iot.industry.data.network;

import java.io.Serializable;

public class DeviceBindRequest implements Serializable {
    private String productKey;
    private String deviceName;
    private String phoneNumber;
    private String securityCode;

    public DeviceBindRequest(){}

    public DeviceBindRequest(String productKey, String deviceName, String phoneNumber, String securityCode) {
        this.productKey = productKey;
        this.deviceName = deviceName;
        this.phoneNumber = phoneNumber;
        this.securityCode = securityCode;
    }

    public String getProductKey() {
        return productKey;
    }

    public String getDeviceName() {
        return deviceName;
    }

    public String getPhoneNumber() {
        return phoneNumber;
    }

    public String getSecurityCode() {
        return securityCode;
    }
}
