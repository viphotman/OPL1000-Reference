package com.aliyun.iot.industry.data;

public interface DeviceDataSource {

    void sendShortMessage(String phoneNum,DataCallBack dataCallBack);

    void deviceBind(String productKey,String deviceName,String phoneNumber,String securityCode,DataCallBack dataCallBack);
}
