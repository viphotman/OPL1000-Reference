package com.aliyun.iot.industry.push;

import android.app.Application;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.support.v4.content.LocalBroadcastManager;
import android.text.TextUtils;

import com.alibaba.sdk.android.push.CloudPushService;
import com.alibaba.sdk.android.push.CommonCallback;
import com.alibaba.sdk.android.push.noonesdk.PushServiceFactory;
import com.aliyun.iot.aep.sdk.apiclient.IoTAPIClient;
import com.aliyun.iot.aep.sdk.apiclient.IoTAPIClientFactory;
import com.aliyun.iot.aep.sdk.apiclient.callback.IoTCallback;
import com.aliyun.iot.aep.sdk.apiclient.callback.IoTResponse;
import com.aliyun.iot.aep.sdk.apiclient.emuns.Scheme;
import com.aliyun.iot.aep.sdk.apiclient.request.IoTRequest;
import com.aliyun.iot.aep.sdk.apiclient.request.IoTRequestBuilder;
import com.aliyun.iot.aep.sdk.log.ALog;
import com.aliyun.iot.aep.sdk.login.LoginBusiness;

public class PushManager {
    static final String BIND = "/uc/bindPushChannel";
    static final String UN_BIND = "/uc/unbindPushChannel";

    private static final String TAG = "PushManager";

    private PushManager() {
    }

    public static final PushManager getInstance() {
        return PushManager.SingletonHolder.INSTANCE;
    }

    public void init(Application var1) {
        this.initPush(var1);
    }

    public void unbindUser() {
        this.request("/uc/unbindPushChannel");
    }

    public void bindUser() {
        this.request("/uc/bindPushChannel");
    }

    private void initPush(Application var1) {
        PushServiceFactory.init(var1);
        CloudPushService var2 = PushServiceFactory.getCloudPushService();
        var2.setSecurityGuardAuthCode("114d");
        var2.register(var1, new CommonCallback() {
            public void onSuccess(String var1) {
                ALog.d(TAG, "init cloudchannel success");
                String var2 = PushServiceFactory.getCloudPushService().getDeviceId();
                if (TextUtils.isEmpty(var2)) {
                    var2 = "没有获取到";
                }

                //EnvConfigure.putEnvArg("KEY_DEVICE_ID", var2);
                if (LoginBusiness.isLogin()) {
                    PushManager.this.request("/uc/bindPushChannel");
                }

            }

            public void onFailed(String var1, String var2) {
                ALog.d(TAG, "init cloudchannel failed -- errorcode:" + var1 + " -- errorMessage:" + var2);
            }
        });
        IntentFilter var3 = new IntentFilter();
        var3.addAction("com.aliyun.iot.sdk.LoginStatusChange");
        LocalBroadcastManager var4 = LocalBroadcastManager.getInstance(var1);
        var4.registerReceiver(new BroadcastReceiver() {
            public void onReceive(Context var1, Intent var2) {
                if (LoginBusiness.isLogin()) {
                    ALog.d(TAG, "login:" + var2);

                    PushManager.this.request("/uc/bindPushChannel");
                } else {
                    ALog.d(TAG, "logout:" + var2);

                    PushManager.this.request("/uc/unbindPushChannel");

                }

            }
        }, var3);
    }

    void request(String var1) {
        CloudPushService var2 = PushServiceFactory.getCloudPushService();
        String var3 = var2.getDeviceId();
        if (!TextUtils.isEmpty(var3)) {
            String var4 = "1.0.2";
            IoTRequestBuilder var5 = (new IoTRequestBuilder()).setAuthType("iotAuth").setScheme(Scheme.HTTPS).setPath(var1).setApiVersion(var4).addParam("deviceType", "ANDROID").addParam("deviceId", var3);
            IoTRequest var6 = var5.build();
            IoTAPIClient var7 = (new IoTAPIClientFactory()).getClient();
            var7.send(var6, new IoTCallback() {
                public void onFailure(IoTRequest var1, Exception var2) {
                    var2.printStackTrace();
                    ALog.d(TAG, "Failure");
                }

                public void onResponse(IoTRequest var1, IoTResponse var2) {
                    ALog.d(TAG, "Success");
                }
            });
        }
    }

    static class SingletonHolder {
        private static final PushManager INSTANCE = new PushManager();

        private SingletonHolder() {
        }
    }
}
