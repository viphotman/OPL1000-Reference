package com.aliyun.iot.industry.page.account;

import android.animation.ObjectAnimator;
import android.animation.ValueAnimator;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.res.Configuration;
import android.graphics.Color;
import android.os.Build;
import android.os.Bundle;
import android.os.LocaleList;
import android.support.annotation.Nullable;
import android.text.TextUtils;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.Toast;

import com.alibaba.sdk.android.openaccount.rpc.model.RpcResponse;
import com.alibaba.sdk.android.openaccount.task.TaskWithDialog;
import com.alibaba.sdk.android.openaccount.trace.AliSDKLogger;
import com.alibaba.sdk.android.openaccount.ui.model.CountrySort;
import com.alibaba.sdk.android.openaccount.ui.widget.SiderBar;
import com.alibaba.sdk.android.openaccount.util.RpcUtils;
import com.aliyun.iot.aep.oa.OAUIInitHelper;
import com.aliyun.iot.aep.oa.page.adapter.CountryCodeAdapter;
import com.aliyun.iot.aep.oa.page.data.GetCountryNameSort;
import com.aliyun.iot.aep.oa.page.data.LocaleUtils;
import com.aliyun.iot.aep.sdk.login.oa.ui.R;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import java.util.Map;

/**
 * Created by feijie.xfj on 18/4/11.
 * 此代码基本复制MobileCountrySelectorActivity，只做UI定制，逻辑不做修改
 */

public class OAMobileCountrySelectorActivity extends Activity {

    public static final int COUNTRY_CODE_REQUEST = 12;

    private ListView mCountryListView;

    private CountryCodeAdapter adapter;

    protected List<CountrySort> mCountryList = null;

    protected SiderBar mSiderBar;

    private CountryComparator countryComparator = new CountryComparator();

    protected GetCountryNameSort countryChangeUtil;

    private View loadingView;

    private ObjectAnimator mRotaion;


    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(com.aliyun.iot.industry.R.layout.kinco_ali_sdk_openaccount_mobile_country_selector2);
        TRANSPARENT();

        findViewById(R.id.imageview_account_back).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });

        this.mCountryListView = this.findViewById(R.id.country_list);
        this.mSiderBar = this.findViewById(R.id.country_sidebar);
        this.countryChangeUtil = new GetCountryNameSort();
        this.mCountryListView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            public void onItemClick(AdapterView<?> adapterView, View view, int position, long arg3) {
                Intent intent = new Intent();
                CountrySort selectedCountrySort = (CountrySort) adapter.getItem(position);
                intent.putExtra("countryCode", selectedCountrySort.code);
                setResult(-1, intent);
                finish();
            }
        });

        this.mSiderBar.setOnTouchingLetterChangedListener(new SiderBar.OnTouchingLetterChangedListener() {
            public void onTouchingLetterChanged(String s) {
                if (adapter != null) {
                    int position = adapter.getPositionForSection(s.charAt(0));
                    if (position != -1) {
                        mCountryListView.setSelection(position);
                    }

                }
            }
        });
        loadingView = findViewById(R.id.account_loading);

        showLoading();

        //查询国家码信息
        new GetCountryTask(this).execute(new Void[0]);
    }



    @Override
    protected void attachBaseContext(Context newBase) {
        super.attachBaseContext(attachBaseContextInner(newBase));
    }

    @Override
    protected void onResume() {
        super.onResume();
        onResumeInner(this);
    }

    public void showLoading() {
        if (mRotaion == null) {
            mRotaion = ObjectAnimator.ofFloat(loadingView, "rotation", 0, 180);
            mRotaion.setDuration(2000);
            mRotaion.setRepeatCount(ValueAnimator.INFINITE);
        }
        mRotaion.cancel();
        mRotaion.start();
    }


    public void stopAnimation() {
        if (mRotaion != null) {
            mRotaion.cancel();
        }
        if(loadingView!=null){
            loadingView.setVisibility(View.GONE);
        }
    }

    public void stopAnimationAndShowError(final String err) {
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                stopAnimation();
                if (!TextUtils.isEmpty(err)) {
                    Toast.makeText(getApplicationContext(), err, Toast.LENGTH_SHORT).show();
                }
            }
        });
    }

    private class CountryComparator implements Comparator<CountrySort> {
        public CountryComparator() {
        }

        public int compare(CountrySort o1, CountrySort o2) {
            return !o1.sortLetters.equals("@") && !o2.sortLetters.equals("#") ? (!o1.sortLetters.equals("#") && !o2.sortLetters.equals("@") ? o1.sortLetters.compareTo(o2.sortLetters) : 1) : -1;
        }
    }

    private class GetCountryTask extends TaskWithDialog<Void, Void, List<CountrySort>> {
        public GetCountryTask(Activity activity) {
            super(activity);
        }

        protected List<CountrySort> asyncExecute(Void... params) {
            SharedPreferences prefs = getApplication().getSharedPreferences("openaccount_country_list", 0);
            String countryNumListValue = prefs.getString("countryNumList", (String) null);
            JSONArray cachedCountryNumList = null;
            String maxCountryVersion = null;
            boolean useServerSideCountryNumList = false;
            if (TextUtils.isEmpty(countryNumListValue)) {
                maxCountryVersion = null;
            } else {
                maxCountryVersion = prefs.getString("maxCountryVersion", (String) null);

                try {
                    cachedCountryNumList = new JSONArray(countryNumListValue);
                } catch (Exception var15) {
                    AliSDKLogger.e("oa_ui", "fail to parse local cached country list, will use server side", var15);
                    maxCountryVersion = null;
                }
            }

            Map<String, Object> getCountryRequest = new HashMap();
            getCountryRequest.put("queryString", "q=test&rows=100");
            getCountryRequest.put("version", maxCountryVersion);
            RpcResponse rpcResponse = RpcUtils.pureInvokeWithRiskControlInfo("searchCountryRequest", getCountryRequest, "searchcountry");
            List<CountrySort> countrySorts = null;
            JSONArray serverCountryNumList = null;

            stopAnimationAndShowError(null);
            if (rpcResponse != null && rpcResponse.arrayData != null) {
                try {
                    if (rpcResponse.code == 1) {
                        serverCountryNumList = rpcResponse.arrayData;
                        if (serverCountryNumList != null) {
                            countrySorts = readArray(serverCountryNumList);
                            useServerSideCountryNumList = true;
                        }
                    }
                } catch (Exception var14) {
                    AliSDKLogger.e("oa_ui", "fail to parse the server side response", var14);
                    stopAnimationAndShowError(getString(R.string.account_get_country_error));
                }
            }

            if (countrySorts == null && cachedCountryNumList != null) {
                try {
                    countrySorts = readArray(cachedCountryNumList);
                } catch (Exception var13) {
                    AliSDKLogger.e("oa_ui", "fail to parse the local country list", var13);
                    stopAnimationAndShowError(getString(R.string.account_get_country_error));
                }
            }

            if (useServerSideCountryNumList) {
                SharedPreferences sp = getApplication().getSharedPreferences("openaccount_country_list", 0);
                SharedPreferences.Editor editor = sp.edit();
                editor.putString("countryNumList", serverCountryNumList.toString());
                int maxCountryVersion2 = 0;
                Iterator var4 = countrySorts.iterator();

                while (var4.hasNext()) {
                    CountrySort countrySort = (CountrySort) var4.next();
                    if (countrySort.version > maxCountryVersion2) {
                        maxCountryVersion2 = countrySort.version;
                    }
                }

                editor.putString("maxCountryVersion", String.valueOf(maxCountryVersion));
                editor.apply();
            }

            return countrySorts;
        }

        protected void onPostExecute(List<CountrySort> list) {
            if (list != null && list.size() > 0) {
                List<CountrySort> hot5 = getHot5(mCountryList);
                Collections.sort(mCountryList, countryComparator);
                list.addAll(0, hot5);
                adapter = new CountryCodeAdapter(OAMobileCountrySelectorActivity.this, list);
                mCountryListView.setAdapter(adapter);
            }

        }

        protected void doWhenException(Throwable t) {
        }
    }

    protected List<CountrySort> getHot5(List<CountrySort> listToAdd) {
        List<CountrySort> newList = new ArrayList();
        if (listToAdd.size() >= 5) {
            for (int i = 0; i < 5; ++i) {
                newList.add(CountrySort.getCountryHot((CountrySort) listToAdd.get(i)));
            }
        }

        return newList;
    }

    protected List<CountrySort> readArray(JSONArray jsonArray) {
        try {
            int count = jsonArray.length();
            if (count > 0) {
                List<CountrySort> countryList = new ArrayList();

                for (int index = 0; index < count; ++index) {
                    JSONObject obj = null;
                    obj = jsonArray.getJSONObject(index);
                    if (obj != null) {
                        CountrySort country = new CountrySort();
                        country.name = obj.optString("areaName");
                        country.code = obj.optString("code");
                        country.englishName = obj.optString("areaEnglishName");
                        country.tranditionalName = obj.optString("areaChineseTranditionalName");
                        country.pinyin = obj.optString("pinyin");
                        country.sortWeightKey = obj.optString("sortWeightKey");
                        country.checkKey = obj.optString("checkKey");
                        country.domain = obj.optString("domainAbbreviation");
                        country.version = obj.optInt("version");
                        String locale = LocaleUtils.getCurrentLocale();
                        if (LocaleUtils.isZHLocale(locale)) {
                            String sortLetter = this.countryChangeUtil.getSortLetterBySortKey(country.pinyin);
                            if (sortLetter == null) {
                                sortLetter = this.countryChangeUtil.getSortLetter(country.name);
                            }

                            country.sortLetters = sortLetter;
                            if (LocaleUtils.isUseTraditionChinese(locale)) {
                                country.displayName = country.tranditionalName;
                            } else {
                                country.displayName = country.name;
                            }
                        } else {
                            country.sortLetters = this.countryChangeUtil.getSortLetterBySortKey(country.englishName);
                            country.displayName = country.englishName;
                        }

                        countryList.add(country);
                    }
                }

                this.mCountryList = countryList;
                return countryList;
            }
        } catch (JSONException var9) {
            var9.printStackTrace();
        }

        return null;
    }

    protected final void TRANSPARENT() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            Window window = getWindow();
            window.clearFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS
                    | WindowManager.LayoutParams.FLAG_TRANSLUCENT_NAVIGATION);
            window.getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                    | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                    | View.SYSTEM_UI_FLAG_LAYOUT_STABLE);
            window.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS);
            window.setStatusBarColor(Color.TRANSPARENT);
            window.setNavigationBarColor(Color.TRANSPARENT);
        }
    }


    public static Context attachBaseContextInner(Context newBase) {
        if (Build.VERSION.SDK_INT >= 24 && !TextUtils.isEmpty(OAUIInitHelper.LANGUAGE) &&
                !TextUtils.isEmpty(OAUIInitHelper.COUNTRY)) {

            Configuration configuration = newBase.getResources().getConfiguration();
            Locale locale = null;
            try {
                locale = new Locale(OAUIInitHelper.LANGUAGE, OAUIInitHelper.COUNTRY);
            } catch (Exception e) {
                ;
            }
            configuration.setLocales(new LocaleList(locale));
            Context context = newBase.createConfigurationContext(configuration);
            return context;
        }
        return newBase;
    }

    public static void onResumeInner(Context context) {
        if (Build.VERSION.SDK_INT >= 24 && !TextUtils.isEmpty(OAUIInitHelper.LANGUAGE) &&
                !TextUtils.isEmpty(OAUIInitHelper.COUNTRY)) {
            Configuration configuration = context.getResources().getConfiguration();
            Locale locale = null;
            try {
                locale = new Locale(OAUIInitHelper.LANGUAGE, OAUIInitHelper.COUNTRY);
            } catch (Exception e) {
            }
            configuration.setLocales(new LocaleList(locale));
            context.createConfigurationContext(configuration);
        }
    }
}
