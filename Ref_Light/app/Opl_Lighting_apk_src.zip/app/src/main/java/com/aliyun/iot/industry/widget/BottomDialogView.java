package com.aliyun.iot.industry.widget;

import android.content.Context;
import android.support.annotation.Nullable;
import android.util.AttributeSet;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.LinearLayout;

public class BottomDialogView extends LinearLayout {


    public BottomDialogView(Context context) {
        super(context);
    }

    public BottomDialogView(Context context, @Nullable AttributeSet attrs) {
        super(context, attrs);
    }

    public BottomDialogView(Context context, @Nullable AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
    }

    private void setChildButtonOnClickListener(View view, OnClickListener listener) {
        if (view == null || listener == null) return;
        if (view instanceof Button) {
            view.setOnClickListener(listener);
        } else if (view instanceof ViewGroup) {
            int c = ((ViewGroup) view).getChildCount();
            for (int i = 0; i < c; i++) {
                setChildButtonOnClickListener(((ViewGroup) view).getChildAt(i), listener);
            }
        }
    }

    public void setOnClickListener(OnClickListener listener) {
        setChildButtonOnClickListener(this, listener);
    }

}
