package com.aliyun.iot.industry.data;

public interface HomeDataSource {

    void getMyHomes(DataCallBack dataCallBack);

    void searchHomes(String keyWord, DataCallBack dataCallBack);

    boolean getAutoRefresh();

    String getRole();


}