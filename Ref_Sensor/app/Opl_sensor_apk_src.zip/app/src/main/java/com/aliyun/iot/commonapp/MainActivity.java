package com.aliyun.iot.commonapp;

import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Handler;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.TextUtils;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.aliyun.iot.aep.component.router.Router;
import com.aliyun.iot.aep.sdk.login.ILoginCallback;
import com.aliyun.iot.aep.sdk.login.LoginBusiness;
import com.aliyun.iot.commonapp.base.ui.LinkToast;
import com.bumptech.glide.Glide;
import com.bumptech.glide.request.RequestOptions;

import static com.bumptech.glide.load.resource.drawable.DrawableTransitionOptions.withCrossFade;

/**
 * @author sinyuk
 */
public class MainActivity extends AppCompatActivity {
    private final Handler handler = new Handler();

    public static final int ANIMATION_DURATION = 300;
    public static final int DELAY_MILLS = ANIMATION_DURATION + 1000;

    @Override
    protected void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        String main = getString(R.string.default_router_format,
                getString(R.string.in_app_router_schema),
                getString(R.string.host_main));

        Router.getInstance().registerModuleUrlHandler(main, (context, s, bundle1, b, i) -> startSelf(context, s));

        setContentView(R.layout.activity_main);
        ImageView imageView = findViewById(R.id.splash_icon);
        Glide.with(this).load(R.mipmap.common_launcher_icon)
                .apply(new RequestOptions().centerInside())
                .transition(withCrossFade(ANIMATION_DURATION))
                .into(imageView);

        long half = ANIMATION_DURATION / 2;
        TextView textView = findViewById(R.id.text_app_name);
        textView.setAlpha(0f);
        textView.setText(R.string.common_app_name);
        textView.animate()
                .alphaBy(1f)
                .setDuration(half)
                .setStartDelay(half)
                .start();

        handler.postDelayed(this::toLoginActivity, DELAY_MILLS);
    }


    public void startSelf(Context context, String s) {
        Intent intent = new Intent(context, MainActivity.class);
        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
        intent.setData(Uri.parse(s));
        context.startActivity(intent);
    }

    @Override
    protected void onDestroy() {
        handler.removeCallbacksAndMessages(null);
        super.onDestroy();
    }

    void toLoginActivity() {
        if (isFinishing() || isDestroyed()) {
            return;
        }
        if (LoginBusiness.isLogin()) {
            toIndexActivity();
        } else {
            LoginBusiness.login(new ILoginCallback() {
                @Override
                public void onLoginSuccess() {
                    toIndexActivity();
                }

                @Override
                public void onLoginFailed(int i, String s) {
                    String msg = s;
                    if (TextUtils.isEmpty(msg)) {
                        msg = "登入失败";
                    }
                    LinkToast.makeText(MainActivity.this, msg, Toast.LENGTH_SHORT).show();
                    finish();
                }
            });
        }
    }

    void toIndexActivity() {
        String url = getString(R.string.default_router_format, getString(R.string.in_app_router_schema),
                getString(R.string.host_index));
        Router.getInstance().toUrl(this, url);
        finish();
    }
}
