package com.aliyun.iot.commonapp.component;

import android.content.Context;
import android.support.v4.app.Fragment;

import com.aliyun.iot.commonapp.home.HomeFragment;
import com.aliyun.iot.componentmanager.Component;
import com.aliyun.iot.componentmanager.ComponentInterface;

import java.util.HashMap;
import java.util.Map;

/**
 * @author sinyuk
 * @date 2018/12/25
 */
@SuppressWarnings("unused")
public class HomeComponent implements ComponentInterface {
    @Override
    public void init(Context context) {

    }

    @SuppressWarnings("unused")
    public Component.ActionResponse getView(Component.ActionRequest request) {
        Component.ActionResponse response = new Component.ActionResponse(200, "");
        try {
            Map<String, Object> params = new HashMap<>();
            Fragment fragment = HomeFragment.newInstance();
            params.put("data", fragment);
            response.setResponse(params);
        } catch (Exception e) {
            e.printStackTrace();
            response.setCode(500);
            response.setMsg(e.getMessage());
        }
        return response;
    }
}
