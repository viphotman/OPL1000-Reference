package com.aliyun.iot.aep.oa.page;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Bitmap;
import android.net.http.SslError;
import android.os.Build;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.text.TextUtils;
import android.view.View;
import android.webkit.SslErrorHandler;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import com.aliyun.iot.aep.sdk.log.ALog;
import com.aliyun.iot.aep.sdk.login.LoginBusiness;
import com.aliyun.iot.commonapp.login.R;


/**
 * Created by feijie.xfj on 18/3/28.
 * 【Havana相关联系人】
 * 修改手机，邮箱等身份验证问题联系：子崇
 * 修改手机、邮箱问题联系：晨梓、不负
 * 注册相关问题联系：林悟、不负
 * 订正手机和邮箱联系：粥五、晨暮
 */


public class AliyunWebActivity extends Activity {
    private static final String TAG = "AliyunWebActivity";
    /**
     * 出现部分内容显示部分内容不显示，打印日志大概如下：
     * <p>
     * chromium: [INFO:CONSOLE(15)] "Mixed Content: The page at 'https://dihao.moxz.cn/' was loaded over HTTPS, but requested an insecure image 'http://sm.domobcdn.com/hm/2017/landing/img/dihao/p5.jpg'. This request has been blocked; the content must be served over HTTPS.", source: https://sm.domobcdn.com/hm/2017/landing/js/swiper.3.4.2.min.js (15)
     * <p>
     * 这个是加载的地址是https的，一些资源文件使用的是http方法的，从安卓4.4之后对webview安全机制有了加强，webview里面加载https url的时候，如果里面需要加载http的资源或者重定向的时候，webview会block页面加载。需要设置MixedContentMode，解决此问题的代码如下：
     */
    private WebView webView;

    private String url = "https://account.aliyun.test/login/login.htm?oauth_callback=http%3A%2F%2Faliyun.iot.web.com%2Flogin.html&oauth_token=";

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_aliyunweb);

        findViewById(R.id.aliyunwebactivity_back).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onBackPressed();
            }
        });

        //初始化阿里云登录URL
        if (!"TEST".equalsIgnoreCase(LoginBusiness.getEnv())) {
            url = "https://account.aliyun.com/login/login.htm?oauth_callback=http%3A%2F%2Faliyun.iot.web.com%2Flogin.html&oauth_token=";
        }
        webView = findViewById(R.id.aliyunwebactivity_web);
        if (getIntent() != null && getIntent().getExtras() != null) {
            url += getIntent().getExtras().getString("auth_token");
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
            WebView.setWebContentsDebuggingEnabled(true);
        }

        webView.setWebViewClient(new DefaultWebViewClient());

        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        //settings.setDomStorageEnabled(true);
        // settings.setAllowFileAccess(true);
        //settings.setAppCacheEnabled(true);

        webView.loadUrl(url);
    }

    @Override
    public void onBackPressed() {
        setResult(RESULT_CANCELED, null);
        finish();
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
    }

    class DefaultWebViewClient extends WebViewClient {

        @Override
        public boolean shouldOverrideUrlLoading(WebView view, String url) {
            ALog.i(TAG, "shouldOverrideUrlLoading");
            if (url.contains("http://account.aliyun.test/oauth/auth_confirm")) {
                ALog.i(TAG, "shouldOverrideUrlLoading():url:" + url);
            }
            return false;
        }

        @Override
        public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
            ALog.i(TAG, "shouldOverrideUrlLoading1");
            return false;
        }

        @Override
        public void onPageStarted(WebView view, String url, Bitmap favicon) {
            ALog.i(TAG, "onPageStarted():" + url);
            if (url.contains("oauth_token") && url.contains("oauth_verifier")) {
                int index = url.indexOf("?");
                if (index > 0) {
                    String res = url.substring(url.indexOf("?") + 1);
                    String[] paramsList = res.split("&");
                    String oauth_token = "", oauth_verifier = "";
                    for (int i = 0; i < paramsList.length; i++) {
                        if (paramsList[i].contains("oauth_token")) {
                            String[] s = paramsList[i].split("=");
                            oauth_token = s[1];

                        } else if (paramsList[i].contains("oauth_verifier")) {
                            String[] s = paramsList[i].split("=");
                            oauth_verifier = s[1];
                        }
                    }

                    if (TextUtils.isEmpty(oauth_token) || TextUtils.isEmpty(oauth_verifier)) {
                        ALog.i(TAG, "oauth_token or oauth_verifier is empty");
                    }
                    Intent intent = new Intent();
                    intent.putExtra("oauth_token", oauth_token);
                    intent.putExtra("oauth_verifier", oauth_verifier);
                    setResult(RESULT_OK, intent);
                    finish();
                    return;
                }
            }
            super.onPageStarted(view, url, favicon);
        }

        @Override
        public void onReceivedSslError(WebView view, final SslErrorHandler handler, SslError error) {
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    final AlertDialog.Builder builder = new AlertDialog.Builder(AliyunWebActivity.this);
                    builder.setMessage(R.string.account_ssl_error);
                    builder.setPositiveButton(getString(R.string.account_continue), new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            handler.proceed();
                        }
                    });
                    builder.setNegativeButton(getString(R.string.account_cancel), new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            handler.cancel();
                        }
                    });
                    final AlertDialog dialog = builder.create();
                    dialog.show();
                }
            });
        }
    }
}
