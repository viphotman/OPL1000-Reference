package com.aliyun.iot.aep.oa.page;


import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.content.ContextCompat;
import android.text.TextUtils;
import android.util.AttributeSet;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.alibaba.sdk.android.openaccount.model.Result;
import com.alibaba.sdk.android.openaccount.ui.OpenAccountUIConfigs;
import com.alibaba.sdk.android.openaccount.ui.RequestCode;
import com.alibaba.sdk.android.openaccount.ui.model.f;
import com.alibaba.sdk.android.openaccount.ui.ui.ResetPasswordActivity;
import com.alibaba.sdk.android.openaccount.ui.widget.NetworkCheckOnClickListener;
import com.alibaba.sdk.android.openaccount.util.OpenAccountUtils;
import com.alibaba.sdk.android.openaccount.util.ResourceUtils;
import com.aliyun.iot.aep.oa.OALanguageHelper;
import com.aliyun.iot.aep.widget.OATitleBar;
import com.aliyun.iot.commonapp.login.R;

import java.lang.reflect.Field;

import static android.view.View.TEXT_ALIGNMENT_INHERIT;

/**
 * Created by feijie.xfj on 18/4/11.
 */

public class OAResetPasswordActivity extends ResetPasswordActivity {

    private String mEntrance = ENTRANCE_LOGIN;//界面启动入口
    public static final String ENTRANCE_LOGIN = "login";//从登录进入
    public static final String ENTRANCE_APP = "app";//从App内进入
    private TextView chosedCountryNum, chosedCountryNumSub;
    private ImageView countryChooseButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        try {
            mEntrance = this.getIntent().getStringExtra("entrance");
            if (mEntrance == null) {
                mEntrance = ENTRANCE_LOGIN;
            }
        } catch (Exception e) {
            e.printStackTrace();
            mEntrance = ENTRANCE_LOGIN;
        }
        super.onCreate(savedInstanceState);
        findViewById(R.id.aliuser_appbar).setVisibility(View.GONE);

        OATitleBar titleBar = findViewById(R.id.oat_title);
        if (ENTRANCE_LOGIN.equalsIgnoreCase(mEntrance)) {
            titleBar.setType(OATitleBar.TYPE_IMAGE);
            titleBar.setTitle(getString(R.string.account_find_password));
        } else {
            titleBar.setType(OATitleBar.TYPE_SIMPLE);
            titleBar.setTitle(getString(R.string.account_change_password));
        }
        titleBar.setBackClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
        this.next.setOnClickListener(new NetworkCheckOnClickListener() {
            public void afterCheck(View var1) {
                ckeckSmsCode((String) null, (String) null, (String) null);
            }
        });

        chosedCountryNum = (TextView) mobileInputBox.findViewById("edt_chosed_country_num");
        chosedCountryNumSub = (TextView) mobileInputBox.findViewById("edt_chosed_country_num_sub");
        countryChooseButton = (ImageView) mobileInputBox.findViewById("country_choose_btn");
        chosedCountryNum.setTextSize(TypedValue.COMPLEX_UNIT_DIP, 18);
        chosedCountryNum.setTextColor(getResources().getColor(R.color.color_999999));
        chosedCountryNumSub.setTextColor(getResources().getColor(R.color.color_999999));
        setViewOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent();
                intent.setClass(OAResetPasswordActivity.this, OpenAccountUIConfigs.MobileResetPasswordLoginFlow.mobileCountrySelectorActvityClazz);
                intent.putExtra("entrance", mEntrance);
                startActivityForResult(intent, RequestCode.MOBILE_COUNTRY_SELECTOR_REQUEST);
            }
        }, chosedCountryNum, chosedCountryNumSub, countryChooseButton);
    }


    @Override
    protected void useCustomAttrs(Context context, AttributeSet attrs) {
        upDateUI();
        this.mobileInputBox.setInputHint("");


    }

    private void setViewOnClickListener(View.OnClickListener var1, View... var2) {
        View[] var3 = var2;
        int var4 = var2.length;

        for (int var5 = 0; var5 < var4; ++var5) {
            View var6 = var3[var5];
            if (var6 != null) {
                var6.setOnClickListener(var1);
            }
        }

    }

    @Override
    protected void onPostCreate(@Nullable Bundle savedInstanceState) {
        super.onPostCreate(savedInstanceState);


        try {
            if (ENTRANCE_APP.equalsIgnoreCase(mEntrance)) {
                String mobile = this.getIntent().getStringExtra("mobile");
                this.mLocationCode = this.getIntent().getStringExtra("LocationCode");
                if (!TextUtils.isEmpty(mobile) && OpenAccountUtils.isNumeric(mobile)) {
                    this.mobileInputBox.getEditText().setText(mobile);
                    this.mobileInputBox.getEditText().setEnabled(false);
                    this.mobileInputBox.getEditText().setFocusable(false);
                    this.mobileInputBox.getClearTextView().setVisibility(View.GONE);
                }
                if (!TextUtils.isEmpty(this.mLocationCode)) {
                    this.mobileInputBox.setMobileLocationCode(this.mLocationCode);
                }

            }
        } catch (Exception e) {
            e.printStackTrace();
        }


    }

    @Override
    protected void attachBaseContext(Context newBase) {
        super.attachBaseContext(OALanguageHelper.attachBaseContext(newBase));
    }

    private void upDateUI() {
        Button btnSend = smsCodeInputBox.findViewById(R.id.send);
        btnSend.setText(ResourceUtils.getString(this, "account_send_verify_code"));
        btnSend.setTextSize(12);
        btnSend.setMaxLines(2);
        btnSend.setMaxWidth((int) (getResources().getDisplayMetrics().widthPixels * 0.3f));
        btnSend.setTextAlignment(TEXT_ALIGNMENT_INHERIT);
        btnSend.setGravity(Gravity.END | Gravity.CENTER_VERTICAL);
        btnSend.setTextColor(ContextCompat.getColor(this, R.color.common_colorAccent));

        try {
            LinearLayout parentView = (LinearLayout) btnSend.getParent();
            LinearLayout.LayoutParams layoutParams = (LinearLayout.LayoutParams) parentView.getLayoutParams();
            layoutParams.gravity = Gravity.RIGHT;
            layoutParams.width = LinearLayout.LayoutParams.WRAP_CONTENT;
            parentView.setLayoutParams(layoutParams);
        } catch (Exception e) {
            e.printStackTrace();
        }


        smsCodeInputBox.getChildAt(1).setVisibility(View.GONE);
        View view = smsCodeInputBox.getChildAt(2);
        ViewGroup.LayoutParams layoutParams = view.getLayoutParams();
        layoutParams.width = ViewGroup.LayoutParams.WRAP_CONTENT;
        view.setLayoutParams(layoutParams);
        smsCodeInputBox.findViewById(R.id.left_icon).setVisibility(View.GONE);
        setCursorDrawableColor(smsCodeInputBox.getEditText(), ResourceUtils.getRDrawable(this, "et_cursor_color"));
        setCursorDrawableColor(mobileInputBox.getEditText(), ResourceUtils.getRDrawable(this, "et_cursor_color"));


    }

    /**
     * 取消主题透明栏状态
     */
    private final void unTranparent() {
        Window window = getWindow();
        window.clearFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS
                | WindowManager.LayoutParams.FLAG_TRANSLUCENT_NAVIGATION | WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS);
    }


    public void setCursorDrawableColor(EditText editText, int color) {
        try {
            Field f = TextView.class.getDeclaredField("mCursorDrawableRes");
            f.setAccessible(true);
            f.set(editText, color);
        } catch (Exception ignored) {
            ignored.printStackTrace();
        }
    }


    @Override
    protected void initSystemUI() {
        if (ENTRANCE_LOGIN.equalsIgnoreCase(mEntrance)) {
            super.initSystemUI();
        } else {
            unTranparent();
        }

    }


    private void ckeckSmsCode(String var1, String var2, String var3) {
        (new OAResetPasswordActivity.OACheckSmsCodeForResetPasswordTask(this, var1, var2, var3)).execute(new Void[0]);
    }


    protected void onActivityResult(int var1, int var2, Intent var3) {
        if (var1 == RequestCode.NO_CAPTCHA_REQUEST_CODE) {
            if (var2 == -1) {
                if (var3 != null && "nocaptcha".equals(var3.getStringExtra("action"))) {
                    String var4 = var3.getStringExtra("cSessionId");
                    String var5 = var3.getStringExtra("nocToken");
                    String var6 = var3.getStringExtra("sig");
                    this.ckeckSmsCode(var4, var5, var6);
                    return;
                }
            }
        }
        super.onActivityResult(var1, var2, var3);


    }

    public class OACheckSmsCodeForResetPasswordTask extends CheckSmsCodeForResetPasswordTask {

        public OACheckSmsCodeForResetPasswordTask(Activity activity, String s, String s1, String s2) {
            super(activity, s, s1, s2);
        }

        protected void doSuccessAfterToast(Result<f> var1) {
            Intent var2 = new Intent(OAResetPasswordActivity.this, OpenAccountUIConfigs.MobileResetPasswordLoginFlow.resetPasswordPasswordActivityClazz);
            var2.putExtra("token", ((f) var1.data).a);
            var2.putExtra("entrance", mEntrance);
            OAResetPasswordActivity.this.startActivityForResult(var2, 1);
        }

    }


}
