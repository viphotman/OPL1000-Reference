package com.aliyun.iot.aep.oa.auth.listener;

/**
 * Created by feijie.xfj on 18/4/2.
 */

public interface AliYunAuthRequestListener {
    /**
     * response 为通用格式，由业务方自己处理返回值，并保存需要的字段
     */
    void onResponse(String response);

    void onFailed(String error);
}
