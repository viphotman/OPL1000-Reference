package com.aliyun.iot.aep.oa;

import android.content.Context;
import android.content.res.Configuration;
import android.os.Build;
import android.os.LocaleList;
import android.text.TextUtils;

import com.alibaba.sdk.android.openaccount.ConfigManager;
import com.alibaba.sdk.android.openaccount.config.LanguageCode;

import java.util.Locale;

/**
 * Created by feijie.xfj on 18/5/22.
 */

public class OALanguageHelper {

    public static Context attachBaseContext(Context newBase) {
        if (Build.VERSION.SDK_INT >= 24 && !TextUtils.isEmpty(OAUIInitHelper.LANGUAGE) &&
                !TextUtils.isEmpty(OAUIInitHelper.COUNTRY)) {

            Configuration configuration = newBase.getResources().getConfiguration();
            Locale locale = null;
            try {
                locale = new Locale(OAUIInitHelper.LANGUAGE, OAUIInitHelper.COUNTRY);
            } catch (Exception e) {
                e.printStackTrace();
            }
            configuration.setLocales(new LocaleList(locale));
            Context context = newBase.createConfigurationContext(configuration);
            if ("zh".equalsIgnoreCase(OAUIInitHelper.LANGUAGE)) {
                ConfigManager.getInstance().setLanguageCode(LanguageCode.CHINESE);
            } else if ("en".equalsIgnoreCase(OAUIInitHelper.LANGUAGE)) {
                ConfigManager.getInstance().setLanguageCode(LanguageCode.ENGLISH);
            }else if("fr".equalsIgnoreCase(OAUIInitHelper.LANGUAGE)){
                ConfigManager.getInstance().setLanguageCode("fr_FR");
            }else if("de".equalsIgnoreCase(OAUIInitHelper.LANGUAGE)){
                ConfigManager.getInstance().setLanguageCode("de_DE");
            }
            return context;
        }
        if ("zh".equalsIgnoreCase(OAUIInitHelper.LANGUAGE)) {
            ConfigManager.getInstance().setLanguageCode(LanguageCode.CHINESE);

        } else if ("en".equalsIgnoreCase(OAUIInitHelper.LANGUAGE)) {
            ConfigManager.getInstance().setLanguageCode(LanguageCode.ENGLISH);
        }else if("fr".equalsIgnoreCase(OAUIInitHelper.LANGUAGE)){
            ConfigManager.getInstance().setLanguageCode("fr_FR");
        }else if("de".equalsIgnoreCase(OAUIInitHelper.LANGUAGE)){
            ConfigManager.getInstance().setLanguageCode("de_DE");
        }
        return newBase;
    }

}
