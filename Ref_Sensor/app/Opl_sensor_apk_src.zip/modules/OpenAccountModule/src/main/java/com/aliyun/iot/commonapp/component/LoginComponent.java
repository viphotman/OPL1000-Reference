package com.aliyun.iot.commonapp.component;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;

import com.aliyun.iot.aep.oa.page.OALoginActivity;
import com.aliyun.iot.componentmanager.Component;
import com.aliyun.iot.componentmanager.ComponentInterface;

/**
 * @author sinyuk
 * @date 2019/1/2
 */
@SuppressWarnings("unused")
public class LoginComponent implements ComponentInterface {
    @Override
    public void init(Context context) {

    }

    public void toLogin(Context context, Component.PageRequest request) {
        Intent intent = new Intent(context, OALoginActivity.class);
        if (null != request.getBundle()) {
            intent.putExtras(request.getBundle());
        }
        if (request.isNeedForResult()) {
            ((Activity) context).startActivityForResult(intent, request.getRequestCode());
        } else {
            context.startActivity(intent);
        }
    }
}
