package com.aliyun.iot.aep.oa.page;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.content.ContextCompat;
import android.text.TextUtils;
import android.util.AttributeSet;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.alibaba.sdk.android.openaccount.model.Result;
import com.alibaba.sdk.android.openaccount.task.TaskWithDialog;
import com.alibaba.sdk.android.openaccount.ui.OpenAccountUIConfigs;
import com.alibaba.sdk.android.openaccount.ui.model.EmailRegisterResult;
import com.alibaba.sdk.android.openaccount.ui.ui.EmailResetPasswordActivity;
import com.alibaba.sdk.android.openaccount.ui.util.e;
import com.alibaba.sdk.android.openaccount.util.OpenAccountUtils;
import com.alibaba.sdk.android.openaccount.util.ResourceUtils;
import com.alibaba.sdk.android.openaccount.util.RpcUtils;
import com.aliyun.iot.aep.widget.OATitleBar;
import com.aliyun.iot.commonapp.login.R;

import org.json.JSONObject;

import java.lang.reflect.Field;
import java.util.HashMap;

import static android.view.View.TEXT_ALIGNMENT_INHERIT;

/**
 * @author sinyuk
 */
public class OAResetMailPasswordActivity extends EmailResetPasswordActivity {


    private String mEntrance = ENTRANCE_LOGIN;//界面启动入口
    public static final String ENTRANCE_LOGIN = "login";//从登录进入
    public static final String ENTRANCE_APP = "app";//从App内进入


    @Override
    protected void onCreate(Bundle savedInstanceState) {

        try {
            mEntrance = this.getIntent().getStringExtra("entrance");
            if (mEntrance == null) {
                mEntrance = ENTRANCE_LOGIN;
            }
        } catch (Exception e) {
            e.printStackTrace();
            mEntrance = ENTRANCE_LOGIN;
        }
        super.onCreate(savedInstanceState);
        findViewById(R.id.aliuser_appbar).setVisibility(View.GONE);

        OATitleBar oaTitleBar = findViewById(R.id.oat_title);

        if (ENTRANCE_LOGIN.equalsIgnoreCase(mEntrance)) {
            oaTitleBar.setType(OATitleBar.TYPE_IMAGE);
            oaTitleBar.setTitle(getString(R.string.account_find_password));
        } else {
            oaTitleBar.setType(OATitleBar.TYPE_SIMPLE);
            oaTitleBar.setTitle(getString(R.string.account_change_password));
        }

        oaTitleBar.setBackClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
    }


    @Override
    protected void onPostCreate(@Nullable Bundle savedInstanceState) {
        super.onPostCreate(savedInstanceState);
        try {
            if (ENTRANCE_APP.equalsIgnoreCase(mEntrance)) {
                String email = getIntent().getStringExtra("mail_id");
                mailInputBox.getEditText().setText(email);
                mailInputBox.getEditText().setEnabled(false);
                mailInputBox.getClearTextView().setVisibility(View.GONE);
                mailInputBox.getEditText().setFocusable(false);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Override
    protected void useCustomAttrs(Context context, AttributeSet attrs) {
        upDateUI();
    }


    private void upDateUI() {
        Button btnSend = checkCodeInputBox.findViewById(R.id.send);
        btnSend.setText(ResourceUtils.getString(this, "account_send_email_code"));
        btnSend.setTextSize(12);
        btnSend.setTextColor(ContextCompat.getColor(this, R.color.common_colorAccent));
        btnSend.setMaxLines(2);
        btnSend.setTextAlignment(TEXT_ALIGNMENT_INHERIT);
        btnSend.setGravity(Gravity.END | Gravity.CENTER_VERTICAL);
        btnSend.setMaxWidth((int) (getResources().getDisplayMetrics().widthPixels * 0.3f));
        try {
            View view = checkCodeInputBox.getChildAt(2);
            ViewGroup.LayoutParams layoutParams = view.getLayoutParams();
            layoutParams.width = LinearLayout.LayoutParams.WRAP_CONTENT;
            view.setLayoutParams(layoutParams);
        } catch (Exception e) {
            e.printStackTrace();
        }
        checkCodeInputBox.getChildAt(1).setVisibility(View.GONE);
        checkCodeInputBox.findViewById(R.id.left_icon).setVisibility(View.GONE);
        mailInputBox.getLeftIcon().setVisibility(View.GONE);
        setCursorDrawableColor(checkCodeInputBox.getEditText(), ResourceUtils.getRDrawable(this, "et_cursor_color"));
        setCursorDrawableColor(mailInputBox.getEditText(), ResourceUtils.getRDrawable(this, "et_cursor_color"));
    }


    public void setCursorDrawableColor(EditText editText, int color) {
        try {
            Field f = TextView.class.getDeclaredField("mCursorDrawableRes");
            f.setAccessible(true);
            f.set(editText, color);
        } catch (Exception ignored) {
            ignored.printStackTrace();
        }
    }

    @Override
    protected void goVerifyEmailCode() {
        (new OAResetMailPasswordActivity.CheckEmailTask(this)).execute(new Void[0]);
    }


    @Override
    protected void initSystemUI() {
        if (ENTRANCE_LOGIN.equalsIgnoreCase(mEntrance)) {
            super.initSystemUI();
        } else {
            unTranparent();
        }

    }

    /**
     * 取消主题透明栏状态
     */
    private final void unTranparent() {
        Window window = getWindow();
        window.clearFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS
                | WindowManager.LayoutParams.FLAG_TRANSLUCENT_NAVIGATION | WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS);
    }


    class CheckEmailTask extends TaskWithDialog<Void, Void, Result<EmailRegisterResult>> {
        public CheckEmailTask(Activity var2) {
            super(var2);
        }

        protected Result<EmailRegisterResult> asyncExecute(Void... var1) {
            HashMap var2 = new HashMap();
            var2.put("email", OAResetMailPasswordActivity.this.mailInputBox.getEditText().getText());
            var2.put("actionType", "sdk_email_reset_password");
            var2.put("emailToken", OAResetMailPasswordActivity.this.checkCodeInputBox.getInputBoxWithClear().getEditTextContent());
            return this.parseJsonResult(RpcUtils.invokeWithRiskControlInfo("checkEmailTokenRequest", var2, "emailvalidatetoken"));
        }

        protected Result<EmailRegisterResult> parseJsonResult(Result<JSONObject> var1) {
            return var1.data == null ? Result.result(var1.code, var1.message, new EmailRegisterResult()) : Result.result(var1.code, var1.message, this.getEmailRegisterResult((JSONObject) var1.data));
        }

        protected EmailRegisterResult getEmailRegisterResult(JSONObject var1) {
            EmailRegisterResult var2 = new EmailRegisterResult();
            if (var1.has("loginSuccessResult")) {
                var2.loginSuccessResult = OpenAccountUtils.parseLoginSuccessResult(var1);
            }

            return var2;
        }

        protected void doWhenException(Throwable var1) {
        }

        protected void onPostExecute(Result<EmailRegisterResult> var1) {
            super.onPostExecute(var1);
            if (var1 == null) {
                e.a(this.context);
            } else {
                switch (var1.code) {
                    case 1:
                        Intent var2 = new Intent(OAResetMailPasswordActivity.this, OpenAccountUIConfigs.EmailResetPasswordLoginFlow.resetPasswordActivityClazz);
                        var2.putExtra("emailToken", OAResetMailPasswordActivity.this.checkCodeInputBox.getInputBoxWithClear().getEditTextContent());
                        var2.putExtra("email", OAResetMailPasswordActivity.this.mailInputBox.getEditText().getText().toString());
                        var2.putExtra("entrance", mEntrance);
                        OAResetMailPasswordActivity.this.startActivityForResult(var2, 1);
                        break;
                    default:
                        if (TextUtils.isEmpty(var1.message)) {
                            e.a(this.context);
                        } else {
                            e.a(this.context, var1.message, var1.code);
                        }
                }

            }
        }
    }

}
