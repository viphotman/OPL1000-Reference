package com.aliyun.iot.aep.oa.page;

import android.animation.ObjectAnimator;
import android.animation.ValueAnimator;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Build;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.webkit.CookieManager;
import android.widget.Toast;

import com.alibaba.fastjson.JSONObject;
import com.alibaba.sdk.android.oauth.OauthPlateform;
import com.alibaba.sdk.android.openaccount.ConfigManager;
import com.alibaba.sdk.android.openaccount.OpenAccountSDK;
import com.alibaba.sdk.android.openaccount.OpenAccountService;
import com.alibaba.sdk.android.openaccount.callback.LoginCallback;
import com.alibaba.sdk.android.openaccount.model.OpenAccountSession;
import com.alibaba.sdk.android.openaccount.ui.ui.LoginActivity;
import com.aliyun.iot.aep.oa.auth.AliYunAuthClient;
import com.aliyun.iot.aep.oa.auth.listener.AliYunAuthRequestListener;
import com.aliyun.iot.aep.sdk.credential.IotCredentialManager.IoTCredentialManageImpl;
import com.aliyun.iot.aep.sdk.log.ALog;
import com.aliyun.iot.aep.sdk.login.LoginBusiness;
import com.aliyun.iot.commonapp.login.R;


/**
 * Created by feijie.xfj on 18/1/11.
 */

//这个类保留，请勿删除，仅仅为测试使用
public class OALoginTransparentActivity extends LoginActivity {
    private static final String TAG = "OALoginTransparentActivity";

    private int requestCode_AliYun = 101;

    AliYunAuthClient client;

    private View loadingView;

    private ObjectAnimator mRotaion;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        TRANSPARENT();
        findViewById(R.id.aliuser_appbar).setVisibility(View.GONE);

        findViewById(R.id.main).setVisibility(View.GONE);
        //这里设置为阿里云账户类型
        IoTCredentialManageImpl.getInstance(getApplication()).setAccountType("aliyun");

        callAliYunAuthRequest();

        //单独处理UI
        loadingView = findViewById(R.id.account_loading);

        showLoading();
    }

    public void showLoading() {
        if (mRotaion == null) {
            mRotaion = ObjectAnimator.ofFloat(loadingView, "rotation", 0, 180);
            mRotaion.setDuration(2000);
            mRotaion.setRepeatCount(ValueAnimator.INFINITE);
        }
        mRotaion.cancel();
        mRotaion.start();
    }


    public void stopAnimation() {
        if (mRotaion != null) {
            mRotaion.cancel();
        }
    }


    private void callAliYunAuthRequest() {
        String oauth_consumer_key = getIntent().getStringExtra("auth_consumer_key");// appKey
        String oauth_consumer_secret = getIntent().getStringExtra("auth_consumer_secret");// appSecret
        if (TextUtils.isEmpty(oauth_consumer_key) || TextUtils.isEmpty(oauth_consumer_secret)) {
            Toast.makeText(getApplicationContext(), "auth_consumer_key or auth_consumer_secret is empty", Toast.LENGTH_SHORT).show();
            finish();
            return;
        }

        client = new AliYunAuthClient(oauth_consumer_key, oauth_consumer_secret, LoginBusiness.getEnv(), getApplication());
        client.callAliYunAuthRequest(new AliYunAuthLoginRequestListener());
    }

    @Override
    protected void onDestroy() {
        stopAnimation();
        super.onDestroy();
    }

    private String oauth_token = "", oauth_token_secret = "";

    //获取RequestToken listener -- Step 1
    private class AliYunAuthLoginRequestListener implements AliYunAuthRequestListener {
        @Override
        public void onResponse(String response) {
            //先将临时变量清空，防止重复请求
            oauth_token = "";
            oauth_token_secret = "";
            if (!TextUtils.isEmpty(response)) {
                String[] params = response.split("&");
                for (String param : params) {
                    String[] s = param.split("=");
                    if ("oauth_token".equals(s[0])) {
                        ALog.i(TAG, "oauth_token is:" + s[1]);
                        oauth_token = s[1];
                    } else if ("oauth_token_secret".equals(s[0])) {
                        ALog.i(TAG, "oauth_token_secret is:" + s[1]);
                        oauth_token_secret = s[1];
                    }
                }
                if (!TextUtils.isEmpty(oauth_token) && !TextUtils.isEmpty(oauth_token_secret)) {
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            Intent intent = new Intent(OALoginTransparentActivity.this, AliyunWebActivity.class);
                            intent.putExtra("auth_token", oauth_token);
                            startActivityForResult(intent, requestCode_AliYun);
                        }
                    });
                    return;
                }
            }
            ALog.i(TAG, "get authRquestToken failed:" + response);
            errorAndExit(response, -1);
        }

        @Override
        public void onFailed(String error) {
            ALog.i(TAG, "get authRquestToken failed:" + error);
            if (!isNetworkAvailable(getApplication())) {//如果网络不可用，直接退出 -- 500表示网络异常
                errorAndExit(getString(R.string.account_network_anomaly), 500);
                return;
            }
            errorAndExit(error, -1);
        }
    }

    private void errorAndExit(final String error, int errorCode) {

        //强制清除WebView cache
        CookieManager cookieManager = CookieManager.getInstance();

        ALog.i(TAG, "errorAndExit():" + error + " ---- remove all cookie");
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            cookieManager.removeAllCookies(null);
        } else {
            cookieManager.removeAllCookie();
        }

        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                ALog.i(TAG, getString(R.string.account_auth_login_failed) + error);
                LoginCallback loginCallback = OALoginTransparentActivity.this.getLoginCallback();
                if (loginCallback != null) {
                    //如果是时间异常，给出特定提示
                    try {
                        JSONObject jb = JSONObject.parseObject(error);
                        if (jb.containsKey("errorCode")) {
                            if (TextUtils.equals("40103", jb.getString("errorCode"))) {
                                loginCallback.onFailure(40103, getString(R.string.account_auth_login_failed) + "：" + getString(R.string.account_error_time));
                                finish();
                                return;
                            }
                        }
                    } catch (Exception e) {

                    }
                    if (TextUtils.isEmpty(error)) {
                        loginCallback.onFailure(-1, getString(R.string.account_auth_login_failed));
                    } else {
                        loginCallback.onFailure(-1, error);
                    }
                }
                ALog.i(TAG, "finish OALoginTransparentActivity");
                finish();
            }
        });
    }

    //获取AccessToken listener -- Step 2
    private class AliYunAccessTokenRequestListener implements AliYunAuthRequestListener {

        @Override
        public void onResponse(String response) {
            ALog.i(TAG, "AliYunAccessTokenRequestListener : onResponse(): " + response);
            if (!TextUtils.isEmpty(response)) {
                String[] params = response.split("&");
                String accessToken = "", tokenSecret = "";
                for (String param : params) {
                    String[] s = param.split("=");
                    if ("oauth_token".equals(s[0])) {
                        accessToken = s[1];
                        ALog.i(TAG, "AccessToken is " + s[1]);
                    } else if ("oauth_token_secret".equals(s[0])) {
                        tokenSecret = s[1];
                        ALog.i(TAG, "AccessTokenSecret is " + s[1]);
                    }
                }
                if (!TextUtils.isEmpty(accessToken) && !TextUtils.isEmpty(tokenSecret)) {
                    authLoginForAliYun(accessToken, tokenSecret);
                    return;
                }
            }
            errorAndExit(getString(R.string.account_get_accesstoken_error), 502);
        }

        @Override
        public void onFailed(String error) {
            ALog.i(TAG, "AliYunAccessTokenRequestListener : onFailed(): " + error);
            errorAndExit(getString(R.string.account_get_accesstoken_error) + error, 502);
        }
    }

    private void authLoginForAliYun(String access_token, String tokenSecret) {
        ConfigManager.getInstance().putExtBizParam("tokenSec", tokenSecret);
        OpenAccountService service = OpenAccountSDK.getService(OpenAccountService.class);
        try {
            service.accessTokenLogin(this, access_token,
                    OauthPlateform.ALIYUN_AUTH, new LoginCallback() {
                        @Override
                        public void onSuccess(OpenAccountSession openAccountSession) {
                            ALog.i(TAG, "authCode 成功");
                            LoginCallback loginCallback = OALoginTransparentActivity.this.getLoginCallback();
                            if (loginCallback != null) {
                                loginCallback.onSuccess(openAccountSession);
                                OALoginTransparentActivity.this.finishWithoutCallback();
                            }
                        }

                        @Override
                        public void onFailure(int code, String msg) {
                            ALog.i(TAG, "authCode 失败" + msg);
                            LoginCallback loginCallback = OALoginTransparentActivity.this.getLoginCallback();
                            if (loginCallback != null) {
                                loginCallback.onFailure(code, msg);
                            }
                            stopAnimation();
                            errorAndExit(msg, 501);
                        }
                    });
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        ALog.i(TAG, "onActivityResult () resultCode:" + resultCode);

        if (requestCode == this.requestCode_AliYun) {
            if (resultCode == RESULT_CANCELED) {
                LoginCallback loginCallback = OALoginTransparentActivity.this.getLoginCallback();
                if (loginCallback != null) {
                    loginCallback.onFailure(10003, "cancel login");
                }
                stopAnimation();
                finish();
                return;
            }
            if (data != null) {
                String oauth_token = data.getStringExtra("oauth_token");
                String oauth_verifier = data.getStringExtra("oauth_verifier");
                //Toast.makeText(getApplicationContext(), "阿里云登录成功", Toast.LENGTH_SHORT).show();
                ALog.i(TAG, "oauth_token:" + oauth_token + "  oauth_verifier:" + oauth_verifier);
                client.callGetAliYunAccessTokenRequest(oauth_token, oauth_verifier, oauth_token_secret, new AliYunAccessTokenRequestListener());
                return;
            }
        }
        errorAndExit(getString(R.string.account_auth_login_failed), 503);
    }

    protected final void TRANSPARENT() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            Window window = getWindow();
            window.clearFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS
                    | WindowManager.LayoutParams.FLAG_TRANSLUCENT_NAVIGATION);
            window.getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                    | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                    | View.SYSTEM_UI_FLAG_LAYOUT_STABLE);
            window.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS);
            window.setStatusBarColor(Color.TRANSPARENT);
            window.setNavigationBarColor(Color.TRANSPARENT);
        }
    }


    public static boolean isNetworkAvailable(Context context) {

        ConnectivityManager manager = (ConnectivityManager) context
                .getApplicationContext().getSystemService(
                        Context.CONNECTIVITY_SERVICE);

        if (manager == null) {
            return false;
        }

        NetworkInfo networkinfo = manager.getActiveNetworkInfo();

        if (networkinfo == null || !networkinfo.isAvailable()) {
            return false;
        }

        return true;
    }
}
