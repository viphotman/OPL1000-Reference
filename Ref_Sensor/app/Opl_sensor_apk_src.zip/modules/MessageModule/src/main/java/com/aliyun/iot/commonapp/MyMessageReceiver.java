package com.aliyun.iot.commonapp;

import android.app.ActivityManager;
import android.content.ActivityNotFoundException;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.text.TextUtils;
import android.util.Log;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.alibaba.sdk.android.push.MessageReceiver;
import com.alibaba.sdk.android.push.notification.CPushMessage;
import com.aliyun.iot.commonapp.base.ui.WebViewActivity;
import com.aliyun.iot.commonapp.message.BuildConfig;

import static android.app.ActivityManager.RunningAppProcessInfo.IMPORTANCE_FOREGROUND;
import static android.app.ActivityManager.RunningAppProcessInfo.IMPORTANCE_VISIBLE;
import static com.aliyun.iot.commonapp.base.ui.WebViewActivity.URL_REGEX;

import java.util.Map;


/**
 * @author sinyuk
 */
public class MyMessageReceiver extends MessageReceiver {
    /**
     * 消息接收部分的LOG_TAG
     */
    private static final String REC_TAG = "receiver";


    @Override
    public void onNotification(Context context, String title, String summary, Map<String, String> extraMap) {
        Log.e(REC_TAG, "Receive notification, title: " + title + ", summary: " + summary + ", extraMap: " + extraMap);
    }

    @Override
    public void onMessage(Context context, CPushMessage cPushMessage) {
        Log.e(REC_TAG, "onMessage, messageId: " + cPushMessage.getMessageId() + ", title: " + cPushMessage.getTitle() + ", content:" + cPushMessage.getContent());
        onNewIntent(context, cPushMessage.getContent());
    }

    @Override
    public void onNotificationOpened(Context context, String title, String summary, String extraMap) {
        Log.e(REC_TAG, "onNotificationOpened, title: " + title + ", summary: " + summary + ", extraMap:" + extraMap);
    }

    @Override
    protected void onNotificationClickedWithNoAction(Context context, String title, String summary, String extraMap) {
        Log.e(REC_TAG, "onNotificationClickedWithNoAction, title: " + title + ", summary: " + summary + ", extraMap:" + extraMap);
        onNewIntent(context, extraMap);
    }

    /**
     * 处理消息和通知类型
     *
     * @param context Application context
     * @param content json
     */
    private void onNewIntent(Context context, String content) {
        try {
            JSONObject jsonObject = (JSONObject) JSON.parse(content);
            if (jsonObject.containsKey("url")) {
                String url = jsonObject.getString("url");
                if (TextUtils.isEmpty(url) || !url.matches(URL_REGEX)) {
                    startApplication(context);
                } else {
                    startWebViewActivity(context, url);
                }
            } else {
                startApplication(context);
            }
        } catch (Exception e) {
            e.printStackTrace();
            startApplication(context);
        }
    }

    private void startWebViewActivity(Context context, String url) {
        try {
            Intent intent = new Intent(context, WebViewActivity.class);
            intent.setFlags(Intent.FLAG_ACTIVITY_EXCLUDE_FROM_RECENTS | Intent.FLAG_ACTIVITY_NEW_TASK);
            intent.setData(Uri.parse(url));
            context.startActivity(intent);
        } catch (ActivityNotFoundException e) {
            e.printStackTrace();
        }
    }


    @Override
    protected void onNotificationReceivedInApp(Context context, String title, String summary, Map<String, String> extraMap, int openType, String openActivity, String openUrl) {
        Log.e(REC_TAG, "onNotificationReceivedInApp, title: " + title + ", summary: " + summary + ", extraMap:" + extraMap + ", openType:" + openType + ", openActivity:" + openActivity + ", openUrl:" + openUrl);

    }

    @Override
    protected void onNotificationRemoved(Context context, String messageId) {
        Log.e(REC_TAG, "onNotificationRemoved");
    }

    private void startApplication(Context context) {
        if (foregrounded()) {
            return;
        } else if (isAppInstalled(context)) {
            Intent i = context.getPackageManager().getLaunchIntentForPackage(BuildConfig.PACKAGE_NAME);
            if (i != null) {
                i.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                context.startActivity(i);
            }
        }
    }

    private boolean isAppInstalled(Context context) {
        PackageManager pm = context.getPackageManager();
        try {
            pm.getPackageInfo(BuildConfig.PACKAGE_NAME, PackageManager.GET_ACTIVITIES);
            return true;
        } catch (PackageManager.NameNotFoundException e) {
            Log.e(REC_TAG, "isAppInstalled()", e);
        }
        return false;
    }

    private boolean foregrounded() {
        ActivityManager.RunningAppProcessInfo appProcessInfo = new ActivityManager.RunningAppProcessInfo();
        ActivityManager.getMyMemoryState(appProcessInfo);
        return (appProcessInfo.importance == IMPORTANCE_FOREGROUND || appProcessInfo.importance == IMPORTANCE_VISIBLE);
    }
}