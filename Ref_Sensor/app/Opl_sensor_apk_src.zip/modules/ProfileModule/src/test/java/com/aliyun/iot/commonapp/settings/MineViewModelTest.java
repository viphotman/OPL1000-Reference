package com.aliyun.iot.commonapp.settings;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;

import org.junit.Before;
import org.junit.Test;

import static org.junit.Assert.*;

/**
 * @author sinyuk
 * @date 2019/1/15
 */
public class MineViewModelTest {
    private static final String JSON_TEXT = "{\"name\":\"ProfileModule\",\"alias\":\"设置组件\",\"desc\":\"描述\",\"version\":\"版本\",\"target\":\"com.aliyun.iot.commonapp.component.SettingsComponent\",\"pages\":[{\"name\":\"设置页\",\"method\":\"toSettings\",\"url\":\"ldpapp://settings\",\"args\":[]}],\"actions\":[],\"sdks\":[{\"name\":\"account\",\"version\":\"0.0.3\"}],\"opt\":{\"profileModuleMainList\":[{\"profileModuleMainPageTitle\":\"youku\",\"profileModuleMainPageLink\":\"https://www.youku.com/\"},{\"profileModuleMainPageTitle\":\"baidu\",\"profileModuleMainPageLink\":\"https://www.baidu.com/\"},{\"profileModuleMainPageTitle\":\"aliyun\",\"profileModuleMainPageLink\":\"https://www.aliyun.com/\"},{\"profileModuleMainPageTitle\":\"*youku\",\"profileModuleMainPageLink\":\"https://www.youku.com/\"},{\"profileModuleMainPageTitle\":\"link://boneweb/code?url=\\\"https://www.baidu.com/\\\"\",\"profileModuleMainPageLink\":\"link://boneweb/code?url=\\\"https://www.baidu.com/\\\"\"},{\"profileModuleMainPageTitle\":\"link://boneweb/code?url=https://www.aliyun.com/\",\"profileModuleMainPageLink\":\"link://boneweb/code?url=https://www.aliyun.com/\"}],\"profilePrivacyURL\":\"link://boneweb/code?url=https://www.baidu.com\"}}";


    private MineViewModel viewModel;

    @Before
    public void setup() {
        JSONObject jsonObject = JSON.parseObject(JSON_TEXT);
        JSONObject opt = jsonObject.getJSONObject("opt");
        viewModel = new MineViewModel();
        viewModel.mockOpts(opt);
    }

    @Test
    public void privacyURL() {
        assert viewModel.privacyURL().equals("link://boneweb/code?url=https://www.baidu.com");
    }

    @Test
    public void templates() {
        System.out.println(JSON.toJSONString(viewModel.convertJSON()));
        assert viewModel.convertJSON().size() == 6;
    }

}