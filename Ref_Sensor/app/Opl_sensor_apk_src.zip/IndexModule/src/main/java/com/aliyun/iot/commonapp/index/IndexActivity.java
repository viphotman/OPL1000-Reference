package com.aliyun.iot.commonapp.index;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.net.Uri;
import android.os.Bundle;
import android.os.Parcel;
import android.support.annotation.Nullable;
import android.support.design.widget.TabLayout;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentPagerAdapter;
import android.support.v4.view.ViewPager;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.AppCompatImageView;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.aliyun.iot.aep.component.router.Router;
import com.aliyun.iot.aep.sdk.login.ILogoutCallback;
import com.aliyun.iot.aep.sdk.login.LoginBusiness;
import com.aliyun.iot.commonapp.base.ui.LinkAlertDialog;
import com.aliyun.iot.commonapp.base.ui.LinkToast;
import com.aliyun.iot.componentmanager.Component;
import com.aliyun.iot.componentmanager.ComponentManager;

import java.util.ArrayList;
import java.util.List;

import static com.aliyun.iot.commonapp.base.Constants.LOGOUT_ACTION;
import static com.aliyun.iot.commonapp.base.ui.WebViewActivity.URL_REGEX;
import static com.aliyun.iot.commonapp.base.ui.WebViewActivity.URL_REGEX_2;

/**
 * @author sinyuk
 * @date 2018/12/19
 */
@SuppressWarnings("ALL")
public class IndexActivity extends AppCompatActivity {
    private static final int REQUEST_CODE_SCAN = 0x1234;
    private static final int REQUEST_CODE_CONNECT_CONFIG = 0x2345;
    private static final int REQUEST_CODE_DEVICE_BIND = 0x3456;
    private ViewPager viewPager = null;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.index_activity);
        setupViewpager(getPrimaryItemFromIntent(getIntent()));
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
        if (viewPager != null && viewPager.getAdapter() != null) {
            viewPager.setCurrentItem(getPrimaryItemFromIntent(intent), false);
        }
    }

    private int getPrimaryItemFromIntent(Intent intent) {
        if (intent == null) {
            return 0;
        }
        if (getIntent().getData() == null) {
            return 0;
        }
        if (getIntent().getData().getHost() == null) {
            return 0;
        }
        String host = getIntent().getData().getHost().toLowerCase();
        int currentItem = 0;

        if (host.startsWith("profile")) {
            currentItem = 2;
        } else if (host.startsWith("device")) {
            currentItem = 1;
        }
        return currentItem;
    }

    private List<Fragment> fragments = new ArrayList<>();


    private void setupViewpager(int primaryItem) {
        initFragments();

        if (primaryItem >= fragments.size()) {
            primaryItem = fragments.size() - 1;
        }

        viewPager = findViewById(R.id.viewPager);
        if (0 != primaryItem) {
            Parcel parcel = Parcel.obtain();
            parcel.writeParcelable(View.BaseSavedState.EMPTY_STATE, 0);
            parcel.writeInt(primaryItem);
            parcel.writeParcelable(null, 0);
            parcel.setDataPosition(0);
            ViewPager.SavedState savedState = ViewPager.SavedState.CREATOR.createFromParcel(parcel);
            viewPager.onRestoreInstanceState(savedState);
        }
        tabLayout = findViewById(R.id.tabLayout);
        viewPager.setOffscreenPageLimit(fragments.size() - 1);
        viewPager.setAdapter(new FragmentPagerAdapter(getSupportFragmentManager()) {
            @Override
            public Fragment getItem(int position) {
                return fragments.get(position);
            }

            @Override
            public int getCount() {
                return fragments.size();
            }
        });
        tabLayout.setupWithViewPager(viewPager);
        initTabs();
    }

    private static final String[] REQUIRED_COMPONENTS = new String[]{
            "HomeModule",
            "DeviceModule",
            "ProfileModule"
    };

    private void initFragments() {
        for (String component : REQUIRED_COMPONENTS) {
            Component.ActionResponse response = ComponentManager.getInstance().requestComponentActionSync(
                    new Component.ActionRequest(component, "getView", null));
            Fragment f = null;
            try {
                f = (Fragment) response.getResponse().get("data");
            } catch (NullPointerException e) {
                Log.e("ComponentManager", "init " + component
                        + " failed, because " + e.getLocalizedMessage());
            }

            if (f != null) {
                fragments.add(f);
            }
        }
    }


    private TabLayout tabLayout = null;

    private void initTabs() {
        final String[] titles;
        final int[] icons;
        if (2 == fragments.size()) {
            titles = new String[]{"首页", "我的"};
            icons = new int[]{R.drawable.index_ic_tab_home, R.drawable.index_ic_tab_my};
        } else {
            titles = new String[]{"首页", "设备", "我的"};
            icons = new int[]{R.drawable.index_ic_tab_home, R.drawable.index_ic_tab_scene, R.drawable.index_ic_tab_my};
        }
        for (int i = 0; i < fragments.size(); i++) {
            View view = View.inflate(this, R.layout.custom_tab, null);
            ((TextView) view.findViewById(R.id.text)).setText(titles[i]);
            ((AppCompatImageView) view.findViewById(R.id.icon)).setImageResource(icons[i]);
            //noinspection ConstantConditions
            tabLayout.getTabAt(i).setCustomView(view);
        }
        tabLayout.addOnTabSelectedListener(new TabLayout.OnTabSelectedListener() {
            @Override
            public void onTabSelected(TabLayout.Tab tab) {
                onSelectedStateChanged(tab, true);
            }

            @Override
            public void onTabUnselected(TabLayout.Tab tab) {
                onSelectedStateChanged(tab, false);
            }

            @Override
            public void onTabReselected(TabLayout.Tab tab) {

            }
        });
    }

    private void onSelectedStateChanged(TabLayout.Tab tab, boolean selected) {
        if (tab.getCustomView() == null) {
            return;
        }
        TextView text = tab.getCustomView().findViewById(R.id.text);
        if (text != null) {
            text.setSelected(selected);
        }
        ImageView icon = tab.getCustomView().findViewById(R.id.icon);
        if (icon != null) {
            icon.setSelected(selected);
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        switch (requestCode) {
            case REQUEST_CODE_SCAN: {
                if ((RESULT_OK == resultCode)) {
                    if (data == null) {
                        LinkToast.makeText(this, "二维码解析为空", Toast.LENGTH_LONG).show();
                        return;
                    }
                    // result can be either bar code or failed message
                    String result = data.getStringExtra("data").trim();
                    Uri uri = null;
                    try {
                        uri = Uri.parse(result);
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                    if (null == uri || TextUtils.isEmpty(uri.toString())) {
                        LinkToast.makeText(this, "二维码解析结果: Uri不合法", Toast.LENGTH_LONG).show();
                        return;
                    } else if (null == uri.getQueryParameter("productKey")) {
                        handleQRCode(uri);
                    } else {
                        toConnectConfig(data);
                    }
                } else if (resultCode == RESULT_CANCELED && data != null) {
                    String message = data.getStringExtra("data");
                    if (message != null) {
                        LinkToast.makeText(this, message, Toast.LENGTH_LONG).show();
                    }
                }
                break;
            }
            case REQUEST_CODE_CONNECT_CONFIG: {
                if (resultCode != RESULT_OK || data == null) {
                    return;
                }
                String pk = data.getStringExtra("productKey");
                String dn = data.getStringExtra("deviceName");
                // Alternative
                if (TextUtils.isEmpty(pk)) pk = data.getStringExtra(pk);
                if (pk == null) {
                    return;
                }
                Bundle bundle = new Bundle();
                bundle.putString("productKey", pk);
                bundle.putString("deviceName", dn);
                String url = getString(R.string.default_router_format,
                        getString(R.string.in_app_router_schema),
                        getString(R.string.host_bind_device));
                Router.getInstance().toUrlForResult(this, url, REQUEST_CODE_DEVICE_BIND, bundle);
                break;
            }
            case REQUEST_CODE_DEVICE_BIND: {
                if (resultCode == RESULT_OK || data != null) {
                    Bundle bundle = new Bundle();
                    String productKey = data.getStringExtra("pk");
                    // Alternative
                    if (TextUtils.isEmpty(productKey))
                        productKey = data.getStringExtra("productKey");
                    bundle.putString("productKey", productKey);
                    bundle.putString("deviceName", data.getStringExtra("dn"));
                    bundle.putString("iotId", data.getStringExtra("iotId"));
                    bundle.putString("token", data.getStringExtra("token"));
                    String url = getString(R.string.default_router_format,
                            getString(R.string.plugin_router_schema),
                            getString(R.string.host_plugin_panel_format, productKey));
                    Router.getInstance().toUrl(this, url, bundle);
                }
                break;
            }
            default:
                break;
        }
    }

    private void handleQRCode(Uri uri) {
        final String url = uri.toString();
        if (url.matches(URL_REGEX)) {
            Router.getInstance().toUrl(this, url);
        } else if (url.matches(URL_REGEX_2)) {
            new LinkAlertDialog.Builder(this)
                    .setTitle("是否希望在网页中打开链接: ")
                    .setMessage(url)
                    .setPositiveButton("确定", new LinkAlertDialog.OnClickListener() {
                        @Override
                        public void onClick(LinkAlertDialog dialog) {
                            Router.getInstance().toUrl(IndexActivity.this, url);
                            dialog.dismiss();
                        }
                    })
                    .setNegativeButton("取消", new LinkAlertDialog.OnClickListener() {
                        @Override
                        public void onClick(LinkAlertDialog dialog) {
                            dialog.dismiss();
                        }
                    })
                    .create()
                    .show();
        } else {
            LinkToast.makeText(this, "不支持的二维码", Toast.LENGTH_SHORT).show();
        }
    }

    private void toConnectConfig(Intent data) {
        String url = data.getStringExtra("data");
        try {
            Uri uri = Uri.parse(url);
            String productKey = uri.getQueryParameter("productKey");
            if (TextUtils.isEmpty(productKey)) {
                LinkToast.makeText(this, "二维码中未识别到设备pk", Toast.LENGTH_SHORT).show();
                return;
            }
            String router = "link://plugin/a1231HjhvD1Qrihx";
            Bundle bundle = new Bundle();
            bundle.putString("productKey", productKey);
            Router.getInstance().toUrlForResult(this, router, REQUEST_CODE_CONNECT_CONFIG, bundle);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private LogoutBroadcastReceiver broadcastReceiver = new LogoutBroadcastReceiver();

    @Override
    protected void onResume() {
        super.onResume();
        IntentFilter filter = new IntentFilter();
        filter.addAction(LOGOUT_ACTION);
        registerReceiver(broadcastReceiver, filter);
    }

    @Override
    protected void onPause() {
        super.onPause();
        unregisterReceiver(broadcastReceiver);
    }

    public class LogoutBroadcastReceiver extends BroadcastReceiver {
        private static final String TAG = "LogoutBroadcast";

        @Override
        public void onReceive(Context context, Intent intent) {
            Log.d(TAG, "onReceive: ");
            runOnUiThread(logoutRunnable);
        }
    }

    private final Runnable logoutRunnable = new Runnable() {
        @Override
        public void run() {
            LoginBusiness.logout(new ILogoutCallback() {
                @Override
                public void onLogoutSuccess() {
                    toInit();
                }

                @Override
                public void onLogoutFailed(int i, String s) {
                    toInit();
                }
            });
        }
    };

    private void toInit() {
        if (isFinishing() || isDestroyed()) {
            return;
        }
        String url = getString(R.string.default_router_format,
                getString(R.string.in_app_router_schema),
                getString(R.string.host_main));
        Router.getInstance().toUrl(this, url);
    }
}
