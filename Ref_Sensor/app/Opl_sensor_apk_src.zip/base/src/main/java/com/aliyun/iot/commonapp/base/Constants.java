package com.aliyun.iot.commonapp.base;

/**
 * @author sinyuk
 * @date 2019/1/7
 */
public class Constants {
    public static final String LOGOUT_ACTION = "com.aliyun.iot.commonapp.LOGOUT";
}
