package com.aliyun.iot.commonapp.base.persistent.po;
import org.json.JSONObject;

/**
 * @author sinyuk
 * @date 2019/1/2
 */
public class Product {

    private JSONObject accessMethod;

    public String getAccessMethod() {
        return accessMethod.optString("name");
    }

    public String productModel;
    public long gmtModified;
    public String name;
    private JSONObject netType;
    private JSONObject nodeType;

    public String getNetType() {
        return netType.optString("name");
    }

    public String getNodeType() {
        return nodeType.optString("name");
    }

    public String productId;
    public String productKey;
    public String productSecret;
    public String rbacTenantId;
    public String categoryName;
    private JSONObject dataFormat;

    public String getDataFormat() {
        return dataFormat.optString("name");
    }

    public String categoryKey;
    public long gmtCreate;
    public String domain;
    public String tenantId;
    public String region;
    public int categoryId;
    public JSONObject status;

    public String getStatus() {
        return status.optString("name");
    }

    @Override
    public String toString() {
        return "Product{" +
                "name='" + name + '\'' +
                ", netType='" + getNetType() + '\'' +
                ", productId='" + productId + '\'' +
                ", productKey='" + productKey + '\'' +
                ", categoryName='" + categoryName + '\'' +
                ", categoryKey='" + categoryKey + '\'' +
                '}';
    }
}
