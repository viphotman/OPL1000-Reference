package com.aliyun.iot.commonapp.base.ui;

import android.content.Context;
import android.graphics.Rect;
import android.support.annotation.DimenRes;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.View;

/**
 *
 * @author Sinyuk
 * @date 16.1.21
 */
public class ListItemMarginDecoration extends RecyclerView.ItemDecoration {
    private int mSpace;

    public ListItemMarginDecoration(@DimenRes int resId, Context context) {
        this.mSpace = context.getResources().getDimensionPixelOffset(resId);
    }

    @Override
    public void getItemOffsets(@NonNull Rect outRect, @NonNull View view, @NonNull RecyclerView parent, @NonNull RecyclerView.State state) {
        // item position
        int position = parent.getChildAdapterPosition(view);

        if (position == 0) {
            // top edge
            outRect.top = mSpace;
        }
        outRect.bottom = mSpace;
        // item bottom
    }
}