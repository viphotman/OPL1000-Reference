package com.aliyun.iot.commonapp.base.persistent.po;

import android.support.annotation.NonNull;

/**
 * 展示在工作台自定义创建的H5页面列表，列表内容从服务端接口获取
 * /app/mobile/manifest/template/slot
 *
 * @author sinyuk
 * @date 2018/12/20
 */
public class Template {

    public String title;
    public String des;
    public String imageUrl;
    public String url;

    public Template() {
    }

    public Template(String title, String des, String imageUrl, String url) {
        this.title = title;
        this.des = des;
        this.imageUrl = imageUrl;
        this.url = url;
    }

    @NonNull
    @Override
    public String toString() {
        return "Template{" +
                "title='" + title + '\'' +
                ", des='" + des + '\'' +
                ", imageUrl='" + imageUrl + '\'' +
                ", url='" + url + '\'' +
                '}';
    }
}
