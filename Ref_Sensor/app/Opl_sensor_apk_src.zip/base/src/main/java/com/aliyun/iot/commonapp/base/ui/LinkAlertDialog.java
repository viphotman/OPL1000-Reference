package com.aliyun.iot.commonapp.base.ui;

import android.app.AlertDialog;
import android.content.Context;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.Drawable;
import android.text.TextWatcher;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import com.aliyun.iot.commonapp.base.R;

import static com.aliyun.iot.commonapp.base.ui.LinkAlertDialog.Builder.INPUT;
import static com.aliyun.iot.commonapp.base.ui.LinkAlertDialog.Builder.NORMAL;

/**
 * Created by xingwei on 2018/3/21.
 * <p>
 * 支持标题内容两按钮 & 标题输入框两按钮
 */

public class LinkAlertDialog {

    AlertDialog mDialog;

    TextView mTitleTv;
    TextView mMessageTv;
    EditText mInputEt;
    Button mPositiveBtn;
    Button mNegativeBtn;
    Context mCtx;

    public interface OnClickListener {
        void onClick(LinkAlertDialog dialog);
    }


    private LinkAlertDialog(final Builder builder) {

        mDialog = new AlertDialog.Builder(builder.mContext).create();
        mCtx = builder.mContext;
        View view = LayoutInflater.from(builder.mContext).inflate(R.layout.alert_dialog, null);
        mTitleTv = view.findViewById(R.id.title);
        mMessageTv = view.findViewById(R.id.message);
        mInputEt = view.findViewById(R.id.input);
        mPositiveBtn = view.findViewById(R.id.positive_btn);
        mNegativeBtn = view.findViewById(R.id.negative_btn);
        mDialog.setView(view);

        setType(builder.mType);
        mTitleTv.setText(builder.mTitle);
        if (builder.mHideTitle) {
            mTitleTv.setVisibility(View.GONE);
        }
        mMessageTv.setText(builder.mMessage);
        mMessageTv.setGravity(builder.mMsgGravity);
        mInputEt.setHint(builder.mInputHint);

        mPositiveBtn.setText(builder.mPositiveBtnText);
        mNegativeBtn.setText(builder.mNegativeBtnText);

        mPositiveBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (null != builder.mPositiveListener) {
                    builder.mPositiveListener.onClick(LinkAlertDialog.this);
                }
            }
        });
        mNegativeBtn.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                if (null != builder.mNegativeListener) {
                    builder.mNegativeListener.onClick(LinkAlertDialog.this);
                }
            }
        });

        mInputEt.addTextChangedListener(builder.mInputTextWatcher);

        mDialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));

//        initTheme(builder.mContext);
    }

//    void initTheme(Context context) {
//        Resources.Theme theme = context.getTheme();
//        TypedArray typedArray = theme.obtainStyledAttributes(null, R.styleable.LinkAlertDialog,
//                R.attr.LinkAlertDialogStyle, R.style.defaultLinkAlertDialogStyle);
//
//        float titleSize = typedArray.getDimension(R.styleable.LinkAlertDialog_titleSize, 0);
//        int titleColor = typedArray.getColor(R.styleable.LinkAlertDialog_titleColor, 0);
//        float messageSize = typedArray.getDimension(R.styleable.LinkAlertDialog_messageSize, 0);
//        int messageColor = typedArray.getColor(R.styleable.LinkAlertDialog_messageColor, 0);
//        float positiveBtnSize = typedArray.getDimension(R.styleable.LinkAlertDialog_positiveBtnSize, 0);
//        int positiveBtnColor = typedArray.getColor(R.styleable.LinkAlertDialog_positiveBtnColor, 0);
//        float negativeBtnSize = typedArray.getDimension(R.styleable.LinkAlertDialog_negativeBtnSize, 0);
//        int negativeBtnColor = typedArray.getColor(R.styleable.LinkAlertDialog_negativeBtnColor, 0);
//
//        mTitleTv.setTextSize(titleSize);
//        mTitleTv.setTextColor(titleColor);
//        mMessageTv.setTextSize(messageSize);
//        mMessageTv.setTextColor(messageColor);
//        mPositiveBtn.setTextSize(positiveBtnSize);
//        mPositiveBtn.setTextColor(positiveBtnColor);
//        mNegativeBtn.setTextSize(negativeBtnSize);
//        mNegativeBtn.setTextColor(negativeBtnColor);
//
//        typedArray.recycle();
//    }


    void setType(int type) {
        if (NORMAL == type) {
            mMessageTv.setVisibility(View.VISIBLE);
            mInputEt.setVisibility(View.GONE);
        } else if (INPUT == type) {
            mMessageTv.setVisibility(View.GONE);
            mInputEt.setVisibility(View.VISIBLE);
        }
    }

    public void show() {
        mDialog.show();
        Window window = mDialog.getWindow();
        Drawable drawable = mCtx.getResources().getDrawable(R.drawable.alert_dialog_bg);
        if (window != null) {
            window.setBackgroundDrawable(drawable);
        }

        WindowManager.LayoutParams lp = null;
        if (window != null) {
            lp = window.getAttributes();
        }

        int width = mCtx.getResources().getDisplayMetrics().widthPixels;
        if (lp != null) {
            lp.gravity = Gravity.CENTER_VERTICAL;
            lp.width = (int) (width * 0.72);
        }
        if (window != null) {
            window.setAttributes(lp);
        }
    }

    public void dismiss() {
        mDialog.dismiss();
    }

    public String getInputText() {
        return mInputEt.getText().toString();
    }


    public static class Builder {

        public static final int NORMAL = 0x01;
        public static final int INPUT = 0x02;

        Context mContext;
        int mType;
        String mTitle = "title";
        String mMessage = "message";
        String mInputHint = "input";

        String mPositiveBtnText = "OK";
        String mNegativeBtnText = "CANCEL";
        boolean mHideTitle = false;
        int mMsgGravity = Gravity.CENTER_HORIZONTAL;

        OnClickListener mPositiveListener;
        OnClickListener mNegativeListener;
        TextWatcher mInputTextWatcher;

        public Builder(Context context) {
            mContext = context;
        }

        public Builder setType(int type) {
            mType = type;
            return this;
        }

        public Builder setTitle(String title) {
            mTitle = title;
            return this;
        }

        public Builder hideTitle() {
            mHideTitle = true;
            return this;
        }

        public Builder setMessage(String message) {
            mMessage = message;
            return this;
        }

        public Builder setMessageGravity(int gravity) {
            mMsgGravity = gravity;
            return this;
        }

        public Builder setInputHint(String hint) {
            mInputHint = hint;
            return this;
        }

        public Builder setPositiveButton(String text, OnClickListener listener) {
            mPositiveBtnText = text;
            mPositiveListener = listener;
            return this;
        }

        public Builder setNegativeButton(String text, OnClickListener listener) {
            mNegativeBtnText = text;
            mNegativeListener = listener;
            return this;
        }

        public Builder setInputTextWatcher(TextWatcher textWatcher) {
            mInputTextWatcher = textWatcher;
            return this;
        }

        public LinkAlertDialog create() {
            LinkAlertDialog linkAlertDialog = new LinkAlertDialog(this);
            return linkAlertDialog;
        }
    }
}
