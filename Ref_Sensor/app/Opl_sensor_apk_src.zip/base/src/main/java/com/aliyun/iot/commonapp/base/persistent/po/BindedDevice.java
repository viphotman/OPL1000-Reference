package com.aliyun.iot.commonapp.base.persistent.po;


/**
 * The type Device.
 *
 * @author sinyuk on 18/09/03.
 */
@SuppressWarnings("unused")
public class BindedDevice {

    public String categoryImage;
    public String productModel;
    public String iotId;
    public String netType;
    public String identityId;
    public String thingType;
    public String nodeType;
    public String productKey;
    public String deviceName;
    public String productName;
    public int status;
}
