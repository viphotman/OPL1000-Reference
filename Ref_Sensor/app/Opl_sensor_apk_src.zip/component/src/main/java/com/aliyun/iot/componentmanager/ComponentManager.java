package com.aliyun.iot.componentmanager;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.res.AssetManager;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;

import com.alibaba.fastjson.JSONObject;
import com.aliyun.iot.aep.component.router.IUrlHandler;
import com.aliyun.iot.aep.component.router.Router;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;

/**
 * @author xingwei
 */
public class ComponentManager {
    public static final String TAG = "ComponentManager";

    private static class SingletonHolder {
        @SuppressLint("StaticFieldLeak")
        private static final ComponentManager INSTANCE = new ComponentManager();
    }

    private ComponentManager() {
    }

    private Context app;
    private List<Component> components;
    private ConcurrentHashMap<String, Component> mapComponent;
    private ConcurrentHashMap<String, Integer> componentHasInit;
    private HashMap<String, String> urlActionMethod;
    private HashMap<String, String> urlComponent;

    private HashMap<String, ActionTarget> actionTargetCache;

    static class ActionTarget {
        Object target;
        Method method;

        ActionTarget(Object target, Method method) {
            this.target = target;
            this.method = method;
        }
    }

    public static ComponentManager getInstance() {
        return SingletonHolder.INSTANCE;
    }

    public void init(Context context) {

        this.app = context.getApplicationContext();

        components = new ArrayList<>();
        componentHasInit = new ConcurrentHashMap<>();
        urlActionMethod = new HashMap<>();
        urlComponent = new HashMap<>();

        mapComponent = new ConcurrentHashMap<>();
        actionTargetCache = new HashMap<>();

        parseJsonConfig();
        for (Component component : components) {

            mapComponent.putIfAbsent(component.name, component);

            final Class clazz = getComponentClass(component.target);
            final ComponentInterface target = (ComponentInterface) getComponentTarget(component.target);

            if (null == target) {
                continue;
            }

            // init page
            for (final Component.Page page : component.pages) {
                routerRegister(clazz, component.name, target, page.url, page.method);
            }

            // init action
            for (Component.Action action : component.actions) {
                urlComponent.put(action.url, component.name);
                urlActionMethod.put(action.url, action.method);
            }
        }
    }

    private void parseJsonConfig() {
        try {
            String[] componentsFileName = app.getAssets().list("component");
            Log.d(TAG, "parseJsonConfig@componentsFileName: " + Arrays.toString(componentsFileName));
            if (null == componentsFileName || componentsFileName.length == 0) {
                return;
            }
            for (String fileName : componentsFileName) {
                String jsonContent = readFile(app, "component/" + fileName);
                Log.d(TAG, "parseJsonConfig@fileName: " + fileName);
                Log.d(TAG, "parseJsonConfig@jsonContent: " + jsonContent);
                Component component = JSONObject.parseObject(jsonContent, Component.class);
                if (component == null) {
                    Log.d(TAG, "parseJsonConfig: component = null");
                } else {
                    this.components.add(component);
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public JSONObject getOptByComponentName(String name) {
        if (mapComponent.get(name) != null) {
            //noinspection ConstantConditions
            return mapComponent.get(name).opt;
        }
        return null;
    }

    private String readFile(Context ctx, String fileName) {
        AssetManager as = ctx.getAssets();
        StringBuilder sb = new StringBuilder();
        try {
            InputStream is = as.open(fileName);
            BufferedReader bf = new BufferedReader(new InputStreamReader(is));
            String line;
            while ((line = bf.readLine()) != null) {
                sb.append(line);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return sb.toString();
    }

    private void routerRegister(final Class clazz, final String name, final ComponentInterface target, String url, final String methodName) {
        Router.getInstance().registerModuleUrlHandler(url, new IUrlHandler() {
            @Override
            public void onUrlHandle(Context context, String url, Bundle bundle, boolean needForResult, int requestCode) {
                Log.d(TAG, "onUrlHandle: " + url);
                try {

                    if (!componentHasInit.containsKey(name)) {
                        target.init(app);
                        componentHasInit.put(name, 1);
                    }
                    Map<String, Object> argus = new LinkedHashMap<>();
                    Uri uri = Uri.parse(url);
                    Set<String> urlParameters = uri.getQueryParameterNames();
                    for (String parameter : urlParameters) {
                        //noinspection ConstantConditions
                        argus.put(parameter, uri.getQueryParameter(parameter));
                    }

                    Component.PageRequest pageRequest = new Component.PageRequest(argus, bundle, needForResult, requestCode);
                    //noinspection unchecked
                    Method method = clazz.getDeclaredMethod(methodName, Context.class, Component.PageRequest.class);
                    method.invoke(target, context, pageRequest);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });
    }

    /**
     * @param request
     * @param response
     */
    public void requestComponentAction(Component.ActionRequest request, Component.ActionResponseCallback response) {

        String name = request.component;
        Component component = mapComponent.get(name);
        String methodName = request.method;

        if (!componentHasInit.contains(name)) {
            ComponentInterface target = (ComponentInterface) getComponentTarget(component.target);
            Class clazz = getComponentClass(component.target);
            target.init(app);
            try {
                Method method = clazz.getDeclaredMethod(methodName, Component.ActionRequest.class,
                        Component.ActionResponseCallback.class);
                actionTargetCache.put(name + methodName, new ActionTarget(target, method));
            } catch (NoSuchMethodException e) {
                e.printStackTrace();
            }
        }

        ActionTarget at = actionTargetCache.get(name + methodName);
        if (null != at) {
            try {
                at.method.invoke(at.target, request, response);
                return;
            } catch (IllegalAccessException e) {
                e.printStackTrace();
            } catch (InvocationTargetException e) {
                e.printStackTrace();
            }
        }

        if (null != response) {
            response.onResponse(500, "Component Manager Error", null);
        }

    }

    public Component.ActionResponse requestComponentActionSync(Component.ActionRequest request) {

        String name = request.component;
        String methodName = request.method;
        Component component = mapComponent.get(name);
        if (null == component) {
            return new Component.ActionResponse(500, "component name: " + name + " not exist");
        }
        if (!componentHasInit.contains(name)) {
            ComponentInterface target = (ComponentInterface) getComponentTarget(component.target);
            Class clazz = getComponentClass(component.target);
            target.init(app);
            try {
                Method method = clazz.getDeclaredMethod(methodName, Component.ActionRequest.class);
                actionTargetCache.put(name + methodName, new ActionTarget(target, method));
            } catch (NoSuchMethodException e) {
                e.printStackTrace();
            }
        }

        ActionTarget at = actionTargetCache.get(name + methodName);

        if (null != at) {
            try {
                return (Component.ActionResponse) at.method.invoke(at.target, request);
            } catch (IllegalAccessException e) {
                e.printStackTrace();
            } catch (InvocationTargetException e) {
                e.printStackTrace();
            }
        }
        return new Component.ActionResponse(500, "ComponentManager Error");
    }

    /**
     * @param url
     */
    @SuppressWarnings("unused")
    public void requestComponentAction(String url) {
        requestComponentAction(url, null);
    }

    /**
     * @param url
     */
    @SuppressWarnings("WeakerAccess")
    public void requestComponentAction(String url, Component.ActionResponseCallback actionResponseCallback) {
        Component.ActionRequest request = parseUrl(url);
        requestComponentAction(request, actionResponseCallback);
    }

    @SuppressWarnings("unused")
    public Component.ActionResponse requestComponentActionSync(String url) {
        Component.ActionRequest request = parseUrl(url);
        return requestComponentActionSync(request);
    }

    private Component.ActionRequest parseUrl(String url) {
        Map<String, Object> argus = new LinkedHashMap<>();
        Uri uri = Uri.parse(url);
        Set<String> urlParameters = uri.getQueryParameterNames();
        for (String parameter : urlParameters) {
            argus.put(parameter, uri.getQueryParameter(parameter));
        }

        String componentName = urlComponent.get(url);
        Log.d(TAG, "componentName: " + componentName);
        String methodName = urlActionMethod.get(url);
        Log.d(TAG, "methodName: " + methodName);
        return new Component.ActionRequest(componentName, methodName, argus);
    }


    private Class getComponentClass(String target) {
        try {
            return Class.forName(target);
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }
        return null;
    }

    private Object getComponentTarget(String target) {
        Object object = null;
        try {
            object = Class.forName(target).newInstance();
        } catch (IllegalAccessException e) {
            e.printStackTrace();
        } catch (InstantiationException e) {
            e.printStackTrace();
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }
        return object;
    }
}
