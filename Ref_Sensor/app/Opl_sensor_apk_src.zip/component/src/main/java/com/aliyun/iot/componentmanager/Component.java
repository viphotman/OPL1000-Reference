package com.aliyun.iot.componentmanager;

import android.os.Bundle;


import com.alibaba.fastjson.JSONObject;

import java.util.List;
import java.util.Map;

/**
 * @author xingwei
 */
public class Component {

    // 唯一标识
    public String name;
    public String desc;
    public String version;
    public String target;
    public List<Page> pages;
    public List<Action> actions;
    public JSONObject opt;

    public static class Page {
        public String name;
        public String method;
        public String url;
    }

    public static class Action {
        public String name;
        public String method;
        public String url;
//        PageRequest pageRequest;
    }

    public static class PageRequest {

        Map<String, Object> parameter;
        Bundle bundle;
        boolean needForResult;
        int requestCode;

        public PageRequest(Map<String, Object> param) {
            this.parameter = param;
        }

        public PageRequest(Map<String, Object> param, Bundle bundle, boolean needForResult, int requestCode) {
            this.parameter = param;
            this.bundle = bundle;
            this.needForResult = needForResult;
            this.requestCode = requestCode;
        }

        public Map getMapParameter() {
            return parameter;
        }

        public Bundle getBundle() {
            return bundle;
        }

        public boolean isNeedForResult() {
            return needForResult;
        }

        public int getRequestCode() {
            return requestCode;
        }
    }

    public static class ActionRequest {

        Map<String, Object> parameter;
        String component;
        String method;

        public ActionRequest(String component, String method, Map<String, Object> param) {
            this.component = component;
            this.method = method;
            this.parameter = param;
        }
    }

    public interface ActionResponseCallback {

        void onResponse(int code, String msg, Map<String, Object> resp);
    }

    public static class ActionResponse {

        int code;
        String msg;
        Map<String, Object> response;

        public ActionResponse(int code, String msg) {
            this.code = code;
            this.msg = msg;
        }

        public ActionResponse(int code, String msg, Map<String, Object> map) {
            this.code = code;
            this.msg = msg;
            this.response = map;
        }

        public void setCode(int code) {
            this.code = code;
        }

        public int getCode() {
            return this.code;
        }

        public void setMsg(String msg) {
            this.msg = msg;
        }

        public String getMsg() {
            return this.msg;
        }

        public void setResponse(Map<String, Object> resp) {
            this.response = resp;
        }

        public Map<String, Object> getResponse() {
            return this.response;
        }
    }
}
