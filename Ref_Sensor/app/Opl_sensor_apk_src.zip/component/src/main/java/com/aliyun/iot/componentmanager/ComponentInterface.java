package com.aliyun.iot.componentmanager;

import android.content.Context;

public interface ComponentInterface {

    void init(Context context);
}
