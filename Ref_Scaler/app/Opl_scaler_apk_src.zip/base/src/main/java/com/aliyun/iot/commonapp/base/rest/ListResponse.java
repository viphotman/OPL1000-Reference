package com.aliyun.iot.commonapp.base.rest;

/**
 * @author sinyuk
 * @date 2018/12/20
 */
public class ListResponse<T> {
    public int total;
    public T data;
    public int pageSize;
    public int pageNo;
}
