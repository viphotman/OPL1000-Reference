package com.aliyun.iot.commonapp.base.ui;

import android.app.AlertDialog;
import android.content.Context;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.text.TextWatcher;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import com.aliyun.iot.commonapp.base.R;

/**
 *
 * @author xingwei
 * @date 2018/3/23
 *
 * 底部删除对话框
 */

public class LinkBottomDialog {


    private AlertDialog mDialog;

    private TextView mTitleTv;
    private Button mPositiveBtn;
    private Button mNegativeBtn;


    public interface OnClickListener {
        void onClick(LinkBottomDialog dialog);
    }

    private LinkBottomDialog(final Builder builder) {

        mDialog = new AlertDialog.Builder(builder.mContext).create();
        View view = LayoutInflater.from(builder.mContext).inflate(R.layout.bottom_dialog, null);
        mTitleTv = view.findViewById(R.id.title);
        mPositiveBtn = view.findViewById(R.id.positive_btn);
        mNegativeBtn = view.findViewById(R.id.negative_btn);
        mDialog.setView(view);

        mTitleTv.setText(builder.mTitle);

        mPositiveBtn.setText(builder.mPositiveBtnText);
        mNegativeBtn.setText(builder.mNegativeBtnText);

        mPositiveBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (null != builder.mPositiveListener) {
                    builder.mPositiveListener.onClick(LinkBottomDialog.this);
                }
            }
        });

        mNegativeBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (null != builder.mNegativeListener) {
                    builder.mNegativeListener.onClick(LinkBottomDialog.this);
                }
            }
        });

        mDialog.getWindow().setGravity(Gravity.BOTTOM);
        mDialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));

    }

    public void show() {
        mDialog.show();
    }

    public void dismiss() {
        mDialog.dismiss();
    }

    public static class Builder {

        public static final int NORMAL = 0x01;
        public static final int INPUT = 0x02;

        Context mContext;
        String mTitle = "title";

        String mPositiveBtnText = "OK";
        String mNegativeBtnText = "CANCEL";

        OnClickListener mPositiveListener;
        OnClickListener mNegativeListener;
        TextWatcher mInputTextWatcher;

        public Builder(Context context) {
            mContext = context;
        }

        public Builder setTitle(String title) {
            mTitle = title;
            return this;
        }


        public Builder setPositiveButton(String text, OnClickListener listener) {
            mPositiveBtnText = text;
            mPositiveListener = listener;
            return this;
        }

        public Builder setNegativeButton(String text, OnClickListener listener) {
            mNegativeBtnText = text;
            mNegativeListener = listener;
            return this;
        }

        public LinkBottomDialog create() {
            return new LinkBottomDialog(this);
        }
    }
}
