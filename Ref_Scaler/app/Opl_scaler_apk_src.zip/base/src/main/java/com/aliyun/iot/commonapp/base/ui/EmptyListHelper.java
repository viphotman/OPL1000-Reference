package com.aliyun.iot.commonapp.base.ui;

import android.content.Context;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.view.AsyncLayoutInflater;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.aliyun.iot.commonapp.base.R;

import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;

import okio.BufferedSource;
import okio.Okio;

/**
 * @author sinyuk
 * @date 2019/1/7
 */
public class EmptyListHelper {

    public static final String TAG = "EmptyListHelper";

    public interface OnShowEmptyViewCallback {
        /**
         * @param view
         */
        void onShow(View view);
    }

    /**
     * @param context
     * @param viewGroup
     * @param message
     * @param callback
     */
    public static void show(Context context, ViewGroup viewGroup, final String message, final OnShowEmptyViewCallback callback) {
        AsyncLayoutInflater inflater = new AsyncLayoutInflater(context);
        inflater.inflate(R.layout.empty_view, viewGroup, new AsyncLayoutInflater.OnInflateFinishedListener() {
            @Override
            public void onInflateFinished(@NonNull View view, int i, @Nullable ViewGroup viewGroup) {
                TextView textView = view.findViewById(R.id.text_trace);
                textView.setText(message);
                callback.onShow(view);
            }
        });
    }

    private JSONObject loadJsonFromAssets(Context context, String filename) {
        try {
            InputStream inputStream = context.getAssets().open(filename);
            BufferedSource source = Okio.buffer(Okio.source(inputStream));
            String string = source.readString(StandardCharsets.UTF_8);
            Log.d(TAG, "loadJsonFromAssets(): " + string);
            return JSON.parseObject(string);
        } catch (IOException e) {
            e.printStackTrace();
        }
        return null;
    }
}
