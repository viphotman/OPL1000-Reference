package com.aliyun.iot.commonapp.base.ui;

import android.animation.ObjectAnimator;
import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.Color;
import android.graphics.drawable.AnimationDrawable;
import android.graphics.drawable.Drawable;
import android.text.TextUtils;
import android.util.AttributeSet;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.LinearInterpolator;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.aliyun.iot.commonapp.base.R;


/**
 * Created by wb-zyl208210 on 2016/10/20.
 */
public class LinkSimpleLoadView extends FrameLayout {

    private static final String TAG = "WHloadView";
    private LinearLayout mLoadViewRoot;
    private ImageView mIconScreen;
    private TextView mTip;
    private String mDefaultTipText;
    private ObjectAnimator mRotation;
    private View mDeleTopBar;
    private View mUpperBlanSpaceView;
    private View mBottomBlanSpaceView;
    private int mTipColor;
    private Drawable mLoadTipIcon;
    private Drawable mLoadingIcon;
    private float mLoadTipIconSize;
    private float mLoadingIconSize;
    private float mTip2IconSpace;
    private float mTipTextSize;
    private LinearLayout mInfoArea;
    private float mInfoAreaTipSize;
    private float mInfoAreaLoadingSize;
    private Drawable mInfoAreaTipBg;
    private Drawable mInfoAreaLoadingBg;
    private float mLoadViewLoacation;
    private float mTipViewLoacation;

    public LinkSimpleLoadView(Context context) {
        super(context);
        this.init((AttributeSet) null);
    }

    public LinkSimpleLoadView(Context context, AttributeSet attrs) {
        super(context, attrs);
        this.init(attrs);
    }

    public LinkSimpleLoadView(Context context, AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        this.init(attrs);
    }

    public void init(AttributeSet attrs) {
        this.addView(LayoutInflater.from(this.getContext()).inflate(R.layout.link_view_simpleloadview, null, false));
        mLoadViewRoot = this.findViewById(R.id.simpleloadview_root_linearlayout);
        mUpperBlanSpaceView = this.findViewById(R.id.simpleloadview_upper_blanspace_view);
        mBottomBlanSpaceView = this.findViewById(R.id.simpleloadview_bottom_blanspace_view);
        mDeleTopBar = this.findViewById(R.id.simpleloadview_topbar_dele_view);
        mInfoArea = this.findViewById(R.id.simpleloadview_infoarea_linearlayout);
        mIconScreen = this.findViewById(R.id.simpleloadview_icon_imageview);
        mTip = this.findViewById(R.id.simpleloadview_loadtip_textview);
        if (attrs != null) {
            TypedArray typedArray = this.getContext().obtainStyledAttributes(attrs, R.styleable.LinkSimpleLoadView);
            applyStyle(typedArray);
            typedArray.recycle();
        }
    }

    public void setLoadViewLoacation(float loadViewLoaction) {
        this.mLoadViewLoacation = loadViewLoaction;
    }

    public void setTipViewLoacation(float tipViewLoacation) {
        this.mTipViewLoacation = tipViewLoacation;

    }

    public void applyStyle(TypedArray typedArray) {
        mDefaultTipText = typedArray.getString(R.styleable.LinkSimpleLoadView_slv_tip_text);
        mTipColor = typedArray.getColor(R.styleable.LinkSimpleLoadView_slv_tip_color, Color.LTGRAY);
        mTipTextSize = typedArray.getDimension(R.styleable.LinkSimpleLoadView_slv_tip_textsize, convertdp2px(14));

        mLoadTipIcon = typedArray.getDrawable(R.styleable.LinkSimpleLoadView_slv_loadtip_icon);
        mLoadTipIconSize = typedArray.getDimension(R.styleable.LinkSimpleLoadView_slv_loadtip_icon_size, convertdp2px(45));

        mLoadingIcon = typedArray.getDrawable(R.styleable.LinkSimpleLoadView_slv_loading_icon);
        mLoadingIconSize = typedArray.getDimension(R.styleable.LinkSimpleLoadView_slv_loading_icon_size, convertdp2px(94));


        mInfoAreaTipSize = typedArray.getLayoutDimension(R.styleable.LinkSimpleLoadView_slv_infoarea_tip_size, convertdp2px(96));//提示信息区域显示提示信息时的大小
        mInfoAreaLoadingSize = typedArray.getLayoutDimension(R.styleable.LinkSimpleLoadView_slv_infoarea_loading_size, ViewGroup.LayoutParams.WRAP_CONTENT);//显示

        mInfoAreaLoadingBg = typedArray.getDrawable(R.styleable.LinkSimpleLoadView_slv_infoarea_loading_background);
        mInfoAreaTipBg = typedArray.getDrawable(R.styleable.LinkSimpleLoadView_slv_infoarea_tip_background);

        mTip2IconSpace = typedArray.getDimension(R.styleable.LinkSimpleLoadView_slv_tip2icon_space, convertdp2px(10));

        mLoadViewLoacation = typedArray.getFloat(R.styleable.LinkSimpleLoadView_slv_loadview_location, 1f);
        mTipViewLoacation = typedArray.getFloat(R.styleable.LinkSimpleLoadView_slv_tipview_location, 1f);
        if (!TextUtils.isEmpty(mDefaultTipText)) {
            mTip.setText(mDefaultTipText);
        }
        mTip.setTextColor(mTipColor);
        MarginLayoutParams layoutParams = (MarginLayoutParams) mTip.getLayoutParams();
        layoutParams.setMargins(0, (int) mTip2IconSpace, 0, 0);
        mTip.setLayoutParams(layoutParams);
    }

    public void setLoadViewRootBgColor(int color) {
        if (mLoadViewRoot == null) {
            return;
        }
        mLoadViewRoot.setBackgroundColor(color);
    }

    public void setLoadViewRootBgDrawbleRes(int resId) {
        if (mLoadViewRoot != null && resId > 0) {
            mLoadViewRoot.setBackgroundColor(Color.WHITE);
        }
    }

    public void setLoadViewlocationOnV(float tw, float bw) {//设置loadview在竖直方向上的位置比例 top/bottom
        LinearLayout.LayoutParams upperLayoutParams = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0);
        upperLayoutParams.weight = tw;
        mUpperBlanSpaceView.setLayoutParams(upperLayoutParams);

        LinearLayout.LayoutParams bottomLayoutParams = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0);
        bottomLayoutParams.weight = bw;
        mBottomBlanSpaceView.setLayoutParams(bottomLayoutParams);
    }


    //自定义loading的样式
    public void setLoadingDrawable(Drawable loadingIcon) {
        this.mLoadingIcon = loadingIcon;
    }

    //自定义loadingErroe的样式
    public void setLoadErrorDrawable(Drawable errorIconDrawable) {
        this.mLoadTipIcon = errorIconDrawable;
    }

    public void showTip(String tip) {
        showTip(tip, mLoadTipIcon);
    }

    public void showTip(String tip, Drawable tipDrawable) {
        this.setVisibility(View.VISIBLE);
        this.setClickable(true);
        mLoadViewRoot.setVisibility(View.VISIBLE);
        if (mRotation != null) {
            mRotation.cancel();
        }
        if (mTipViewLoacation < 0) {
            mTipViewLoacation = 1;
        }
        if (mTipViewLoacation < 1) {
            setLoadViewlocationOnV(10 * mTipViewLoacation, 10);
        } else {
            setLoadViewlocationOnV(mTipViewLoacation, 1);
        }

        LinearLayout.LayoutParams infoAreaLayoutParams = new LinearLayout.LayoutParams((int) mInfoAreaTipSize, (int) mInfoAreaTipSize);
        mInfoArea.setLayoutParams(infoAreaLayoutParams);
        mInfoArea.setBackgroundDrawable(mInfoAreaTipBg);

        mIconScreen.clearAnimation();
        mIconScreen.setRotation(0);
        mIconScreen.setVisibility(View.VISIBLE);
        LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams((int) mLoadTipIconSize, (int) mLoadTipIconSize);
        mIconScreen.setLayoutParams(layoutParams);
        mIconScreen.setBackground(tipDrawable);
        if (TextUtils.isEmpty(tip)) {
            mTip.setText("");
            mTip.setVisibility(GONE);
        } else {
            mTip.setText(tip);
            mTip.setVisibility(VISIBLE);
        }
    }

    public void showError(String errorTip) {
        showTip(errorTip);
    }

    public void showError(String errorTip, Drawable errorIcon) {
        showTip(errorTip, errorIcon);
    }

    public void showLoading(String loadingTip) {
        showLoading(loadingTip, mLoadingIcon);
    }

    public void showLoading(String loadingTip, Drawable loadingIcon) {
        this.setClickable(true);
        this.setVisibility(View.VISIBLE);
        mLoadViewRoot.setVisibility(View.VISIBLE);

        mIconScreen.setVisibility(View.VISIBLE);

        if (mLoadViewLoacation < 0) {
            mLoadViewLoacation = 1;
        }
        if (mLoadViewLoacation < 1) {
            setLoadViewlocationOnV(10 * mLoadViewLoacation, 10);
        } else {
            setLoadViewlocationOnV(mLoadViewLoacation, 1);
        }

        LinearLayout.LayoutParams infoAreaLayoutParams = new LinearLayout.LayoutParams((int) mInfoAreaLoadingSize, (int) mInfoAreaLoadingSize);
        mInfoArea.setLayoutParams(infoAreaLayoutParams);
        mInfoArea.setBackgroundDrawable(mInfoAreaLoadingBg);

        mIconScreen.setClickable(false);
        LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams((int) mLoadingIconSize, (int) mLoadingIconSize);
        mIconScreen.setLayoutParams(layoutParams);
        mIconScreen.setBackgroundDrawable(loadingIcon);
        if (TextUtils.isEmpty(loadingTip)) {
            mTip.setText("");
            mTip.setVisibility(GONE);
        } else {
            mTip.setText(loadingTip);
            mTip.setVisibility(VISIBLE);
        }
        startAnimator();
    }

    //当作为dialog的布局是调用该方法，
    public void setTopbarClickableArea(View topBarView, OnClickListener listener) {
        topBarView.measure(0, 0);
        int topbarHeight = topBarView.getMeasuredHeight();
        int topbarWidth = topBarView.getMeasuredWidth();
        try {
            mDeleTopBar.getLayoutParams().height = topbarHeight > 0 ? topbarHeight : 0;
            mDeleTopBar.getLayoutParams().width = topbarWidth > 0 ? topbarWidth / 2 : this.getContext().getResources().getDisplayMetrics().widthPixels;
            mDeleTopBar.requestLayout();
            mDeleTopBar.setOnClickListener(listener);
        } catch (Exception e) {
            mDeleTopBar.getLayoutParams().height = 0;
            mDeleTopBar.requestLayout();
            mDeleTopBar.setOnClickListener(listener);
            Log.e(TAG, "fail to get the height of topbar," + e);
            e.printStackTrace();
        }
    }

    public void startAnimator() {
        if (mIconScreen == null) {
            return;
        }
        try {
            if (mIconScreen.getBackground() == null) {
                return;
            }
            if (mIconScreen.getBackground() instanceof AnimationDrawable) {
                AnimationDrawable animationDrawable = (AnimationDrawable) mIconScreen.getBackground();
                animationDrawable.start();
            } else {
                if (mRotation == null) {
                    mRotation = ObjectAnimator.ofFloat(mIconScreen, View.ROTATION, 0, 720);
                    mRotation.setDuration(1000);
                    mRotation.setInterpolator(new LinearInterpolator());
                    mRotation.setRepeatCount(ObjectAnimator.INFINITE);//bug-fix 7.0以上 版本出现动画无效
                } else {
                    mRotation.cancel();//必备
                }
                mRotation.start();
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void hide() {
        if (mRotation != null) {
            mRotation.cancel();
        }
        this.setVisibility(View.GONE);
    }

    public int convertdp2px(float dpValue) {
        final float scale = this.getResources().getDisplayMetrics().density;
        return (int) (dpValue * scale + 0.5f);
    }

    public float convertpx2dp(int pxValue) {
        final float scale = this.getResources().getDisplayMetrics().density;
        return pxValue / scale;
    }
}
