package com.aliyun.iot.commonapp.base.ui;

import android.os.Bundle;
import android.support.v4.app.Fragment;

/**
 * @author sinyuk
 * @date 2017/12/4
 */
public abstract class BaseLazyFragment extends Fragment {
    /**
     * The Is view initiated.
     */
    protected boolean isViewInitiated;
    /**
     * The Is visible to user.
     */
    protected boolean isVisibleToUser;
    /**
     * The Is data initiated.
     */
    protected boolean isDataInitiated;


    @Override
    public void onActivityCreated(Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
        isViewInitiated = true;
        prepareFetchData();
    }


    @Override
    public void setUserVisibleHint(boolean isVisibleToUser) {
        super.setUserVisibleHint(isVisibleToUser);
        this.isVisibleToUser = isVisibleToUser;
        prepareFetchData();
    }

    /**
     * Prepare fetch data boolean.
     *
     * @return the boolean
     */
    @SuppressWarnings("UnusedReturnValue")
    private boolean prepareFetchData() {
        return prepareFetchData(false);
    }

    /**
     * Prepare fetch data boolean.
     *
     * @param forceUpdate the force update
     * @return the boolean
     */
    private boolean prepareFetchData(@SuppressWarnings("SameParameterValue") boolean forceUpdate) {
        boolean bool = isVisibleToUser && isViewInitiated && (!isDataInitiated || forceUpdate);
        if (bool) {
            lazyDo();
            isDataInitiated = true;
            return true;
        }
        return false;
    }

    /**
     * Lazy do.
     */
    protected abstract void lazyDo();
}