package com.aliyun.iot.commonapp.base.ui;

import android.app.DownloadManager;
import android.content.Intent;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.support.v7.app.AppCompatActivity;
import android.text.TextUtils;
import android.util.Log;
import android.view.KeyEvent;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.CookieManager;
import android.webkit.DownloadListener;
import android.webkit.URLUtil;
import android.widget.FrameLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.alibaba.fastjson.JSON;
import com.aliyun.iot.aep.component.router.Router;
import com.aliyun.iot.aep.sdk.bridge.core.service.BoneCallback;
import com.aliyun.iot.aep.sdk.framework.config.AConfigure;
import com.aliyun.iot.aep.sdk.h5.BoneWebChromeClient;
import com.aliyun.iot.aep.sdk.h5.BoneWebView;
import com.aliyun.iot.aep.sdk.h5.BoneWebViewClient;
import com.aliyun.iot.aep.sdk.h5.BoneWebViewFactory;
import com.aliyun.iot.aep.sdk.h5.BoneWebViewFactoryProvider;
import com.aliyun.iot.aep.sdk.h5.IoTWebView;
import com.aliyun.iot.aep.sdk.h5.impl.SystemWebViewFactory;
import com.aliyun.iot.aep.sdk.threadpool.ThreadPool;
import com.aliyun.iot.commonapp.base.BuildConfig;
import com.aliyun.iot.commonapp.base.R;

/**
 * @author sinyuk
 */
public class WebViewActivity extends AppCompatActivity {
    public static final String TAG = "WebViewActivity";
    public static final String CUSTOM_HOST = "plugin.vapp.cloudhost.link";

    private IoTWebView mWebView;
    private BoneWebViewFactory webViewFactory;

    public static final String URL_REGEX = "^(https?://|ftp://|file://|www)[-a-zA-Z0-9+&@#/%?=~_|!:,.;]*[-a-zA-Z0-9+&@#/%=~_|]";

    public static final String URL_REGEX_2 = "^[a-zA-Z][0-9a-zA-Z_]{0,32}(\\.)(org.cn|net.cn|luxe|art|beer|design|live|pub|ink|kim|group|ren|store|tech|pro|vip|ltd|link|red|fun|online|club|site|shop|wang|xyz|top|xin|co|info|biz|name|gov.cn|tv|cc|mobi|com|cn|com.cn|net|me|tt|org)";

    private TextView actionBarTitle;

    private View toolbar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        String auCode = AConfigure.getInstance().getConfig("securityIndex");
        if (TextUtils.isEmpty(auCode)) {
            LinkToast.makeText(this, "安全图片不存在", Toast.LENGTH_SHORT).show();
            finish();
        }
        setContentView(R.layout.web_view_activity);
        actionBarTitle = findViewById(R.id.text_actionbar_title);
        toolbar = findViewById(R.id.toolbar);
        findViewById(R.id.button_back).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });

        configWebViewCore();

        BoneWebViewFactoryProvider.registerBoneWebViewFactory(webViewFactory);

        mWebView = new IoTWebView(this);
        mWebView.setPluginHost(CUSTOM_HOST);

        String env = "release";
        if (BuildConfig.MODE.toLowerCase().equals("debug")) {
            env = "test";
        }
        mWebView.setEnv(env);
        mWebView.setAuthCode(auCode);
        Log.d(TAG, "auCode: " + auCode + ", evn: " + env);
        FrameLayout container = findViewById(R.id.web_view_container);
        mWebView.setLayoutParams(new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT));
        container.addView(mWebView);
        mWebView.getView().requestFocusFromTouch();
        final String finalUrl = handleIntent();
        mWebView.setWebChromeClient(chromeClient);
        mWebView.setWebViewClient(webViewClient);
        mWebView.setOnOpenNewPageListener(onOpenNewPageListener);

        mWebView.setDownloadListener(new MyDownloadManager());
        mWebView.loadUrl(finalUrl);
    }

    private final BoneWebChromeClient chromeClient = new BoneWebChromeClient() {
        @Override
        public void onReceivedTitle(BoneWebView boneWebView, String title) {
            final String titleStr;
            if (TextUtils.isEmpty(title)) {
                titleStr = "about:blank";
            } else {
                titleStr = title;
            }
            ThreadPool.MainThreadHandler.getInstance().post(new Runnable() {
                @Override
                public void run() {
                    actionBarTitle.setText(titleStr);
                }
            });
        }
    };


    private final BoneWebViewClient webViewClient = new BoneWebViewClient() {
        @Override
        public void onPageFinished(BoneWebView webView, String url) {
            super.onPageFinished(webView, url);
            try {
                Uri uri = Uri.parse(url);
                String host = uri.getHost();
                Log.d(TAG, "onPageFinished@url: " + url + ", host: " + host);
                if (!TextUtils.isEmpty(host) && host.equals(CUSTOM_HOST)
                        && toolbar != null) {
                    toolbar.setVisibility(View.GONE);
                } else {
                    toolbar.setVisibility(View.VISIBLE);
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    };


    private IoTWebView.OnOpenNewPageListener onOpenNewPageListener = new IoTWebView.OnOpenNewPageListener() {
        @Override
        public void onOpenNewPage(String url, BoneCallback boneCallback) {
            boolean result = Router.getInstance().toUrl(WebViewActivity.this, url);
            if (result) {
                boneCallback.success();
            } else {
                boneCallback.failed(url + " ,not found", "", "");
            }
        }

        @Override
        public void onOpenNewPageForResult(String url, BoneCallback boneCallback) {
            boolean result = Router.getInstance().toUrlForResult(WebViewActivity.this, url, 1000);
            if (result) {
                boneCallback.success();
            } else {
                boneCallback.failed(url + " ,not found", "", "");
            }
        }
    };

    private String handleIntent() {
        String url = null;
        String host = null;
        if (getIntent() != null && getIntent().getData() != null) {
            Uri uri = getIntent().getData();
            host = uri.getHost();
            url = uri.toString();
        }

        int visibility = CUSTOM_HOST.equals(host) ? View.GONE : View.VISIBLE;
        // 自定义页面隐藏顶部栏
        toolbar.setVisibility(visibility);

        Log.d(TAG, "URL: " + url);
        if (url.matches(URL_REGEX)) {
            if (url.startsWith("www")) url = "http://" + url;
        } else if (url.matches(URL_REGEX_2)) {
            url = "http://" + url;
        } else {
            url = "about:blank";
        }
        Log.d(TAG, "Formatted URL: " + url);
        return url;
    }

    private void configWebViewCore() {
        webViewFactory = new SystemWebViewFactory();
    }

    @Override
    protected void onPause() {
        super.onPause();
        if (mWebView != null && mWebView.getView() != null) {
            mWebView.onPause();
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (mWebView != null && mWebView.getView() != null) {
            mWebView.onResume();
        }
    }

    @Override
    protected void onStop() {
        super.onStop();
        if (mWebView != null && mWebView.getView() != null) {
            mWebView.onStop();
        }
    }


    /**
     * Called when the activity is becoming visible to the user.
     */
    @Override
    protected void onStart() {
        super.onStart();
        if (mWebView != null && mWebView.getView() != null) {
            mWebView.onStart();
        }
    }

    /**
     * The final call you receive before your activity is destroyed.
     */
    @Override
    public void onDestroy() {
        super.onDestroy();
        if (mWebView != null && mWebView.getView() != null) {
            if (mWebView.getView().getParent() != null) {
                ((ViewGroup) mWebView.getView().getParent()).removeView(mWebView.getView());
            }
            mWebView.loadUrl("about:blank");
            mWebView.destroy();
            mWebView = null;
        }
        if (webViewFactory != null) {
            BoneWebViewFactoryProvider.unregisterBoneWebViewFactory(webViewFactory);
        }
    }

    @Override
    public boolean onKeyDown(final int keyCode, final KeyEvent event) {
        // Check if the key event was the Back button and if there's history
        if ((keyCode == KeyEvent.KEYCODE_BACK) && mWebView != null &&
                mWebView.getView() != null && mWebView.canGoBack()) {
            mWebView.goBack();
            return true;
        }
        // If it wasn't the Back key or there's no web page history, bubble up to the default
        // system behavior (probably exit the activity)
        return super.onKeyDown(keyCode, event);
    }


    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent intent) {
        super.onActivityResult(requestCode, resultCode, intent);
        if (1000 == requestCode && mWebView != null && mWebView.getView() != null) {
            mWebView.onActivityResult(requestCode, resultCode, intent);
        }
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        try {
            Log.d(TAG, "onNewIntent: " + JSON.toJSONString(intent));
        } catch (Exception ignored) {

        }
        setIntent(intent);
        if (mWebView != null && mWebView.getView() != null) {
            mWebView.loadUrl(handleIntent());
        }
    }


    class MyDownloadManager implements DownloadListener {

        @Override
        public void onDownloadStart(String url, String userAgent,
                                    String contentDisposition, String mimeType,
                                    long contentLength) {

            DownloadManager.Request request = new DownloadManager.Request(Uri.parse(url));
            request.setMimeType(mimeType);
            String cookies = CookieManager.getInstance().getCookie(url);
            request.addRequestHeader("cookie", cookies);
            request.addRequestHeader("User-Agent", userAgent);
            request.setDescription("下载文件…");
            request.allowScanningByMediaScanner();
            request.setTitle(URLUtil.guessFileName(url, contentDisposition, mimeType));

            request.setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED);
            request.setDestinationInExternalPublicDir(
                    Environment.DIRECTORY_DOWNLOADS, URLUtil.guessFileName(
                            url, contentDisposition, mimeType));
            DownloadManager dm = (DownloadManager) getSystemService(DOWNLOAD_SERVICE);
            if (dm != null) {
                dm.enqueue(request);
            }
            LinkToast.makeText(getApplicationContext(), "开始下载…", Toast.LENGTH_LONG).show();
        }
    }

}