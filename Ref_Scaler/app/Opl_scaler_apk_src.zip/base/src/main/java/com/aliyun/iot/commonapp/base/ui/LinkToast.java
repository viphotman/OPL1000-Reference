package com.aliyun.iot.commonapp.base.ui;

import android.content.Context;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

import com.aliyun.iot.commonapp.base.R;

/**
 * @author xingwei
 * @date 2018/3/21
 */
public class LinkToast {

    private Toast mToast;

    private LinkToast(Context context, CharSequence text, int duration) {
        mToast = new Toast(context);

        View view = LayoutInflater.from(context).inflate(R.layout.link_toast, null);
        TextView tv = view.findViewById(R.id.text);
        tv.setText(text);
        mToast.setDuration(duration);
        mToast.setGravity(Gravity.CENTER, 0, 0);
        mToast.setView(view);
    }

    public static LinkToast makeText(Context context, CharSequence text, int duration) {
        return new LinkToast(context, text, duration);
    }

    public static LinkToast makeText(Context context, int textResId, int duration) {
        String text = context.getResources().getString(textResId);
        return new LinkToast(context, text, duration);
    }

    public void show() {
        mToast.show();
    }

    public void setGravity(int gravity, int xoffset, int yoffset) {
        mToast.setGravity(gravity, xoffset, yoffset);
    }
}
