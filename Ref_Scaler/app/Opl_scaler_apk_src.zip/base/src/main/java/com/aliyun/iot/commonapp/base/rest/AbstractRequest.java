package com.aliyun.iot.commonapp.base.rest;

import android.text.TextUtils;
import android.util.Log;

import com.alibaba.fastjson.JSON;
import com.aliyun.iot.aep.sdk.apiclient.IoTAPIClient;
import com.aliyun.iot.aep.sdk.apiclient.IoTAPIClientFactory;
import com.aliyun.iot.aep.sdk.apiclient.callback.IoTCallback;
import com.aliyun.iot.aep.sdk.apiclient.callback.IoTResponse;
import com.aliyun.iot.aep.sdk.apiclient.emuns.Scheme;
import com.aliyun.iot.aep.sdk.apiclient.request.IoTRequest;
import com.aliyun.iot.aep.sdk.apiclient.request.IoTRequestBuilder;
import com.aliyun.iot.aep.sdk.threadpool.ThreadPool;

import java.lang.ref.WeakReference;
import java.lang.reflect.ParameterizedType;
import java.lang.reflect.Type;
import java.util.Map;

import javax.security.auth.login.LoginException;

/**
 * The type My request.
 *
 * @author sinyuk
 * @date 2018 /12/20
 */
public abstract class AbstractRequest {
    public static final String TAG = "AbstractRequest";
    private final Scheme schema;

    /**
     * The interface Request callback.
     *
     * @param <T> the type parameter
     */
    public interface RequestCallback<T> {
        /**
         * On success.
         *
         * @param data the data
         */
        void onSuccess(T data);

        /**
         * On error.
         *
         * @param t the t
         */
        void onError(Throwable t);
    }

    private final Map<String, Object> params;
    private final String apiVersion;
    private final String path;

    /**
     * Instantiates a new My request.
     *
     * @param params     the params
     * @param apiVersion the api version
     * @param path       the path
     */
    protected AbstractRequest(String apiVersion, String path, Map<String, Object> params) {
        this.params = params;
        this.apiVersion = apiVersion;
        this.path = path;
        this.schema = null;
    }

    protected AbstractRequest(String apiVersion, String path, Map<String, Object> params,
                              com.aliyun.iot.aep.sdk.apiclient.emuns.Scheme scheme) {
        this.params = params;
        this.apiVersion = apiVersion;
        this.path = path;
        this.schema = scheme;
    }


    public <V> void execute(final RequestCallback<V> reference) {
        try {
            IoTAPIClient ioTAPIClient = new IoTAPIClientFactory().getClient();
            IoTRequestBuilder builder = new IoTRequestBuilder().setAuthType("iotAuth");
            if (schema != null) {
                builder.setScheme(schema);
            }

            if (!TextUtils.isEmpty(path)) {
                builder.setPath(path);
            }
            if (params != null && !params.isEmpty()) {
                builder.setParams(params);
            }
            if (!TextUtils.isEmpty(apiVersion)) {
                builder.setApiVersion(apiVersion);
            }

            ioTAPIClient.send(builder.build(), new IoTCallback() {
                @Override
                public void onFailure(IoTRequest ioTRequest, final Exception e) {
                    ThreadPool.MainThreadHandler.getInstance().post(new Runnable() {
                        @Override
                        public void run() {
                            reference.onError(e);
                        }
                    });
                }

                @Override
                public void onResponse(IoTRequest ioTRequest, final IoTResponse ioTResponse) {
                    if (200 == ioTResponse.getCode()) {
                        //noinspection unchecked
                        final V v = (V) parseData(ioTResponse.getData());
                        ThreadPool.MainThreadHandler.getInstance().post(new Runnable() {
                            @Override
                            public void run() {
                                reference.onSuccess(v);
                            }
                        });
                    } else {
                        final String message;
                        if (TextUtils.isEmpty(ioTResponse.getLocalizedMsg())) {
                            message = ioTResponse.getMessage();
                        } else {
                            message = ioTResponse.getLocalizedMsg();
                        }
                        ThreadPool.MainThreadHandler.getInstance().post(new Runnable() {
                            @Override
                            public void run() {
                                reference.onError(new Throwable(message));
                            }
                        });
                    }
                }
            });
        } catch (final Exception e) {
            Log.e(TAG, "execute: ", e);
            ThreadPool.MainThreadHandler.getInstance().post(new Runnable() {
                @Override
                public void run() {
                    reference.onError(new Throwable(e.getLocalizedMessage()));
                }
            });
        }
    }

    /**
     * parse response to java clazz
     *
     * @param body response body
     * @return data clazz
     */
    protected abstract Object parseData(Object body);
}
