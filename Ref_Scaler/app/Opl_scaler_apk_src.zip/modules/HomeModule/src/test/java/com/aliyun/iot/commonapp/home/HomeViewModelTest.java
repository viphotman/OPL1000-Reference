package com.aliyun.iot.commonapp.home;


import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;

import org.junit.Before;
import org.junit.Test;


/**
 * @author sinyuk
 * @date 2019/1/15
 */
public class HomeViewModelTest {
    private static final String JSON_TEXT = "{\"name\":\"HomeModule\",\"alias\":\"首页组件\",\"desc\":\"描述\",\"version\":\"版本\",\"target\":\"com.aliyun.iot.commonapp.component.HomeComponent\",\"pages\":[{\"name\":\"首页\",\"method\":\"toHome\",\"url\":\"ldpapp://home\",\"args\":[]}],\"actions\":[{\"name\":\"初始化首页\",\"target\":\"com.aliyun.iot.commonapp.component.HomeComponent\",\"url\":\"ldpapp://home/view\",\"method\":\"getView\",\"args\":{}}],\"sdks\":[{\"name\":\"push\",\"version\":\"0.0.1\"},{\"name\":\"account\",\"version\":\"0.0.3\"},{\"name\":\"apiClient\",\"version\":\"0.0.3.1\"}],\"opt\":{\"homeModuleMainList\":[{\"homeModuleMainPageTitle\":\"https://www.taobao.com\",\"homeModuleMainPageDesc\":\"desc desc desc\",\"homeModuleMainPageIconURL\":\"https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTBZWUMfkaGAkZHDtXPaHalO8umXWBfetPz0FPAxRuHfJEpESA3iQ\",\"homeModuleMainPageLink\":\"https://www.taobao.com\"},{\"homeModuleMainPageTitle\":\"link://boneweb/code?url=\\\"https://www.taobao.com\\\"\",\"homeModuleMainPageDesc\":\"desc desc desc\",\"homeModuleMainPageIconURL\":\"https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTBZWUMfkaGAkZHDtXPaHalO8umXWBfetPz0FPAxRuHfJEpESA3iQ\",\"homeModuleMainPageLink\":\"link://boneweb/code?url=\\\"https://www.taobao.com\\\"\"},{\"homeModuleMainPageTitle\":\"link://scan/pages/index\",\"homeModuleMainPageDesc\":\"desc desc desc\",\"homeModuleMainPageIconURL\":\"https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTBZWUMfkaGAkZHDtXPaHalO8umXWBfetPz0FPAxRuHfJEpESA3iQ\",\"homeModuleMainPageLink\":\"link://scan/pages/index\"},{\"homeModuleMainPageTitle\":\"link://profile/pages/index\",\"homeModuleMainPageDesc\":\"desc desc desc\",\"homeModuleMainPageIconURL\":\"https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTBZWUMfkaGAkZHDtXPaHalO8umXWBfetPz0FPAxRuHfJEpESA3iQ\",\"homeModuleMainPageLink\":\"link://profile/pages/index\"},{\"homeModuleMainPageTitle\":\"link://device/pages/index\",\"homeModuleMainPageDesc\":\"desc desc desc\",\"homeModuleMainPageIconURL\":\"https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTBZWUMfkaGAkZHDtXPaHalO8umXWBfetPz0FPAxRuHfJEpESA3iQ\",\"homeModuleMainPageLink\":\"link://device/pages/index\"}],\"homeModuleQRScanEnable\":true,\"homeModuleAddDeviceEnable\":true}}";


    private HomeViewModel homeViewModel;

    @Before
    public void setup() {
        JSONObject jsonObject = JSON.parseObject(JSON_TEXT);
        JSONObject opt = jsonObject.getJSONObject("opt");
        homeViewModel = new HomeViewModel();
        homeViewModel.mockOpts(opt);
    }

    @Test
    public void qrcodeScanEnable() {
        assert homeViewModel.qrcodeScanEnable();
    }

    @Test
    public void addDeviceEnable() {
        assert homeViewModel.addDeviceEnable();
    }

    @Test
    public void templates() {
        System.out.println(JSON.toJSONString(homeViewModel.convertJSON()));
        assert homeViewModel.convertJSON().size() == 5;
    }
}