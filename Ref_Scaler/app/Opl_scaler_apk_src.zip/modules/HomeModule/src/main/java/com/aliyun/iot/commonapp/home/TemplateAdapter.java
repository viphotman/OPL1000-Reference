package com.aliyun.iot.commonapp.home;

import android.widget.ImageView;

import com.aliyun.iot.commonapp.base.persistent.po.Template;
import com.bumptech.glide.Glide;
import com.bumptech.glide.request.RequestOptions;
import com.chad.library.adapter.base.BaseQuickAdapter;
import com.chad.library.adapter.base.BaseViewHolder;

import static com.bumptech.glide.load.resource.drawable.DrawableTransitionOptions.withCrossFade;

/**
 * @author sinyuk
 * @date 2018/12/20
 */
public class TemplateAdapter extends BaseQuickAdapter<Template, BaseViewHolder> {
    TemplateAdapter() {
        super(R.layout.template_list_item);
    }

    private RequestOptions requestOptions = new RequestOptions()
            .centerCrop()
            .fallback(R.drawable.ic_image_placeholder)
            .error(R.drawable.ic_image_placeholder)
            .placeholder(R.color.common_colorListSeparator);

    /**
     * Implement this method and use the helper to adapt the view to the given item.
     *
     * @param helper A fully initialized helper.
     * @param item   The item that needs to be displayed.
     */
    @Override
    protected void convert(BaseViewHolder helper, Template item) {
        helper.setText(R.id.title, item.title);
        helper.setText(R.id.desc, item.des);
        Glide.with(helper.getView(R.id.icon))
                .load(item.imageUrl)
                .apply(requestOptions.clone())
                .transition(withCrossFade(500))
                .into((ImageView) helper.getView(R.id.icon));
    }
}
