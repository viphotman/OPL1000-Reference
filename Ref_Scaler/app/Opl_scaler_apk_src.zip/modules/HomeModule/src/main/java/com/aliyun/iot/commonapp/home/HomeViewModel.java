package com.aliyun.iot.commonapp.home;

import android.support.annotation.VisibleForTesting;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.aliyun.iot.aep.sdk.threadpool.ThreadPool;
import com.aliyun.iot.commonapp.base.persistent.po.Template;
import com.aliyun.iot.commonapp.base.rest.AbstractRequest;
import com.aliyun.iot.componentmanager.ComponentManager;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * @author sinyuk
 * @date 2018/12/20
 */
@SuppressWarnings("WeakerAccess")
public class HomeViewModel {

    boolean qrcodeScanEnable() {
        return opts == null ? false : opts.getBoolean("homeModuleQRScanEnable");
    }

    boolean addDeviceEnable() {
        return opts == null ? false : opts.getBoolean("homeModuleAddDeviceEnable");
    }

    private static final String KEY_LIST_SLOT = "homeModuleMainList";
    private static final String KEY_TITLE_SLOT = "homeModuleMainPageTitle";
    private static final String KEY_URL_SLOT = "homeModuleMainPageLink";
    private static final String KEY_DESC_SLOT = "homeModuleMainPageDesc";
    private static final String KEY_ICON_SLOT = "homeModuleMainPageIconURL";

    private JSONObject opts = null;

    public HomeViewModel() {
        try {
            opts = ComponentManager.getInstance().getOptByComponentName("HomeModule");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @VisibleForTesting()
    public void mockOpts(JSONObject jsonObject) {
        opts = jsonObject;
    }

    void templates(final AbstractRequest.RequestCallback<List<Template>> callback) {
        if (opts == null || opts.isEmpty() || !opts.containsKey(KEY_LIST_SLOT)) {
            callback.onSuccess(Collections.<Template>emptyList());
            return;
        }
        ThreadPool.DefaultThreadPool.getInstance().submit(new Runnable() {
            @Override
            public void run() {
                try {
                    final List<Template> result = convertJSON();
                    ThreadPool.MainThreadHandler.getInstance().post(new Runnable() {
                        @Override
                        public void run() {
                            callback.onSuccess(result);
                        }
                    });
                } catch (final Exception e) {
                    e.printStackTrace();
                    ThreadPool.MainThreadHandler.getInstance().post(new Runnable() {
                        @Override
                        public void run() {
                            callback.onError(e);
                        }
                    });
                }
            }
        });
    }

    @VisibleForTesting()
    public List<Template> convertJSON() {
        final JSONArray jsonArray = opts.getJSONArray(KEY_LIST_SLOT);
        final List<Template> result = new ArrayList<>();
        for (int i = 0; i < jsonArray.size(); i++) {
            Template template = parseTemplate(jsonArray.getJSONObject(i));
            if (template != null) result.add(template);
        }
        return result;
    }

    private Template parseTemplate(JSONObject jsonObject) {
        if (jsonObject.containsKey(KEY_TITLE_SLOT)) {
            Template template = new Template();
            template.title = jsonObject.getString(KEY_TITLE_SLOT);
            template.url = jsonObject.getString(KEY_URL_SLOT);
            template.imageUrl = jsonObject.getString(KEY_ICON_SLOT);
            template.des = jsonObject.getString(KEY_DESC_SLOT);
            return template;
        }
        return null;
    }

}
