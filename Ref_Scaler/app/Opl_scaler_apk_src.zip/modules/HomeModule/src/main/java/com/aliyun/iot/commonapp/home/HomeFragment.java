package com.aliyun.iot.commonapp.home;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.view.AsyncLayoutInflater;
import android.support.v4.widget.SwipeRefreshLayout;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import com.aliyun.iot.aep.component.router.Router;
import com.aliyun.iot.commonapp.base.persistent.po.Template;
import com.aliyun.iot.commonapp.base.rest.AbstractRequest;
import com.aliyun.iot.commonapp.base.ui.BaseLazyFragment;
import com.aliyun.iot.commonapp.base.ui.LinkToast;
import com.aliyun.iot.commonapp.base.ui.ListItemMarginDecoration;
import com.chad.library.adapter.base.BaseQuickAdapter;


import java.util.List;


/**
 * @author sinyuk
 * @date 2018/12/19
 */
@SuppressWarnings("unused")
public class HomeFragment extends BaseLazyFragment {
    public static final String TAG = "HomeFragment";

    public static HomeFragment newInstance() {
        Bundle args = new Bundle();
        HomeFragment fragment = new HomeFragment();
        fragment.setArguments(args);
        return fragment;
    }

    private HomeViewModel viewModel;

    private SwipeRefreshLayout swipeRefreshLayout;
    private TemplateAdapter adapter;

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        viewModel = new HomeViewModel();
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.template_fragment, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        if (viewModel.qrcodeScanEnable()) {
            view.findViewById(R.id.button_scan).setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    String url = getString(R.string.default_router_format, getString(R.string.in_app_router_schema), getString(R.string.host_scan));
                    Router.getInstance().toUrlForResult(getActivity(), url, 0x1234);
                }
            });
        } else {
            view.findViewById(R.id.button_scan).setVisibility(View.GONE);
        }

        if (viewModel.addDeviceEnable()) {
            view.findViewById(R.id.button_add).setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    String url = getString(R.string.default_router_format, getString(R.string.in_app_router_schema), getString(R.string.host_add_device));
                    Router.getInstance().toUrl(getActivity(), url);
                }
            });
        } else {
            view.findViewById(R.id.button_add).setVisibility(View.GONE);
        }

        if (BuildConfig.MODE.toLowerCase().equals("debug")) {
            view.findViewById(R.id.button_debug).setVisibility(View.VISIBLE);
            view.findViewById(R.id.button_debug)
                    .setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View view) {
                            Router.getInstance().toUrl(getContext(), "link://debug/pages/index");
                        }
                    });
        } else {
            view.findViewById(R.id.button_debug).setVisibility(View.GONE);
        }

        setupRecyclerView(view);
        swipeRefreshLayout.setEnabled(false);
    }

    @SuppressLint("InflateParams")
    private void setupRecyclerView(View view) {
        swipeRefreshLayout = view.findViewById(R.id.swipe_refresh_layout);
        final RecyclerView recyclerView = view.findViewById(R.id.recycler_view);
        adapter = new TemplateAdapter();
        adapter.setOnItemClickListener(new BaseQuickAdapter.OnItemClickListener() {
            @Override
            public void onItemClick(BaseQuickAdapter a, View v, int p) {
                String url = adapter.getData().get(p).url;
                boolean found = Router.getInstance().toUrl(getContext(), url);
            }
        });
        adapter.setEnableLoadMore(false);
        recyclerView.setHasFixedSize(true);
        //noinspection ConstantConditions
        ListItemMarginDecoration decoration = new ListItemMarginDecoration(R.dimen.list_item_space, getContext());
        recyclerView.addItemDecoration(decoration);
        recyclerView.setLayoutManager(new LinearLayoutManager(getContext()));
        //noinspection ConstantConditions
        AsyncLayoutInflater inflater = new AsyncLayoutInflater(getContext());
        inflater.inflate(R.layout.template_list_empty, null, new AsyncLayoutInflater.OnInflateFinishedListener() {
            @Override
            public void onInflateFinished(@NonNull View view, int i, @Nullable ViewGroup viewGroup) {
                adapter.setEmptyView(view);
            }
        });
        recyclerView.setAdapter(adapter);
    }

    @Override
    protected void lazyDo() {
        swipeRefreshLayout.setRefreshing(true);
        viewModel.templates(new AbstractRequest.RequestCallback<List<Template>>() {
            @Override
            public void onSuccess(List<Template> data) {
                swipeRefreshLayout.setRefreshing(false);
                adapter.setNewData(data);
            }

            @Override
            public void onError(Throwable t) {
                swipeRefreshLayout.setRefreshing(false);
                if (t != null) {
                    LinkToast.makeText(getContext(), t.getLocalizedMessage(), Toast.LENGTH_SHORT).show();
                }
            }
        });
    }
}
