package com.aliyun.iot.commonapp.settings;

import com.aliyun.iot.commonapp.base.persistent.po.Template;
import com.chad.library.adapter.base.BaseQuickAdapter;
import com.chad.library.adapter.base.BaseViewHolder;

/**
 * @author sinyuk
 * @date 2019/1/4
 */
public class OptionAdapter extends BaseQuickAdapter<Template, BaseViewHolder> {
    public OptionAdapter() {
        super(R.layout.mine_list_item);
    }

    /**
     * Implement this method and use the helper to adapt the view to the given item.
     *
     * @param helper A fully initialized helper.
     * @param item   The item that needs to be displayed.
     */
    @Override
    protected void convert(BaseViewHolder helper, Template item) {
        helper.setText(R.id.title, item.title);
    }
}
