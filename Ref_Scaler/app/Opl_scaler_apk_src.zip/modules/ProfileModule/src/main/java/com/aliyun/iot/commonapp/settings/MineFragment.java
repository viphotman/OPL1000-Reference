package com.aliyun.iot.commonapp.settings;

import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.content.ContextCompat;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.aliyun.iot.aep.component.router.Router;
import com.aliyun.iot.aep.sdk.login.ILogoutCallback;
import com.aliyun.iot.aep.sdk.login.LoginBusiness;
import com.aliyun.iot.aep.sdk.login.data.UserInfo;
import com.aliyun.iot.commonapp.base.persistent.po.Template;
import com.aliyun.iot.commonapp.base.rest.AbstractRequest;
import com.aliyun.iot.commonapp.base.ui.BaseLazyFragment;
import com.aliyun.iot.commonapp.base.ui.LinearDividerItemDecoration;
import com.aliyun.iot.commonapp.base.ui.LinkAlertDialog;
import com.aliyun.iot.commonapp.base.ui.LinkBottomDialog;
import com.aliyun.iot.commonapp.base.ui.LinkToast;
import com.aliyun.iot.commonapp.base.ui.WebViewActivity;
import com.bumptech.glide.Glide;
import com.bumptech.glide.request.RequestOptions;
import com.chad.library.adapter.base.BaseQuickAdapter;

import java.util.List;

import static com.aliyun.iot.commonapp.base.ui.LinearDividerItemDecoration.LINEAR_DIVIDER_VERTICAL;

/**
 * @author sinyuk
 * @date 2018/12/19
 */
@SuppressWarnings("unused")
public class MineFragment extends BaseLazyFragment {
    public static final String TAG = "MineFragment";
    private MineViewModel viewModel;
    private RecyclerView recyclerView;
    private OptionAdapter adapter;

    public static MineFragment newInstance() {
        Bundle args = new Bundle();
        MineFragment fragment = new MineFragment();
        fragment.setArguments(args);
        return fragment;
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.mine_fragment, container, false);
    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        viewModel = new MineViewModel();
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        final String privacyUrl = viewModel.privacyURL();
        if (TextUtils.isEmpty(privacyUrl)) {
            view.findViewById(R.id.entry_privacy).setVisibility(View.GONE);
            view.findViewById(R.id.divider_privacy).setVisibility(View.GONE);
        } else {
            view.findViewById(R.id.entry_privacy).setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Router.getInstance().toUrl(getContext(), privacyUrl);
                }
            });
        }

        view.findViewById(R.id.entry_logout).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                new LinkBottomDialog.Builder(getContext())
                        .setTitle("退出当前账号?")
                        .setPositiveButton("确认", new LinkBottomDialog.OnClickListener() {
                            @Override
                            public void onClick(LinkBottomDialog dialog) {
                                dialog.dismiss();
                                logout();
                            }
                        })
                        .setNegativeButton("取消", new LinkBottomDialog.OnClickListener() {
                            @Override
                            public void onClick(LinkBottomDialog dialog) {
                                dialog.dismiss();
                            }
                        })
                        .create()
                        .show();
            }
        });

        view.findViewById(R.id.entry_about).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Router.getInstance().toUrl(getContext(), "link://about/pages/index");
            }
        });

        UserInfo userInfo = LoginBusiness.getUserInfo();
        ImageView imageView = view.findViewById(R.id.avatar);
        Glide.with(this)
                .load(userInfo.userAvatarUrl)
                .apply(new RequestOptions().circleCrop()
                        .error(R.drawable.ic_avatar_placeholder)
                        .fallback(R.drawable.ic_avatar_placeholder))
                .into(imageView);

        TextView screenName = view.findViewById(R.id.screenName);

        if (!TextUtils.isEmpty(userInfo.userNick)) {
            screenName.setText(userInfo.userNick);
        } else if (!TextUtils.isEmpty(userInfo.userPhone)) {
            screenName.setText(userInfo.userPhone);
        } else if (!TextUtils.isEmpty(userInfo.userEmail)) {
            screenName.setText(userInfo.userEmail);
        } else {
            screenName.setText(userInfo.userId);
        }


        setupRecyclerView(view);
    }

    private void setupRecyclerView(View view) {
        recyclerView = view.findViewById(R.id.recycler_view);
        adapter = new OptionAdapter();
        adapter.setOnItemClickListener(new BaseQuickAdapter.OnItemClickListener() {
            @Override
            public void onItemClick(BaseQuickAdapter a, View v, int p) {
                String url = adapter.getData().get(p).url;
                boolean found = Router.getInstance().toUrl(getContext(), url);
            }
        });
        adapter.setEnableLoadMore(false);

        //noinspection ConstantConditions
        LinearDividerItemDecoration decoration = new LinearDividerItemDecoration(getContext(), LINEAR_DIVIDER_VERTICAL);
        //noinspection ConstantConditions
        decoration.setDivider(ContextCompat.getDrawable(getContext(), R.drawable.list_item_divider));
        recyclerView.addItemDecoration(decoration);
        recyclerView.setHasFixedSize(true);
        recyclerView.setLayoutManager(new LinearLayoutManager(getContext()) {
            @Override
            public boolean canScrollHorizontally() {
                return super.canScrollHorizontally();
            }

            @Override
            public boolean canScrollVertically() {
                return false;
            }
        });
        recyclerView.setAdapter(adapter);
    }

    private void logout() {
        LoginBusiness.logout(new ILogoutCallback() {
            @Override
            public void onLogoutSuccess() {
                toInitActivity();
            }

            @Override
            public void onLogoutFailed(int i, String s) {
                toInitActivity();
                LinkToast.makeText(getContext(), s, Toast.LENGTH_LONG).show();
            }
        });
    }

    private void toInitActivity() {
        String url = getString(R.string.default_router_format,
                getString(R.string.in_app_router_schema),
                getString(R.string.host_main));
        Router.getInstance().toUrl(getContext(), url);
    }


    @Override
    protected void lazyDo() {
        viewModel.templates(new AbstractRequest.RequestCallback<List<Template>>() {
            @Override
            public void onSuccess(List<Template> data) {
                recyclerView.setVisibility(View.VISIBLE);
                adapter.setNewData(data);
            }

            @Override
            public void onError(Throwable t) {
                recyclerView.setVisibility(View.GONE);
                Toast.makeText(getContext(), t.getLocalizedMessage(), Toast.LENGTH_SHORT).show();
            }
        });
    }
}
