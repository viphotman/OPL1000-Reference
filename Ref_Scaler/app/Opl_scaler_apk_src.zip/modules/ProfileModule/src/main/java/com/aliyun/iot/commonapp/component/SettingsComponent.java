package com.aliyun.iot.commonapp.component;

import android.app.Activity;
import android.content.ActivityNotFoundException;
import android.content.Context;
import android.content.Intent;
import android.support.v4.app.Fragment;
import android.util.Log;

import com.aliyun.iot.commonapp.settings.AboutActivity;
import com.aliyun.iot.commonapp.settings.MineFragment;
import com.aliyun.iot.componentmanager.Component;
import com.aliyun.iot.componentmanager.ComponentInterface;

import java.util.HashMap;
import java.util.Map;

/**
 * @author sinyuk
 * @date 2018/12/24
 */
@SuppressWarnings("unused")
public class SettingsComponent implements ComponentInterface {
    @Override
    public void init(Context context) {

    }

    @SuppressWarnings("unused")
    public Component.ActionResponse getView(Component.ActionRequest request) {
        Component.ActionResponse response = new Component.ActionResponse(200, "");
        try {
            Map<String, Object> params = new HashMap<>(1);
            Fragment fragment = MineFragment.newInstance();
            params.put("data", fragment);
            response.setResponse(params);
        } catch (Exception e) {
            e.printStackTrace();
            response.setCode(500);
            response.setMsg(e.getMessage());
        }
        return response;
    }

    public void toAbout(Context context, Component.PageRequest request) {
        startActivity(context, request, AboutActivity.class);
    }

    private void startActivity(Context context, Component.PageRequest request, Class<?> cls) {
        try {
            Intent intent = new Intent(context, cls);
            if (null != request.getBundle()) {
                intent.putExtras(request.getBundle());
            }
            if (request.isNeedForResult()) {
                ((Activity) context).startActivityForResult(intent, request.getRequestCode());
            } else {
                context.startActivity(intent);
            }
        } catch (ActivityNotFoundException e) {
            Log.e("SettingsComponent", "startActivity: ", e);
        }
    }
}
