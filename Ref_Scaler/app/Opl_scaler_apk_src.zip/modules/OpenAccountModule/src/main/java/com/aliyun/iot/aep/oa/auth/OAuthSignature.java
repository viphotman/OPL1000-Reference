/*
 * Copyright 2007 Netflix, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.aliyun.iot.aep.oa.auth;

import android.util.Base64;

import java.io.ByteArrayOutputStream;
import java.net.URI;
import java.net.URISyntaxException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.List;

import javax.crypto.Mac;
import javax.crypto.SecretKey;
import javax.crypto.spec.SecretKeySpec;


/**
 * @author guanbin
 */
public class OAuthSignature {

    private String consumerSecret;
    private String tokenSecret;

    public void sign(OAuthMessage message) {
        String baseString = getBaseString(message);
        String signature = "";
        try {
            signature = new String(Base64.encode(computeSignature(baseString), Base64.NO_WRAP), "utf-8");
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
        message.addParameter(new OAuthPair(OAuthConstant.OAUTH_SIGNATURE, signature));
    }

    private String getBaseString(OAuthMessage message) {
        List<OAuthPair> parameters = message.getParameters();
        return OAuthUtil.percentEncode(message.method.toUpperCase()) + '&' + OAuthUtil.percentEncode(normalizeUrl(message.url)) + '&'
                + OAuthUtil.percentEncode(normalizeParameters(parameters));
    }

    private String normalizeUrl(String url) {
        URI uri;
        try {
            uri = new URI(url);
        } catch (URISyntaxException e) {
            throw new RuntimeException(e);
        }
        String scheme = uri.getScheme().toLowerCase();
        String authority = uri.getAuthority().toLowerCase();
        int index = authority.lastIndexOf(":");
        if (index >= 0) {
            authority = authority.substring(0, index);
        }
        String path = uri.getRawPath();
        if (path == null || path.length() <= 0) {
            path = "/"; // conforms to RFC 2616 section 3.2.2
        }
        // we know that there is no query and no fragment here.
        return scheme + "://" + authority + path;
    }

    private String normalizeParameters(Collection<OAuthPair> parameters) {
        List<ComparableParameter> comparableParams = new ArrayList<ComparableParameter>(parameters.size());
        for (OAuthPair parameter : parameters) {
            if (OAuthConstant.OAUTH_SIGNATURE.equals(parameter.key))
                continue;

            comparableParams.add(new ComparableParameter(parameter));
        }

        Collections.sort(comparableParams);

        ByteArrayOutputStream byteArrayBuff = new ByteArrayOutputStream();
        try {
            boolean first = true;
            for (ComparableParameter parameter : comparableParams) {
                OAuthPair pair = parameter.object;
                if (first) {
                    first = false;
                } else {
                    byteArrayBuff.write('&');
                }

                byteArrayBuff.write(OAuthUtil.percentEncode(pair.key).getBytes(OAuthConstant.ENCODING));
                byteArrayBuff.write('=');
                byteArrayBuff.write(OAuthUtil.percentEncode(pair.value).getBytes(OAuthConstant.ENCODING));
            }
            return new String(byteArrayBuff.toByteArray(), OAuthConstant.ENCODING);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    private byte[] computeSignature(String baseString) {
        String appSec = OAuthUtil.percentEncode(getConsumerSecret());
        String tokenSec = OAuthUtil.percentEncode(getTokenSecret());
        String keyString = appSec + '&' + (tokenSec == null ? "" : tokenSec);
        byte[] keyBytes;
        try {
            keyBytes = keyString.getBytes(OAuthConstant.ENCODING);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
        SecretKey key = new SecretKeySpec(keyBytes, "HmacSHA1");

        try {
            Mac mac = Mac.getInstance("HmacSHA1");
            mac.init(key);
            byte[] text = baseString.getBytes(OAuthConstant.ENCODING);
            return mac.doFinal(text);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }

    }

    private static class ComparableParameter implements Comparable<ComparableParameter> {

        public ComparableParameter(OAuthPair value) {
            String k = value.key;
            String v = value.value;
            this.key = OAuthUtil.percentEncode(k) + ' ' + OAuthUtil.percentEncode(v);
            this.object = value;
        }

        private final OAuthPair object;

        private final String key;

        public int compareTo(ComparableParameter that) {
            return this.key.compareTo(that.key);
        }
    }

    public String getConsumerSecret() {
        return consumerSecret;
    }

    public void setConsumerSecret(String consumerSecret) {
        this.consumerSecret = consumerSecret;
    }

    public String getTokenSecret() {
        return tokenSecret;
    }

    public void setTokenSecret(String tokenSecret) {
        this.tokenSecret = tokenSecret;
    }
}
