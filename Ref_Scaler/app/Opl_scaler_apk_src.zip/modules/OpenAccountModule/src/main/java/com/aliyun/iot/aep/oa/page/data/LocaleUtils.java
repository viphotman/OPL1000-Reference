package com.aliyun.iot.aep.oa.page.data;

import android.text.TextUtils;

import com.alibaba.sdk.android.openaccount.OpenAccountConfigs;

/**
 * Created by feijie.xfj on 18/5/24.
 */

public class LocaleUtils {
    private static final String DEFAULT_LOCALE = "zh_CN";

    public LocaleUtils() {
    }

    public static String getCurrentLocale() {
        return TextUtils.isEmpty(OpenAccountConfigs.clientLocal)?"zh_CN": OpenAccountConfigs.clientLocal;
    }

    public static boolean isENLocale(String locale) {
        return locale == null?false:locale.toLowerCase().indexOf("en") != -1;
    }

    public static boolean isZHLocale(String locale) {
        return locale == null?false:locale.toLowerCase().indexOf("zh") != -1;
    }

    public static boolean isUseTraditionChinese(String locale) {
        if(locale == null) {
            return false;
        } else {
            String lowerCasedLocale = locale.toLowerCase();
            return lowerCasedLocale.indexOf("tw") != -1 || lowerCasedLocale.indexOf("hk") != -1;
        }
    }
}
