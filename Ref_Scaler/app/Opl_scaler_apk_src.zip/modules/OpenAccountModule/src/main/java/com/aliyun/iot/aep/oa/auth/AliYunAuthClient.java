package com.aliyun.iot.aep.oa.auth;

import android.content.Context;
import android.text.TextUtils;
import android.util.Log;

import com.aliyun.iot.aep.oa.auth.listener.AliYunAuthRequestListener;

import java.io.IOException;
import java.net.URLEncoder;
import java.security.SecureRandom;
import java.security.cert.CertificateException;
import java.security.cert.X509Certificate;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

import javax.net.ssl.SSLContext;
import javax.net.ssl.SSLSocketFactory;
import javax.net.ssl.TrustManager;
import javax.net.ssl.X509TrustManager;

import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.FormBody;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;

/**
 * Created by feijie.xfj on 18/3/13.
 */

public class AliYunAuthClient {
    private static final String TAG = "AliYunAuthClient";

    private String appKey;
    private String appSecret;

    private static final String BASE_DAILY_URL = "http://account.aliyun.test";
    private static final String BASE_PRE_URL = "https://account.aliyun.com";
    private static final String BASE_RELEASE_URL = "https://account.aliyun.com";

    public static final String HTTP_METHOD = "POST";

    private String env;

    private String baseURL = "";

    private Context context;

    public AliYunAuthClient(String appKey, String appSecret, String env, Context context) {
        if (TextUtils.isEmpty(appKey) || TextUtils.isEmpty(appSecret))
            throw new IllegalArgumentException("appKey or appSecret should not be empty or null");
        this.appKey = appKey;
        this.appSecret = appSecret;
        if ("TEST".equalsIgnoreCase(env)) {
            baseURL = BASE_DAILY_URL;
        } else if ("PRE".equalsIgnoreCase(env)) {
            baseURL = BASE_PRE_URL;
        } else {
            baseURL = BASE_RELEASE_URL;
        }
        //测试，临时写死日常URL
        Log.i(TAG, "ALiYun BASE_REQUEST_URL is :" + baseURL);
        this.context = context;
    }

    private static SSLSocketFactory createSSLSocketFactory() {
        SSLSocketFactory ssfFactory = null;
        try {
            SSLContext context = SSLContext.getInstance("SSL");
            context.init(null, new TrustManager[]{new TrustEveryOneManager()}, new SecureRandom());
            ssfFactory = context.getSocketFactory();
        } catch (Exception e) {
        }
        return ssfFactory;
    }

    public void callAliYunAuthRequest(AliYunAuthRequestListener listener) {
        List<OAuthPair> params = new ArrayList<OAuthPair>();
        params.add(new OAuthPair("oauth_callback", "http://aliyun.iot.web.com/login.html"));
        callRealRequest(baseURL + "/oauth/request_token", params, null, listener);
    }

    public void callGetAliYunAccessTokenRequest(String oauth_token, String oauth_verifier, String oauth_token_secret, AliYunAuthRequestListener listener) {
        List<OAuthPair> params = new ArrayList<OAuthPair>();
        params.add(new OAuthPair("oauth_token", oauth_token));
        params.add(new OAuthPair("oauth_verifier", oauth_verifier));
        Log.i(TAG, "oauth_token:" + oauth_token + "  oauth_verifier: " + oauth_verifier);

        //获取AccessToken时，tokenSec已经在第一步请求RequestToken中获取到了，这里需要填入，否则签名会失败
        callRealRequest(baseURL + "/oauth/access_token", params, oauth_token_secret, listener);
    }


    private void callRealRequest(String api, List<OAuthPair> params, String tokenSec, AliYunAuthRequestListener listener) {
        OAuthMessage message = null;
        Log.i(TAG, "api:" + api);
        message = new OAuthMessage(HTTP_METHOD, api, params);
        // add common parameters specified in oauth1.0 protocol
        message.addParameter(new OAuthPair(OAuthConstant.OAUTH_CONSUMER_KEY, this.appKey));
        message.addParameter(new OAuthPair(OAuthConstant.OAUTH_SIGNATURE_METHOD, OAuthConstant.HMAC_SHA1));
        message.addParameter(new OAuthPair(OAuthConstant.OAUTH_VERSION, OAuthConstant.VERSION_1_0));
        message.addParameter(new OAuthPair(OAuthConstant.OAUTH_TIMESTAMP,
                String.valueOf(System.currentTimeMillis() / 1000)));
        message.addParameter(new OAuthPair(OAuthConstant.OAUTH_NONCE, UUID.randomUUID().toString().replaceAll("-", "")));

        OAuthSignature signer = new OAuthSignature();
        signer.setConsumerSecret(appSecret);
        signer.setTokenSecret(tokenSec);
        signer.sign(message);
        sendRequest(message, listener);
    }

    private void sendRequest(OAuthMessage from, final AliYunAuthRequestListener listener) {
        OkHttpClient.Builder clientBuilder = new OkHttpClient.Builder();
        // clientBuilder.sslSocketFactory(createSSLSocketFactory(), new TrustEveryOneManager());

        FormBody.Builder builder = new FormBody.Builder();
        try {
            for (OAuthPair parameter : from.getParameters()) {
                builder.addEncoded(URLEncoder.encode(OAuthUtil.percentEncode(parameter.key), OAuthConstant.ENCODING),
                        URLEncoder.encode(OAuthUtil.percentEncode(parameter.value), OAuthConstant.ENCODING));
            }
        } catch (Exception e) {
            Log.i(TAG, e.toString());
        }

        RequestBody body = builder.build();


        final Request request = new Request.Builder()
                .url(from.getUrl())
                .post(body)
                .build();

        Call call = clientBuilder.build().newCall(request);

        call.enqueue(new Callback() {
            @Override
            public void onFailure(Call call, IOException e) {
                Log.i(TAG, "onFailure:" + e.toString());
                if (listener != null) {
                    listener.onFailed("response failed! :" + e.toString());
                }
            }

            @Override
            public void onResponse(Call call, Response response) throws IOException {
                String result = response.body().string();
                Log.i(TAG, "onResponse():" + result);
                if (!TextUtils.isEmpty(result)) {
                    if (listener != null) {
                        listener.onResponse(result);
                        return;
                    }
                }
                if (listener != null) {
                    listener.onFailed("response failed:" + response.toString());
                }
            }
        });

    }


    public static class TrustEveryOneManager implements X509TrustManager {
        public void checkClientTrusted(X509Certificate[] arg0, String arg1) throws CertificateException {
        }

        public void checkServerTrusted(X509Certificate[] arg0, String arg1) throws CertificateException {
        }

        public X509Certificate[] getAcceptedIssuers() {
            return new X509Certificate[]{};
        }
    }
}
