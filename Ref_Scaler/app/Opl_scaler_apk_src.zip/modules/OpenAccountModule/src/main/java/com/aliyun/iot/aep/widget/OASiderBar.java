package com.aliyun.iot.aep.widget;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Typeface;
import android.util.AttributeSet;
import android.util.TypedValue;

import com.alibaba.sdk.android.openaccount.ui.widget.SiderBar;

/**
 * Created by feijie.xfj on 18/4/11.
 */

public class OASiderBar extends SiderBar {


    private float mInterval;

    public OASiderBar(Context context) {
        this(context, null);
    }

    public OASiderBar(Context context, AttributeSet attrs) {
        this(context, attrs, 0);
    }

    public OASiderBar(Context context, AttributeSet attrs, int defStyle) {
        super(context, attrs, defStyle);
        b = new String[]{"#", "A", "B", "C", "D", "E", "F", "G", "H", "I", "J", "K", "L", "M", "N", "O", "P", "Q", "R", "S", "T", "U", "V", "W", "X", "Y", "Z"};
    }


    @Override
    protected void onMeasure(int widthMeasureSpec, int heightMeasureSpec) {
        paint.setAntiAlias(true);
        setTextSize(12);
        int size = MeasureSpec.getSize(heightMeasureSpec);
        int mode = MeasureSpec.getMode(heightMeasureSpec);

        if (mode != MeasureSpec.EXACTLY) {
            size = (int) ((paint.descent() - paint.ascent() + mInterval) * b.length);
        }

        setMeasuredDimension(getDefaultSize(0, widthMeasureSpec), size);
    }


    protected void setTextSize(float size) {
        super.setTextSize(TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_SP, size, getResources().getDisplayMetrics()));
    }


    protected void onDraw(Canvas canvas) {
        int height = this.getHeight();
        int width = this.getWidth();
        float letterHeight = (float) this.getViewHeight() * 1.0F / (float) b.length;

        for (int i = 0; i < b.length; ++i) {
            float yPos = letterHeight * (float) i + letterHeight;
            if (yPos > (float) height) {
                break;
            }

            float xPos = (float) (width / 2);
            this.setColor(Color.parseColor("#1fc88b"));
            this.setTypeface(Typeface.DEFAULT_BOLD);
            this.setTextSize(12);
            if (i == this.choose) {
                this.setColor(-16776961);
                this.setFakeBoldText(true);
            }
            paint.setTextAlign(Paint.Align.CENTER);
            canvas.drawText(b[i], xPos, yPos, this.paint);
            this.paint.reset();
        }

    }


    protected int getViewHeight() {
        if (this.viewHeight == 0) {
            this.viewHeight = this.getHeight();
        }

        return this.viewHeight;
    }

    /**
     *
     * @param interval dp
     */
    public void setInterval(float interval) {
        this.mInterval = TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, interval, getResources().getDisplayMetrics());
        requestLayout();

    }

}
