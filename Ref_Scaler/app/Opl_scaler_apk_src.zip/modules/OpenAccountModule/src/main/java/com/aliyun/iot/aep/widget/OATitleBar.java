package com.aliyun.iot.aep.widget;

import android.content.Context;
import android.util.AttributeSet;
import android.view.LayoutInflater;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.alibaba.sdk.android.openaccount.util.ResourceUtils;

public class OATitleBar extends LinearLayout {


    public static final int TYPE_SIMPLE = 0x00000001;
    public static final int TYPE_IMAGE = 0x00000000;

    private int mType = TYPE_IMAGE;


    private ImageView mBtnBack;
    private TextView mTitle;

    public OATitleBar(Context context) {
        this(context, null);
    }

    public OATitleBar(Context context, AttributeSet attrs) {
        this(context, attrs, 0);
    }

    public OATitleBar(Context context, AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        setOrientation(VERTICAL);
        setType(TYPE_IMAGE);
    }


    public void setType(int type) {
        mType = type;
        initView();
    }


    private void initView() {
        removeAllViews();
        if (mType==TYPE_SIMPLE){
            LayoutInflater.from(getContext()).inflate(ResourceUtils.getRLayout("ali_sdk_openaccount_title_layout_1"), this, true);
        }else{
            LayoutInflater.from(getContext()).inflate(ResourceUtils.getRLayout("ali_sdk_openaccount_title_layout_2"), this, true);

        }

        mBtnBack = findViewById(ResourceUtils.getRId("ali_sdk_openaccount_back"));
        mTitle = findViewById(ResourceUtils.getRId("ali_sdk_openaccount_title"));
    }


    public void setBackClickListener(OnClickListener onClickListener) {
        mBtnBack.setOnClickListener(onClickListener);
    }


    public void setTitle(String title) {
        mTitle.setText(title);
    }


}
