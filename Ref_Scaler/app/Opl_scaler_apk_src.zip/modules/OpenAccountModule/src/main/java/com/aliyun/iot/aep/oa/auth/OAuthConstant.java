/**
 * Project: aliyun.oauth
 * 
 * File Created at 2011-7-15
 * 
 * Copyright 2011 Alibaba.com Corporation Limited.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of
 * Alibaba Company. ("Confidential Information").  You shall not
 * disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into
 * with Alibaba.com.
 */
package com.aliyun.iot.aep.oa.auth;

/**
 * @author guanbin
 */
public class OAuthConstant {

    public static final String VERSION_1_0              = "1.0";
    public static final String ENCODING                 = "UTF-8";
    public static final String HMAC_SHA1                = "HMAC-SHA1";
    

    public static final String OAUTH_CONSUMER_KEY       = "oauth_consumer_key";
    public static final String OAUTH_TOKEN              = "oauth_token";
    public static final String OAUTH_TOKEN_SECRET       = "oauth_token_secret";
    public static final String OAUTH_SIGNATURE_METHOD   = "oauth_signature_method";
    public static final String OAUTH_SIGNATURE          = "oauth_signature";
    public static final String OAUTH_TIMESTAMP          = "oauth_timestamp";
    public static final String OAUTH_NONCE              = "oauth_nonce";
    public static final String OAUTH_VERSION            = "oauth_version";
    public static final String OAUTH_CALLBACK           = "oauth_callback";
    public static final String OAUTH_CALLBACK_CONFIRMED = "oauth_callback_confirmed";
    public static final String OAUTH_VERIFIER           = "oauth_verifier";
    public static final String OAUTH_CALLBACK_OOB       = "oob";
    public static final String OAUTH_PK                 = "oauth_pk";
}
