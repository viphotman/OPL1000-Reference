package com.aliyun.iot.aep.oa.page;

import android.content.Context;
import android.graphics.Color;
import android.graphics.Typeface;
import android.os.Build;
import android.os.Bundle;
import android.util.TypedValue;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import com.alibaba.sdk.android.openaccount.ui.ui.EmailResetPwdFillPwdActivity;
import com.alibaba.sdk.android.openaccount.util.ResourceUtils;
import com.aliyun.iot.aep.oa.OALanguageHelper;
import com.aliyun.iot.aep.widget.OATitleBar;
import com.aliyun.iot.commonapp.login.R;

import java.lang.reflect.Field;

public class OAResetPasswordFillMailPwdAcitvity extends EmailResetPwdFillPwdActivity {

    private String mEntrance = ENTRANCE_LOGIN;//界面启动入口
    public static final String ENTRANCE_LOGIN = "login";//从登录进入
    public static final String ENTRANCE_APP = "app";//从App内进入

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        try {
            mEntrance = this.getIntent().getStringExtra("entrance");
            if (mEntrance == null) {
                mEntrance = ENTRANCE_LOGIN;
            }
        } catch (Exception e) {
            e.printStackTrace();
            mEntrance = ENTRANCE_LOGIN;
        }
        super.onCreate(savedInstanceState);
        findViewById(R.id.aliuser_appbar).setVisibility(View.GONE);
        OATitleBar titleBar = findViewById(R.id.oat_title);
        if (ENTRANCE_LOGIN.equalsIgnoreCase(mEntrance)) {
            titleBar.setType(OATitleBar.TYPE_IMAGE);
            titleBar.setTitle(getString(R.string.account_input_new_passwrod));
        } else {
            titleBar.setType(OATitleBar.TYPE_SIMPLE);
            titleBar.setTitle(getString(R.string.account_reset_pwd));
        }
        titleBar.setBackClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
        updateOriginalOAView();
    }


    @Override
    protected void attachBaseContext(Context newBase) {
        super.attachBaseContext(OALanguageHelper.attachBaseContext(newBase));
    }


    //隐藏调整OA的组件  -- 定制
    private void updateOriginalOAView() {
        //隐藏账密左边的icon
        View pwdLeft = passwordInputBox.findViewById(R.id.left_icon);
        if (pwdLeft != null) {
            pwdLeft.setVisibility(View.GONE);
        }
        EditText leftInput = passwordInputBox.getEditText();
        if (leftInput != null) {
            leftInput.setHint("");
            setCursorDrawableColor(passwordInputBox.getEditText(), ResourceUtils.getRDrawable(this, "et_cursor_color"));
            leftInput.setTextSize(TypedValue.COMPLEX_UNIT_DIP, 18);
            leftInput.setTextColor(Color.BLACK);
        }
        Typeface typeface = Typeface.createFromAsset(this.getAssets(), "ali_sdk_openaccount/newiconfont.ttf");
        Button btnEye = (Button) passwordInputBox.findViewById("open_eye");
        btnEye.setTypeface(typeface);

    }


    @Override
    protected void initSystemUI() {
        if (ENTRANCE_LOGIN.equalsIgnoreCase(mEntrance)) {
            super.initSystemUI();
            TRANSPARENT();
        } else {
            unTranparent();
        }


    }

    protected final void TRANSPARENT() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            Window window = getWindow();
            window.clearFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS
                    | WindowManager.LayoutParams.FLAG_TRANSLUCENT_NAVIGATION);
            window.getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                    | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                    | View.SYSTEM_UI_FLAG_LAYOUT_STABLE);
            window.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS);
            window.setStatusBarColor(Color.TRANSPARENT);
            window.setNavigationBarColor(Color.TRANSPARENT);
        }
    }

    /**
     * 取消主题透明栏状态
     */
    private final void unTranparent() {
        Window window = getWindow();
        window.clearFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS
                | WindowManager.LayoutParams.FLAG_TRANSLUCENT_NAVIGATION| WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS);
    }

    public void setCursorDrawableColor(EditText editText, int color) {
        try {
            Field f = TextView.class.getDeclaredField("mCursorDrawableRes");
            f.setAccessible(true);
            f.set(editText, color);
        } catch (Exception ignored) {
            ignored.printStackTrace();
        }
    }

}
