package com.aliyun.iot.aep.oa.page;

import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.text.InputType;
import android.text.TextUtils;
import android.util.AttributeSet;
import android.util.Log;
import android.util.TypedValue;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.WindowManager;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.RadioGroup;
import android.widget.TextView;

import com.alibaba.fastjson.JSONObject;
import com.alibaba.sdk.android.oauth.OauthPlateform;
import com.alibaba.sdk.android.openaccount.OauthService;
import com.alibaba.sdk.android.openaccount.OpenAccountSDK;
import com.alibaba.sdk.android.openaccount.callback.LoginCallback;
import com.alibaba.sdk.android.openaccount.model.OpenAccountSession;
import com.alibaba.sdk.android.openaccount.ui.OpenAccountUIService;
import com.alibaba.sdk.android.openaccount.ui.callback.EmailRegisterCallback;
import com.alibaba.sdk.android.openaccount.ui.callback.EmailResetPasswordCallback;
import com.alibaba.sdk.android.openaccount.ui.ui.LoginActivity;
import com.alibaba.sdk.android.openaccount.util.ResourceUtils;
import com.aliyun.iot.aep.oa.OALanguageHelper;
import com.aliyun.iot.aep.oa.OAUIInitHelper;
import com.aliyun.iot.aep.sdk.threadpool.ThreadPool;
import com.aliyun.iot.aep.widget.OAInputBoxWithHistory;
import com.aliyun.iot.aep.widget.RegisterSelectorDialogFragment;
import com.aliyun.iot.aep.widget.ResetSelectorDialogFragment;
import com.aliyun.iot.commonapp.login.R;
import com.aliyun.iot.componentmanager.ComponentManager;

import java.lang.reflect.Field;

/**
 * @author feijie.xfj
 * @date 18/1/11
 */
public class OALoginActivity extends LoginActivity implements RadioGroup.OnCheckedChangeListener, OnClickListener {

    private int requestCode = 100;
    private TextView mTvHint;
    private RegisterSelectorDialogFragment registerSelectorDialogFragment;
    private ResetSelectorDialogFragment resetSelectorDialogFragment;
    private String login_type = "phone";


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_PAN);
        super.onCreate(savedInstanceState);
        findViewById(R.id.aliuser_appbar).setVisibility(View.GONE);

        registerSelectorDialogFragment = new RegisterSelectorDialogFragment();
        registerSelectorDialogFragment.setOnClickListener(registerListenr);

        resetSelectorDialogFragment = new ResetSelectorDialogFragment();
        resetSelectorDialogFragment.setOnClickListener(resetListenr);

        findViewById(R.id.imageview_account_back).setVisibility(View.INVISIBLE);

        if (isForeign()) {
            findViewById(R.id.oauth_login_google).setOnClickListener(this);
        } else {
            findViewById(R.id.oauth_3rd_layout).setVisibility(View.GONE);
        }

        mTvHint = findViewById(R.id.tv_hint);
        RadioGroup radioGroup = findViewById(R.id.rg_login_type);
        radioGroup.setOnCheckedChangeListener(this);
        findViewById(R.id.btn_mobile).performClick();

        configRegisterEntry();
    }

    /**
     * 是否隐藏注册按钮
     */
    private void configRegisterEntry() {
        final View registerView = findViewById(R.id.register);
        if (registerView != null) {
            registerView.setVisibility(View.INVISIBLE);
            ThreadPool.DefaultThreadPool.getInstance().submit(new Runnable() {
                @Override
                public void run() {
                    try {
                        JSONObject config = ComponentManager.getInstance().getOptByComponentName("OpenAccountModule");
                        final boolean enable =
                                config == null ? false : config.getBoolean("registerAllowed");
                        ThreadPool.MainThreadHandler.getInstance().post(new Runnable() {
                            @Override
                            public void run() {
                                if (enable) {
                                    registerView.setVisibility(View.VISIBLE);
                                } else {
                                    registerView.setVisibility(View.INVISIBLE);
                                }
                            }
                        });
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }
            });
        }
    }

    @Override
    protected void useCustomAttrs(Context context, AttributeSet attrs) {
        if (this.registerTV != null) {
            this.registerTV.setTextColor(Color.WHITE);
        }
        updateOriginalOAView();
    }


    private boolean isForeign() {
        String region = getIntent().getStringExtra("countryNum");
        if (TextUtils.isEmpty(region) || "86".equalsIgnoreCase(region)) {
            return false;
        } else {
            return true;
        }

    }


    @Override
    protected void attachBaseContext(Context newBase) {
        super.attachBaseContext(OALanguageHelper.attachBaseContext(newBase));
    }


    //隐藏调整OA的组件  -- 定制
    private void updateOriginalOAView() {
        //隐藏账密左边的icon
        LinearLayout pwdLL = (LinearLayout) findViewById(R.id.password);
        View pwdLeft = pwdLL.findViewById(R.id.left_icon);
        if (pwdLeft != null) {
            pwdLeft.setVisibility(View.GONE);
        }

        EditText leftInput = pwdLL.findViewById(R.id.input);
        if (leftInput != null) {
            leftInput.setHint("");
            setCursorDrawableColor(leftInput, ResourceUtils.getRDrawable(this, "et_cursor_color"));
            leftInput.setTextSize(TypedValue.COMPLEX_UNIT_DIP, 18);
            leftInput.setTextColor(Color.BLACK);
        }
        View eyeView = pwdLL.findViewById(R.id.open_eye);
        if (eyeView != null) {
            eyeView.setVisibility(View.GONE);
        }

        //隐藏账密左边的icon
        LinearLayout accountLL = (LinearLayout) findViewById(R.id.login_id);

        String countryNum = getIntent().getStringExtra("countryNum");

        TextView countryNumTV = (TextView) loginIdEdit.findViewById(R.id.edt_chosed_country_num);
        if (!TextUtils.isEmpty(countryNum) && isNumeric(countryNum)) {
            countryNumTV.setText(countryNum);
        }
        countryNumTV.setTextSize(TypedValue.COMPLEX_UNIT_DIP, 18);
        countryNumTV.setTextColor(getResources().getColor(R.color.color_999999));
        ((TextView) loginIdEdit.findViewById("edt_chosed_country_num_sub")).setTextColor(getResources().getColor(R.color.color_999999));
        View history = accountLL.findViewById(R.id.open_history);
        if (history != null) {
            history.setVisibility(View.GONE);
        }
        View accountLeft = accountLL.findViewById(R.id.left_icon);
        if (accountLeft != null) {
            accountLeft.setVisibility(View.GONE);
        }
        EditText rightInput = accountLL.findViewById(R.id.input);
        if (rightInput != null) {
            rightInput.setHint("");
            setCursorDrawableColor(rightInput, ResourceUtils.getRDrawable(this, "et_cursor_color"));
            rightInput.setTextSize(TypedValue.COMPLEX_UNIT_DIP, 18);
            rightInput.setTextColor(Color.BLACK);
        }

    }

    private boolean isNumeric(String str) {
        for (int i = str.length(); --i >= 0; ) {
            int chr = str.charAt(i);
            if (chr < 48 || chr > 57)
                return false;
        }
        return true;
    }


    @Override
    public void onCheckedChanged(RadioGroup group, int checkedId) {
        if (checkedId == R.id.btn_mobile) {
            login_type = "phone";
            ((OAInputBoxWithHistory) loginIdEdit).setLoginType(login_type);
            loginIdEdit.getEditText().setText("");
            loginIdEdit.getEditText().setInputType(InputType.TYPE_CLASS_PHONE);
            this.passwordEdit.getInputBoxWithClear().getEditText().setText("");
            findViewById(R.id.edt_chosed_country_num).setVisibility(View.VISIBLE);
            findViewById(R.id.edt_chosed_country_num_sub).setVisibility(View.VISIBLE);
            findViewById(R.id.country_choose_btn).setVisibility(View.VISIBLE);
            mTvHint.setText(R.string.account_name_hint);

        } else if (checkedId == R.id.btn_email) {
            login_type = "mail";
            ((OAInputBoxWithHistory) loginIdEdit).setLoginType(login_type);
            loginIdEdit.getEditText().setText("");
            loginIdEdit.getEditText().setInputType(InputType.TYPE_CLASS_TEXT);
            this.passwordEdit.getInputBoxWithClear().getEditText().setText("");
            findViewById(R.id.edt_chosed_country_num).setVisibility(View.GONE);
            findViewById(R.id.edt_chosed_country_num_sub).setVisibility(View.GONE);
            findViewById(R.id.country_choose_btn).setVisibility(View.GONE);
            mTvHint.setText(R.string.ali_sdk_openaccount_text_mail);
        }
    }

    @Override
    public void onClick(View v) {
        int plateform = OauthPlateform.GOOGLE;
        if (v.getId() == R.id.imageview_account_back) {
            finish();
            return;
//        } else if (v.getId() == R.id.oauth_login_facebook) {
//            plateform = OauthPlateform.FACEBOOK;
//        } else if (v.getId() == R.id.oauth_login_twitter) {
//            plateform = OauthPlateform.TWITTER;
        } else if (v.getId() == R.id.oauth_login_google) {
            plateform = OauthPlateform.GOOGLE;
        }
        OauthService oauthService = OpenAccountSDK.getService(OauthService.class);
        oauthService.oauth(OALoginActivity.this, plateform, new LoginCallback() {
            @Override
            public void onSuccess(OpenAccountSession session) {
                LoginCallback loginCallback = OALoginActivity.this.getLoginCallback();
                if (loginCallback != null) {
                    loginCallback.onSuccess(session);
                    OALoginActivity.this.finishWithoutCallback();
                }
            }

            @Override
            public void onFailure(int code, String msg) {
                Log.e(TAG, "oauth onFailure: " + code + "  " + msg);
                LoginCallback loginCallback = OALoginActivity.this.getLoginCallback();
                if (loginCallback != null) {
                    loginCallback.onFailure(code, msg);
                }
            }
        });

    }

    private OnClickListener registerListenr = new OnClickListener() {
        @Override
        public void onClick(View v) {
            if (v.getId() == R.id.btn_register_phone) {//手机注册
                OpenAccountUIService openAccountUIService = OpenAccountSDK.getService(OpenAccountUIService.class);
                openAccountUIService.showRegister(OALoginActivity.this, OARegisterActivity.class, getRegisterLoginCallback());
                registerSelectorDialogFragment.dismissAllowingStateLoss();
            } else if (v.getId() == R.id.btn_register_email) {//邮箱注册
                OpenAccountUIService openAccountUIService = OpenAccountSDK.getService(OpenAccountUIService.class);
                openAccountUIService.showEmailRegister(OALoginActivity.this, OARegisterEmailActivity.class, getEmailRegisterCallback());
                registerSelectorDialogFragment.dismissAllowingStateLoss();
            }
        }
    };


    private OnClickListener resetListenr = new OnClickListener() {
        @Override
        public void onClick(View v) {
            if (v.getId() == R.id.btn_register_phone) {//手机找回
                forgetPhonePassword(v);
                resetSelectorDialogFragment.dismissAllowingStateLoss();
            } else if (v.getId() == R.id.btn_register_email) {//邮箱找回
                forgetMailPassword(v);
                resetSelectorDialogFragment.dismissAllowingStateLoss();
            }
        }
    };

    public void forgetPhonePassword(View view) {
        super.forgetPassword(view);
    }

    public void forgetMailPassword(View view) {
        OpenAccountUIService openAccountUIService = (OpenAccountUIService) OpenAccountSDK.getService(OpenAccountUIService.class);
        openAccountUIService.showEmailResetPassword(this, OAResetMailPasswordActivity.class, this.getEmailResetPasswordCallback());
    }


    @Override
    public void forgetPassword(View view) {
        resetSelectorDialogFragment.showAllowingStateLoss(getSupportFragmentManager(), "resetSelectorDialogFragment");
    }

    @Override
    protected String getLoginId() {
        if (this.loginIdEdit == null)
            return "";
        if ("mail".equalsIgnoreCase(login_type)) {
            return this.loginIdEdit.getEditText().getText().toString();
        } else {

            return super.getLoginId();
        }

    }


    @Override
    public void registerUser(View view) {
        registerSelectorDialogFragment.showAllowingStateLoss(getSupportFragmentManager(), "registerSelectorDialogFragment");
    }


    private EmailResetPasswordCallback getEmailResetPasswordCallback() {
        return new EmailResetPasswordCallback() {

            @Override
            public void onSuccess(OpenAccountSession session) {
                LoginCallback callback = getLoginCallback();
                if (callback != null) {
                    callback.onSuccess(session);
                }
                finishWithoutCallback();
            }

            @Override
            public void onFailure(int code, String message) {
                LoginCallback callback = getLoginCallback();
                if (callback != null) {
                    callback.onFailure(code, message);
                }
            }

            @Override
            public void onEmailSent(String email) {

            }

        };
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        OauthService service = OpenAccountSDK.getService(OauthService.class);
        if (service != null) {
            service.authorizeCallback(requestCode, resultCode, data);
        }
    }


    private EmailRegisterCallback getEmailRegisterCallback() {
        return new EmailRegisterCallback() {

            @Override
            public void onSuccess(OpenAccountSession session) {
                LoginCallback callback = getLoginCallback();
                if (callback != null) {
                    callback.onSuccess(session);
                }
                finishWithoutCallback();
            }

            @Override
            public void onFailure(int code, String message) {
                LoginCallback callback = getLoginCallback();
                if (callback != null) {
                    callback.onFailure(code, message);
                }
            }

            @Override
            public void onEmailSent(String email) {
            }

        };
    }


    public void setCursorDrawableColor(EditText editText, int color) {
        try {
            Field f = TextView.class.getDeclaredField("mCursorDrawableRes");
            f.setAccessible(true);
            f.set(editText, color);
        } catch (Exception ignored) {
            ignored.printStackTrace();
        }
    }


}
