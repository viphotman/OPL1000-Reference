package com.aliyun.iot.aep.oa.page;

import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.Color;
import android.os.Build;
import android.os.Bundle;
import android.support.v4.content.ContextCompat;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.alibaba.sdk.android.openaccount.ui.ui.RegisterActivity;
import com.alibaba.sdk.android.openaccount.util.ResourceUtils;
import com.aliyun.iot.aep.oa.OALanguageHelper;
import com.aliyun.iot.aep.sdk.log.ALog;
import com.aliyun.iot.commonapp.login.R;

import java.lang.reflect.Field;

import static android.view.View.TEXT_ALIGNMENT_INHERIT;

/**
 * Created by feijie.xfj on 18/4/10.
 */

public class OARegisterActivity extends RegisterActivity {
    private static final String TAG = "OARegisterActivity";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        findViewById(R.id.aliuser_appbar).setVisibility(View.GONE);


        findViewById(R.id.imageview_account_back).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });


    }


    @Override
    protected void doUseCustomAttrs(Context context, TypedArray typedArray) {
        updateOriginalOAView();
    }

    @Override
    protected void attachBaseContext(Context newBase) {
        super.attachBaseContext(OALanguageHelper.attachBaseContext(newBase));
    }


    //隐藏调整OA的组件  -- 定制
    private void updateOriginalOAView() {
        //手机号码 hint字号大小

        EditText phoneET = mobileInputBox.findViewById(R.id.input);
        if (phoneET != null) {
            phoneET.setTextSize(TypedValue.COMPLEX_UNIT_DIP, 18);
            phoneET.setTextColor(Color.BLACK);
        }
        setCursorDrawableColor(mobileInputBox.getEditText(), ResourceUtils.getRDrawable(this, "et_cursor_color"));
        TextView chosedCountryNum = mobileInputBox.findViewById(R.id.edt_chosed_country_num);
        chosedCountryNum.setTextSize(TypedValue.COMPLEX_UNIT_DIP, 18);
        chosedCountryNum.setTextColor(getResources().getColor(R.color.color_999999));
        ((TextView) mobileInputBox.findViewById("edt_chosed_country_num_sub")).setTextColor(getResources().getColor(R.color.color_999999));
        //隐藏短信校验码左边的icon

        View accountLeft = smsCodeInputBox.findViewById(R.id.left_icon);
        if (accountLeft != null) {
            accountLeft.setVisibility(View.GONE);
        }
        View view = smsCodeInputBox.getChildAt(1);
        if (view != null) {
            view.setVisibility(View.GONE);
        }

        EditText rightInput = smsCodeInputBox.getEditText();
        if (rightInput != null) {
            rightInput.setHint("");
            setCursorDrawableColor(rightInput, ResourceUtils.getRDrawable(this, "et_cursor_color"));
            rightInput.setTextSize(TypedValue.COMPLEX_UNIT_DIP, 18);
            rightInput.setTextColor(Color.BLACK);
        }
        //发送短信验证码文字大小
        Button send = smsCodeInputBox.findViewById(R.id.send);
        if (send != null) {
            send.setTextSize(TypedValue.COMPLEX_UNIT_DIP, 12);
            send.setTextColor(ContextCompat.getColor(this, R.color.common_colorAccent));
            send.setMaxLines(2);
            send.setMaxWidth((int) (getResources().getDisplayMetrics().widthPixels * 0.3f));
            send.setTextAlignment(TEXT_ALIGNMENT_INHERIT);
            send.setGravity(Gravity.RIGHT | Gravity.CENTER_VERTICAL);
            //这里修改view的大小

            try {
                LinearLayout parentLL = (LinearLayout) send.getParent();
                LinearLayout.LayoutParams lp = (LinearLayout.LayoutParams) parentLL.getLayoutParams();
                lp.width = LinearLayout.LayoutParams.WRAP_CONTENT;
                lp.setMargins(convertDp2Px(5), 0, convertDp2Px(5), 0);

                parentLL.setLayoutParams(lp);
                //必须强制修改为center，否则字符变化时无法居中
                parentLL.setGravity(Gravity.END);
            } catch (Exception e) {
                ALog.i(TAG, "can't change sms text width");
            }
        }
    }

    public int convertDp2Px(float count) {
        return (int) TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, count, getApplication().getResources().getDisplayMetrics());
    }


    @Override
    protected void onUserCancel() {

    }

    public void setCursorDrawableColor(EditText editText, int color) {
        try {
            Field f = TextView.class.getDeclaredField("mCursorDrawableRes");
            f.setAccessible(true);
            f.set(editText, color);
        } catch (Exception ignored) {
            ignored.printStackTrace();
        }
    }
}
