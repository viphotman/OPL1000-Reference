package com.aliyun.iot.aep.oa.page.data;

/**
 * Created by feijie.xfj on 18/5/9.
 */

public class ALiYunAuthConfigData {
    public String oauth_consumer_key_test;
    public String oauth_consumer_key_online;

    public String oauth_consumer_secret_test;
    public String oauth_consumer_secret_online;

    public ALiYunAuthConfigData(String oauth_consumer_key_test, String oauth_consumer_key_online, String oauth_consumer_secret_test, String oauth_consumer_secret_online) {
        this.oauth_consumer_key_test = oauth_consumer_key_test;
        this.oauth_consumer_key_online = oauth_consumer_key_online;
        this.oauth_consumer_secret_test = oauth_consumer_secret_test;
        this.oauth_consumer_secret_online = oauth_consumer_secret_online;
    }

    public ALiYunAuthConfigData() {
    }
}
