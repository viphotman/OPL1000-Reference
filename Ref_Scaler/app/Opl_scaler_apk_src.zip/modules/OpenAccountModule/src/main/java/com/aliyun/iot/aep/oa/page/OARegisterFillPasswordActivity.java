package com.aliyun.iot.aep.oa.page;

import android.content.Context;
import android.graphics.Color;
import android.graphics.Typeface;
import android.os.Build;
import android.os.Bundle;
import android.util.TypedValue;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import com.alibaba.sdk.android.openaccount.ui.ui.RegisterFillPasswordActivity;
import com.alibaba.sdk.android.openaccount.util.ResourceUtils;
import com.aliyun.iot.aep.oa.OALanguageHelper;
import com.aliyun.iot.commonapp.login.R;

import java.lang.reflect.Field;

/**
 * Created by feijie.xfj on 18/4/11.
 */

public class OARegisterFillPasswordActivity extends RegisterFillPasswordActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        TRANSPARENT();
        findViewById(R.id.aliuser_appbar).setVisibility(View.GONE);


        findViewById(R.id.imageview_account_back).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });

        updateOriginalOAView();
    }


    @Override
    protected void attachBaseContext(Context newBase) {
        super.attachBaseContext(OALanguageHelper.attachBaseContext(newBase));
    }



    //隐藏调整OA的组件  -- 定制
    private void updateOriginalOAView() {
        //隐藏账密左边的icon

        View pwdLeft = passwordInputBox.findViewById(R.id.left_icon);
        if (pwdLeft != null) {
            pwdLeft.setVisibility(View.GONE);
        }
        EditText leftInput = passwordInputBox.getEditText();
        if (leftInput != null) {
            leftInput.setHint("");
            setCursorDrawableColor(leftInput, ResourceUtils.getRDrawable(this,"et_cursor_color"));
            leftInput.setTextSize(TypedValue.COMPLEX_UNIT_DIP, 18);
            leftInput.setTextColor(Color.BLACK);
        }
        setCursorDrawableColor(inputBoxWithClear.getEditText(), ResourceUtils.getRDrawable(this,"et_cursor_color"));
        Typeface typeface = Typeface.createFromAsset(this.getAssets(), "ali_sdk_openaccount/newiconfont.ttf");
        Button btnEye = (Button) passwordInputBox.findViewById("open_eye");
        btnEye.setTypeface(typeface);
    }

    protected final void TRANSPARENT() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            Window window = getWindow();
            window.clearFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS
                    | WindowManager.LayoutParams.FLAG_TRANSLUCENT_NAVIGATION);
            window.getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                    | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                    | View.SYSTEM_UI_FLAG_LAYOUT_STABLE);
            window.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS);
            window.setStatusBarColor(Color.TRANSPARENT);
            window.setNavigationBarColor(Color.TRANSPARENT);
        }
    }
    public  void setCursorDrawableColor(EditText editText, int color) {
        try {
            Field f = TextView.class.getDeclaredField("mCursorDrawableRes");
            f.setAccessible(true);
            f.set(editText, color);
        } catch (Exception ignored) {
            ignored.printStackTrace();
        }
    }

}
