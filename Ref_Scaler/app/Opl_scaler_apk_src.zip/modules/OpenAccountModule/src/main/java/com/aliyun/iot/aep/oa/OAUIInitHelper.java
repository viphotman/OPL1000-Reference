package com.aliyun.iot.aep.oa;

import android.app.Activity;

import com.alibaba.sdk.android.openaccount.ui.LayoutMapping;
import com.alibaba.sdk.android.openaccount.ui.OpenAccountUIConfigs;
import com.aliyun.iot.aep.oa.page.OALoginActivity;
import com.aliyun.iot.aep.oa.page.OALoginTransparentActivity;
import com.aliyun.iot.aep.oa.page.OAMobileCountrySelectorActivity;
import com.aliyun.iot.aep.oa.page.OARegisterActivity;
import com.aliyun.iot.aep.oa.page.OARegisterEmailActivity;
import com.aliyun.iot.aep.oa.page.OARegisterFillPasswordActivity;
import com.aliyun.iot.aep.oa.page.OAResetMailPasswordActivity;
import com.aliyun.iot.aep.oa.page.OAResetPasswordActivity;
import com.aliyun.iot.aep.oa.page.OAResetPasswordFillMailPwdAcitvity;
import com.aliyun.iot.aep.oa.page.OAResetPasswordFillPasswordActivity;
import com.aliyun.iot.aep.oa.page.data.ALiYunAuthConfigData;
import com.aliyun.iot.aep.sdk.login.LoginBusiness;
import com.aliyun.iot.aep.sdk.login.oa.OALoginAdapter;
import com.aliyun.iot.commonapp.login.R;


import java.util.HashMap;
import java.util.Locale;
import java.util.Map;

/**
 * Created by feijie.xfj on 18/5/17.
 */

public class OAUIInitHelper {

    public static String LANGUAGE = "";

    public static String COUNTRY = "";

    //是否隐藏注册按钮，默认不隐藏
    public static Boolean DisableRegisterFlag = false;

    public static void setLanguage(Locale locale) {
        OAUIInitHelper.LANGUAGE = locale.getLanguage();
        OAUIInitHelper.COUNTRY = locale.getCountry();
    }


    /**
     * 是否隐藏注册按钮 - 只针对默认IOT定制的OA登录页面，其余自定义页面需要自行提供
     */
    public static void disableRegister() {
        OAUIInitHelper.DisableRegisterFlag = true;
    }

    private static void initDefaultUIConfig(boolean supportAliYun) {
        if (supportAliYun) {
            LayoutMapping.put(OALoginTransparentActivity.class, R.layout.ali_sdk_openaccount_login2_transparent);
        } else {
            //注入自定义布局
            OpenAccountUIConfigs.MobileRegisterFlow.registerFillPasswordActivityClazz = OARegisterFillPasswordActivity.class;
            OpenAccountUIConfigs.UnifyLoginFlow.resetPasswordActivityClass = OAResetPasswordActivity.class;
            OpenAccountUIConfigs.MobileResetPasswordLoginFlow.resetPasswordPasswordActivityClazz = OAResetPasswordFillPasswordActivity.class;

            OpenAccountUIConfigs.AccountPasswordLoginFlow.supportForeignMobileNumbers = true;
            OpenAccountUIConfigs.AccountPasswordLoginFlow.mobileCountrySelectorActvityClazz = OAMobileCountrySelectorActivity.class;

            OpenAccountUIConfigs.ChangeMobileFlow.supportForeignMobileNumbers = true;
            OpenAccountUIConfigs.ChangeMobileFlow.mobileCountrySelectorActvityClazz = OAMobileCountrySelectorActivity.class;

            OpenAccountUIConfigs.MobileRegisterFlow.supportForeignMobileNumbers = true;
            OpenAccountUIConfigs.MobileRegisterFlow.mobileCountrySelectorActvityClazz = OAMobileCountrySelectorActivity.class;

            OpenAccountUIConfigs.MobileResetPasswordLoginFlow.supportForeignMobileNumbers = true;
            OpenAccountUIConfigs.MobileResetPasswordLoginFlow.mobileCountrySelectorActvityClazz = OAMobileCountrySelectorActivity.class;

            OpenAccountUIConfigs.OneStepMobileRegisterFlow.supportForeignMobileNumbers = true;
            OpenAccountUIConfigs.OneStepMobileRegisterFlow.mobileCountrySelectorActvityClazz = OAMobileCountrySelectorActivity.class;
            OpenAccountUIConfigs.EmailResetPasswordLoginFlow.resetPasswordActivityClazz = OAResetPasswordFillMailPwdAcitvity.class;

            LayoutMapping.put(OALoginActivity.class, R.layout.ali_sdk_openaccount_login2);

            LayoutMapping.put(OARegisterActivity.class, R.layout.ali_sdk_openaccount_register2);
            LayoutMapping.put(OARegisterEmailActivity.class, R.layout.ali_sdk_openaccount_mail_register2);
            LayoutMapping.put(OARegisterFillPasswordActivity.class, R.layout.ali_sdk_openaccount_register_fill_password2);

            LayoutMapping.put(OAResetMailPasswordActivity.class, R.layout.ali_sdk_openaccount_reset_password3_mail);
            LayoutMapping.put(OAResetPasswordActivity.class, R.layout.ali_sdk_openaccount_reset_password2_phone);

            LayoutMapping.put(OAResetPasswordFillPasswordActivity.class, R.layout.ali_sdk_openaccount_reset_password_fill_password2);
            LayoutMapping.put(OAResetPasswordFillMailPwdAcitvity.class, R.layout.ali_sdk_openaccount_reset_password_fill_password2);
        }
    }

    public static void initConfig(OALoginAdapter adapter, boolean supportAliYun, ALiYunAuthConfigData configData) {
        if (supportAliYun && configData == null) {
            throw new IllegalArgumentException("OA Support Aliyun , Must set configData");
        }
        initDefaultUIConfig(supportAliYun);

        //注入阿里云配置
        if (supportAliYun) {
            //阿里云账号页面暂时不支持插件配置
            adapter.setDefaultLoginClass(OALoginTransparentActivity.class);
            Map<String, String> params = new HashMap();
            if ("TEST".equalsIgnoreCase(LoginBusiness.getEnv())) {
                params.put("auth_consumer_key", configData.oauth_consumer_key_test);
                params.put("auth_consumer_secret", configData.oauth_consumer_secret_test);
            } else {
                params.put("auth_consumer_key", configData.oauth_consumer_key_online);
                params.put("auth_consumer_secret", configData.oauth_consumer_secret_online);
            }
            adapter.setDefaultLoginParams(params);
        } else {
            adapter.setDefaultLoginClass(OALoginActivity.class);
        }
    }


    /**
     * 注入登录页面UI
     *
     * @param adapter            初始化LoginBusiness的 ILoginAdapter
     * @param params             传递给Activity的额外参数
     * @param loginActivityClazz 自定义的LoginActivity -- 必须继承原生OA 的LoginActivity
     */
    public static void setCustomLoginActivityUIConfig(OALoginAdapter adapter, Map<String, String> params, Class<? extends Activity> loginActivityClazz) {
        if (loginActivityClazz != null) {
            adapter.setDefaultLoginClass(loginActivityClazz);
        }
        if (params != null && !params.isEmpty()) {
            adapter.setDefaultLoginParams(params);
        }
    }

    /**
     * 注入选择国家码页面UI
     *
     * @param mobileCountrySelectorActivityClazz 自定义的选择国家码页面
     */
    public static void setCustomSelectCountryActivityUIConfig(Class<? extends Activity> mobileCountrySelectorActivityClazz) {
        if (mobileCountrySelectorActivityClazz != null) {
            OpenAccountUIConfigs.AccountPasswordLoginFlow.mobileCountrySelectorActvityClazz = mobileCountrySelectorActivityClazz;
            OpenAccountUIConfigs.ChangeMobileFlow.mobileCountrySelectorActvityClazz = mobileCountrySelectorActivityClazz;
            OpenAccountUIConfigs.MobileRegisterFlow.mobileCountrySelectorActvityClazz = mobileCountrySelectorActivityClazz;
            OpenAccountUIConfigs.MobileResetPasswordLoginFlow.mobileCountrySelectorActvityClazz = mobileCountrySelectorActivityClazz;
            OpenAccountUIConfigs.OneStepMobileRegisterFlow.mobileCountrySelectorActvityClazz = mobileCountrySelectorActivityClazz;
        }
    }
}

