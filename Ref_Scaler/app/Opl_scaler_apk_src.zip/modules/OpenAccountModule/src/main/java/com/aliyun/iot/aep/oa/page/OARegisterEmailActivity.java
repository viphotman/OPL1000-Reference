package com.aliyun.iot.aep.oa.page;

import android.content.Context;
import android.graphics.Color;
import android.graphics.Typeface;
import android.os.Build;
import android.os.Bundle;
import android.util.AttributeSet;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.alibaba.sdk.android.openaccount.ui.ui.EmailRegisterActivity;
import com.alibaba.sdk.android.openaccount.util.ResourceUtils;
import com.aliyun.iot.aep.oa.OALanguageHelper;
import com.aliyun.iot.commonapp.login.R;

import java.lang.reflect.Field;

import static android.view.View.TEXT_ALIGNMENT_INHERIT;

public class OARegisterEmailActivity extends EmailRegisterActivity {
    private static final String TAG = "OARegisterEmailActivity";


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        findViewById(R.id.aliuser_appbar).setVisibility(View.GONE);
        TRANSPARENT();
        findViewById(R.id.imageview_account_back).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });


    }


    @Override
    protected void useCustomAttrs(Context context, AttributeSet attrs) {
        View btnLeft = mailInputBox.findViewById(R.id.left_icon);
        if (btnLeft != null) {
            btnLeft.setVisibility(View.GONE);
        }
        setCursorDrawableColor(mailInputBox.getEditText(), ResourceUtils.getRDrawable(this,"et_cursor_color"));



        View pwdLeft = passwordInputBox.findViewById(R.id.left_icon);
        if (pwdLeft != null) {
            pwdLeft.setVisibility(View.GONE);
        }
        setCursorDrawableColor(passwordInputBox.getEditText(), ResourceUtils.getRDrawable(this,"et_cursor_color"));


        View codeLeft = emailCodeInputBox.findViewById(R.id.left_icon);
        if (codeLeft != null) {
            codeLeft.setVisibility(View.GONE);
        }

        View view = emailCodeInputBox.getChildAt(1);
        if (view != null) {
            view.setVisibility(View.GONE);
        }

        View sendLL = emailCodeInputBox.getChildAt(2);

        try {
            ViewGroup.LayoutParams layoutParams = sendLL.getLayoutParams();
            layoutParams.width = LinearLayout.LayoutParams.WRAP_CONTENT;
            sendLL.setLayoutParams(layoutParams);
        } catch (Exception e) {
            e.printStackTrace();
        }

        setCursorDrawableColor( emailCodeInputBox.getEditText(), ResourceUtils.getRDrawable(this,"et_cursor_color"));

        emailCodeInputBox.getSend().setText(ResourceUtils.getString("account_send_email_code"));
        emailCodeInputBox.setSendText("account_send_email_code");
        emailCodeInputBox.getSend().setMaxLines(2);
        emailCodeInputBox.getSend().setTextSize(12);
        emailCodeInputBox.getSend().setMaxWidth((int) (getResources().getDisplayMetrics().widthPixels*0.3f));
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.JELLY_BEAN_MR1) {
            emailCodeInputBox.getSend().setTextAlignment(TEXT_ALIGNMENT_INHERIT);
        }
        emailCodeInputBox.getSend().setGravity(Gravity.RIGHT|Gravity.CENTER_VERTICAL);

        Typeface typeface = Typeface.createFromAsset(this.getAssets(), "ali_sdk_openaccount/newiconfont.ttf");
        Button btnEye = (Button) passwordInputBox.findViewById("open_eye");
        btnEye.setTypeface(typeface);
    }

    @Override
    protected void attachBaseContext(Context newBase) {
        super.attachBaseContext(OALanguageHelper.attachBaseContext(newBase));
    }



    protected final void TRANSPARENT() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            Window window = getWindow();
            window.clearFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS
                    | WindowManager.LayoutParams.FLAG_TRANSLUCENT_NAVIGATION);
            window.getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                    | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                    | View.SYSTEM_UI_FLAG_LAYOUT_STABLE);
            window.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS);
            window.setStatusBarColor(Color.TRANSPARENT);
            window.setNavigationBarColor(Color.TRANSPARENT);
        }
    }

    public void setCursorDrawableColor(EditText editText, int color) {
        try {
            Field f = TextView.class.getDeclaredField("mCursorDrawableRes");
            f.setAccessible(true);
            f.set(editText, color);
        } catch (Exception ignored) {
            ignored.printStackTrace();
        }
    }

}
