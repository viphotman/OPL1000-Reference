package com.aliyun.iot.aep.oa;

import android.content.Context;

import com.alibaba.sdk.android.openaccount.OpenAccountSDK;
import com.alibaba.sdk.android.openaccount.callback.LoginCallback;
import com.alibaba.sdk.android.openaccount.ui.OpenAccountUIService;
import com.aliyun.iot.aep.sdk.apiclient.IoTAPIClientFactory;
import com.aliyun.iot.aep.sdk.apiclient.callback.IoTCallback;
import com.aliyun.iot.aep.sdk.apiclient.emuns.Scheme;
import com.aliyun.iot.aep.sdk.apiclient.request.IoTRequest;
import com.aliyun.iot.aep.sdk.apiclient.request.IoTRequestBuilder;

import java.util.HashMap;
import java.util.Map;

public class OAUserHelper {

    /**
     * 修改用户昵称
     *
     * @param context
     * @param nickName
     * @param loginCallback
     */
    public static void updateNickName(Context context, String nickName, LoginCallback loginCallback) {
        Map<String, Object> map = new HashMap<>();
        map.put("displayName", nickName);
        OpenAccountUIService var2 = (OpenAccountUIService) OpenAccountSDK.getService(OpenAccountUIService.class);
        var2.updateProfile(context, map, loginCallback);
    }

    /**
     * 修改用户头像
     *
     * @param context
     * @param avatarUrl
     * @param loginCallback
     */
    public static void updateAvatarUrl(Context context, String avatarUrl, LoginCallback loginCallback) {
        Map<String, Object> map = new HashMap<>();
        map.put("avatarUrl", avatarUrl);
        OpenAccountUIService var2 = (OpenAccountUIService) OpenAccountSDK.getService(OpenAccountUIService.class);
        var2.updateProfile(context, map, loginCallback);
    }

    /***
     *
     * 提供裸接口，用于业务方，修改profile，接口为map类型,key-value对如下
     * 头像                avatarUrl            String
     * 显示名              displayName          String
     * 姓名                name                 String
     * 性别                gender               Integer 1男 2女
     * 生日                birthday             String
     * 旺旺                wangwang             String
     * 微信                weixin               String
     * 地区，用于国际化      locale               String
     * 记录创建的位置        createLocation       String
     * 扩展json            extInfos             String
     * 支付宝id            alipayId             String
     * 银行卡号            bankCardNo            String
     * 银行卡拥有者姓名     bankCardOwnerName     String
     * 国家名称            country               String
     * 公司名称            companyName           String
     * @param context
     * @param map
     * @param loginCallback
     */
    public static void updateProfile(Context context, Map<String, Object> map, LoginCallback loginCallback) {
        OpenAccountUIService var2 = (OpenAccountUIService) OpenAccountSDK.getService(OpenAccountUIService.class);
        var2.updateProfile(context, map, loginCallback);
    }


    /**
     * 注销账户
     */
    public static void unRegisterAccount(IoTCallback ioTCallback){
        IoTRequestBuilder builder = new IoTRequestBuilder();
        builder.setApiVersion("1.0.5");
        builder.setScheme(Scheme.HTTPS);
        builder.setPath("/account/unregister");
        builder.setAuthType("iotAuth");
        IoTRequest request = builder.build();
        new IoTAPIClientFactory().getClient().send(request, ioTCallback);
    }


}
