package com.aliyun.iot.aep.widget;

import android.content.Context;
import android.text.TextUtils;
import android.util.AttributeSet;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import com.alibaba.sdk.android.openaccount.ui.widget.InputBoxWithHistory;
import com.alibaba.sdk.android.openaccount.ui.widget.SensitiveTransformationMethod;
import com.alibaba.sdk.android.openaccount.util.ResourceUtils;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class OAInputBoxWithHistory extends InputBoxWithHistory {

    private static final String KEY_INPUT_HISTORY = "openaccount_input_history";

    private String historySavedKey = "openaccount_input_history";
    private String loginType = "phone";


    public OAInputBoxWithHistory(Context context, AttributeSet attrs) {
        super(context, attrs);

    }

    @Override
    public void updateHistoryView(String accountPrefix) {
        if (this.inputHistoryView != null) {
            this.showInputHistory(this, true);
            final List<String> accountMatchHistory = new ArrayList();
            Iterator var3 = this.inputHistory.iterator();

            while (true) {
                while (var3.hasNext()) {
                    String account = (String) var3.next();
                    if (!TextUtils.isEmpty(account) && account.startsWith(accountPrefix)) {
                        if ("mail".equalsIgnoreCase(loginType)) {
                            if (isEmail(account)) {
                                accountMatchHistory.add(account);
                            }
                        } else if ("phone".equalsIgnoreCase(loginType)) {
                            if (!isEmail(account)) {
                                accountMatchHistory.add(account);
                            }
                        }
                    } else if (TextUtils.isEmpty(account)) {
                        accountMatchHistory.add(account);
                    }
                }

                if (accountMatchHistory.size() == 0) {
                    this.showInputHistory(this, false);
                    return;
                }

                this.inputHistoryViewAdapter = new ArrayAdapter<String>(this.inputHistoryView.getContext(), ResourceUtils.getRLayout(this.inputHistoryView.getContext(), "ali_sdk_openaccount_input_history_item"), accountMatchHistory) {
                    public View getView(int position, View convertView, ViewGroup parent) {
                        View view = super.getView(position, convertView, parent);
                        if (view instanceof TextView) {
                            ((TextView) view).setTransformationMethod(SensitiveTransformationMethod.INSTANCE);
                        }

                        return view;
                    }
                };
                this.inputHistoryView.setAdapter(this.inputHistoryViewAdapter);
                this.inputHistoryView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
                    public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                        if (accountMatchHistory != null && accountMatchHistory.size() > position) {
                            inputBoxWithClear.getEditText().setText((CharSequence) accountMatchHistory.get(position));
                            showInputHistory(view, false);
                        }

                    }
                });
                return;
            }
        }

    }


    private boolean isEmail(String email) {
        //电子邮件
        String check = "^([a-z0-9A-Z]+[-|\\.]?)+[a-z0-9A-Z]@([a-z0-9A-Z]+(-[a-z0-9A-Z]+)?\\.)+[a-zA-Z]{2,}$";
        Pattern regex = Pattern.compile(check);
        Matcher matcher = regex.matcher(email);
        return matcher.matches();
    }


    public void setLoginType(String login) {
        loginType = login;
    }

}
