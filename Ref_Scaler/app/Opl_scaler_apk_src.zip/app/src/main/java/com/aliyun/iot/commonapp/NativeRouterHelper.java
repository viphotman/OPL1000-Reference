package com.aliyun.iot.commonapp;

import android.app.Activity;
import android.content.ActivityNotFoundException;
import android.content.Context;
import android.content.Intent;
import android.content.res.Resources;
import android.net.Uri;
import android.os.Bundle;

import com.aliyun.iot.aep.component.router.IUrlHandler;
import com.aliyun.iot.aep.component.router.Router;
import com.aliyun.iot.aghanim.log.LogActivity;
import com.aliyun.iot.commonapp.base.ui.WebViewActivity;
import com.aliyun.iot.commonapp.index.IndexActivity;

import static com.aliyun.iot.commonapp.base.ui.WebViewActivity.URL_REGEX;
import static com.aliyun.iot.commonapp.base.ui.WebViewActivity.URL_REGEX_2;

/**
 * Created by xingwei on 2018/4/28.
 */

class NativeRouterHelper {

    private static class SingletonHolder {
        private static final NativeRouterHelper INSTANCE = new NativeRouterHelper();
    }

    private NativeRouterHelper() {
    }

    static NativeRouterHelper getInstance() {
        return SingletonHolder.INSTANCE;
    }

    void init(Context applicationContext) {
        IUrlHandler outerAppUrlHandle = (context, url, bundle, isForResult, requestCode) -> {
            try {
                Intent intent = new Intent(context, WebViewActivity.class);
                intent.setData(Uri.parse(url));
                if (null != bundle) {
                    intent.putExtras(bundle);
                }
                if (isForResult && context instanceof Activity) {
                    ((Activity) context).startActivityForResult(intent, requestCode);
                } else {
                    context.startActivity(intent);
                }
            } catch (ActivityNotFoundException e) {
                e.printStackTrace();
            }
        };

        Router.getInstance().registerRegexUrlHandler(URL_REGEX, outerAppUrlHandle);
        Router.getInstance().registerRegexUrlHandler(URL_REGEX_2, outerAppUrlHandle);

        Resources resources = applicationContext.getResources();
        String toHome = resources.getString(R.string.default_router_format,
                resources.getString(R.string.in_app_router_schema),
                resources.getString(R.string.host_index_home));
        String toDeviceList = resources.getString(R.string.default_router_format,
                resources.getString(R.string.in_app_router_schema),
                resources.getString(R.string.host_index_device));
        String toProfile = resources.getString(R.string.default_router_format,
                resources.getString(R.string.in_app_router_schema),
                resources.getString(R.string.url_index_profile));

        IUrlHandler indexPageHandle = (context, url, bundle, isForResult, requestCode) -> {
            try {
                Intent intent = new Intent(context, IndexActivity.class);
                intent.setData(Uri.parse(url));
                intent.setFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP | Intent.FLAG_ACTIVITY_CLEAR_TOP);
                if (null != bundle) {
                    intent.putExtras(bundle);
                }
                if (isForResult && context instanceof Activity) {
                    ((Activity) context).startActivityForResult(intent, requestCode);
                } else {
                    context.startActivity(intent);
                }
            } catch (ActivityNotFoundException e) {
                e.printStackTrace();
            }
        };
        Router.getInstance().registerModuleUrlHandler(toHome, indexPageHandle);
        Router.getInstance().registerModuleUrlHandler(toDeviceList, indexPageHandle);
        Router.getInstance().registerModuleUrlHandler(toProfile, indexPageHandle);

        Router.getInstance().registerModuleUrlHandler("link://debug/pages/index", (context, s, bundle, b, i) -> {
            try {
                Intent intent = new Intent(context, LogActivity.class);
                if (null != bundle) intent.putExtras(bundle);
                intent.setFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP | Intent.FLAG_ACTIVITY_CLEAR_TOP);
                if (b && context instanceof Activity) {
                    ((Activity) context).startActivityForResult(intent, i);
                } else {
                    context.startActivity(intent);
                }
            } catch (ActivityNotFoundException e) {
                e.printStackTrace();
            }
        });
    }
}
