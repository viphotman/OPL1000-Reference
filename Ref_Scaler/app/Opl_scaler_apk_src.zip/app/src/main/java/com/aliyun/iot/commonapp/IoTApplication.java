package com.aliyun.iot.commonapp;

import android.app.ActivityManager;
import android.content.Context;
import android.content.Intent;
import android.os.StrictMode;
import android.util.Log;

import com.alibaba.sdk.android.openaccount.ConfigManager;
import com.aliyun.alink.sdk.bone.plugins.BaseBoneServiceFactory;
import com.aliyun.iot.aep.sdk.apiclient.IoTAPIClientImpl;
import com.aliyun.iot.aep.sdk.bridge.core.BoneServiceFactoryRegistry;
import com.aliyun.iot.aep.sdk.credential.IotCredentialManager.IoTCredentialManageImpl;
import com.aliyun.iot.aep.sdk.framework.AApplication;
import com.aliyun.iot.aep.sdk.log.ALog;
import com.aliyun.iot.aep.sdk.threadpool.ThreadPool;
import com.aliyun.iot.componentmanager.ComponentManager;

import static com.aliyun.iot.commonapp.base.Constants.LOGOUT_ACTION;

/**
 * 需要继承AApplication，会将所有配置在sdk_config 下的sdk 进行初始化
 *
 * @author sinyuk
 */
public class IoTApplication extends AApplication {

    @Override
    public void onCreate() {
        super.onCreate();


        String processName = null;
        int pid = android.os.Process.myPid();
        ActivityManager manager = (ActivityManager) this.getSystemService(Context.ACTIVITY_SERVICE);
        if (null == manager) return;
        for (ActivityManager.RunningAppProcessInfo i : manager.getRunningAppProcesses()) {
            if (i.pid == pid) {
                processName = i.processName;
                break;
            }
        }

        if (!getPackageName().equals(processName)) {
            // 非主进程直接退出
            return;
        }

        Log.d("IoTApplication", "Setting up StrictMode policy checking.");

//        StrictMode.setThreadPolicy(new StrictMode.ThreadPolicy.Builder()
//                .detectAll()
//                .penaltyLog()
//                .build());
//
//        StrictMode.setVmPolicy(new StrictMode.VmPolicy.Builder()
//                .detectAll()
//                .penaltyLog()
//                .build());

        ComponentManager.getInstance().init(this);

        // 注册路由
        NativeRouterHelper.getInstance().init(getApplicationContext());

        // 开启网络请求日志
        ThreadPool.MainThreadHandler.getInstance().post(() -> {
            // 开启网络请求日志
            IoTAPIClientImpl.getInstance().registerTracker(new Tracker());
            ALog.setLevel(ALog.LEVEL_VERBOSE);
        });

        try {
            IoTCredentialManageImpl.getInstance(this).setIotCredentialListenerList(() -> {
                Intent intent = new Intent();
                intent.setAction(LOGOUT_ACTION);
                sendBroadcast(intent);
            });
        } catch (IllegalArgumentException e) {
            e.printStackTrace();
        }
        ConfigManager.getInstance().setBundleName("com.aliyun.iot.commonapp");

        // TODO: delete this later
        BoneServiceFactoryRegistry.register(new BaseBoneServiceFactory());

    }
}